<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-08-24 17:16:28 --> Config Class Initialized
DEBUG - 2012-08-24 17:16:28 --> Hooks Class Initialized
DEBUG - 2012-08-24 17:16:28 --> Utf8 Class Initialized
DEBUG - 2012-08-24 17:16:28 --> UTF-8 Support Enabled
DEBUG - 2012-08-24 17:16:28 --> URI Class Initialized
DEBUG - 2012-08-24 17:16:28 --> Router Class Initialized
DEBUG - 2012-08-24 17:16:28 --> No URI present. Default controller set.
DEBUG - 2012-08-24 17:16:28 --> Output Class Initialized
DEBUG - 2012-08-24 17:16:28 --> Security Class Initialized
DEBUG - 2012-08-24 17:16:28 --> Input Class Initialized
DEBUG - 2012-08-24 17:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-24 17:16:28 --> Language Class Initialized
DEBUG - 2012-08-24 17:16:28 --> Loader Class Initialized
DEBUG - 2012-08-24 17:16:28 --> Helper loaded: date_helper
DEBUG - 2012-08-24 17:16:28 --> Controller Class Initialized
DEBUG - 2012-08-24 17:16:28 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-08-24 17:16:28 --> Final output sent to browser
DEBUG - 2012-08-24 17:16:28 --> Total execution time: 0.1748
DEBUG - 2012-08-24 17:40:58 --> Config Class Initialized
DEBUG - 2012-08-24 17:40:58 --> Hooks Class Initialized
DEBUG - 2012-08-24 17:40:58 --> Utf8 Class Initialized
DEBUG - 2012-08-24 17:40:58 --> UTF-8 Support Enabled
DEBUG - 2012-08-24 17:40:58 --> URI Class Initialized
DEBUG - 2012-08-24 17:40:58 --> Router Class Initialized
DEBUG - 2012-08-24 17:40:58 --> No URI present. Default controller set.
DEBUG - 2012-08-24 17:40:58 --> Output Class Initialized
DEBUG - 2012-08-24 17:40:58 --> Security Class Initialized
DEBUG - 2012-08-24 17:40:58 --> Input Class Initialized
DEBUG - 2012-08-24 17:40:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-24 17:40:58 --> Language Class Initialized
DEBUG - 2012-08-24 17:40:58 --> Loader Class Initialized
DEBUG - 2012-08-24 17:40:58 --> Helper loaded: date_helper
DEBUG - 2012-08-24 17:40:58 --> Controller Class Initialized
DEBUG - 2012-08-24 17:40:58 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-08-24 17:40:58 --> Final output sent to browser
DEBUG - 2012-08-24 17:40:58 --> Total execution time: 0.0236
DEBUG - 2012-08-24 17:43:08 --> Config Class Initialized
DEBUG - 2012-08-24 17:43:08 --> Hooks Class Initialized
DEBUG - 2012-08-24 17:43:08 --> Utf8 Class Initialized
DEBUG - 2012-08-24 17:43:08 --> UTF-8 Support Enabled
DEBUG - 2012-08-24 17:43:08 --> URI Class Initialized
DEBUG - 2012-08-24 17:43:08 --> Router Class Initialized
DEBUG - 2012-08-24 17:43:08 --> No URI present. Default controller set.
DEBUG - 2012-08-24 17:43:08 --> Output Class Initialized
DEBUG - 2012-08-24 17:43:08 --> Security Class Initialized
DEBUG - 2012-08-24 17:43:08 --> Input Class Initialized
DEBUG - 2012-08-24 17:43:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-24 17:43:08 --> Language Class Initialized
DEBUG - 2012-08-24 17:43:08 --> Loader Class Initialized
DEBUG - 2012-08-24 17:43:08 --> Helper loaded: date_helper
DEBUG - 2012-08-24 17:43:08 --> Controller Class Initialized
DEBUG - 2012-08-24 17:43:08 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-08-24 17:43:08 --> Final output sent to browser
DEBUG - 2012-08-24 17:43:08 --> Total execution time: 0.0225
DEBUG - 2012-08-24 17:43:44 --> Config Class Initialized
DEBUG - 2012-08-24 17:43:44 --> Hooks Class Initialized
DEBUG - 2012-08-24 17:43:44 --> Utf8 Class Initialized
DEBUG - 2012-08-24 17:43:44 --> UTF-8 Support Enabled
DEBUG - 2012-08-24 17:43:44 --> URI Class Initialized
DEBUG - 2012-08-24 17:43:44 --> Router Class Initialized
DEBUG - 2012-08-24 17:43:44 --> No URI present. Default controller set.
DEBUG - 2012-08-24 17:43:44 --> Output Class Initialized
DEBUG - 2012-08-24 17:43:44 --> Security Class Initialized
DEBUG - 2012-08-24 17:43:44 --> Input Class Initialized
DEBUG - 2012-08-24 17:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-24 17:43:44 --> Language Class Initialized
DEBUG - 2012-08-24 17:43:44 --> Loader Class Initialized
DEBUG - 2012-08-24 17:43:44 --> Helper loaded: date_helper
DEBUG - 2012-08-24 17:43:44 --> Controller Class Initialized
DEBUG - 2012-08-24 17:43:44 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-08-24 17:43:44 --> Final output sent to browser
DEBUG - 2012-08-24 17:43:44 --> Total execution time: 0.0220
DEBUG - 2012-08-24 17:47:36 --> Config Class Initialized
DEBUG - 2012-08-24 17:47:36 --> Hooks Class Initialized
DEBUG - 2012-08-24 17:47:36 --> Utf8 Class Initialized
DEBUG - 2012-08-24 17:47:36 --> UTF-8 Support Enabled
DEBUG - 2012-08-24 17:47:36 --> URI Class Initialized
DEBUG - 2012-08-24 17:47:36 --> Router Class Initialized
DEBUG - 2012-08-24 17:47:36 --> No URI present. Default controller set.
DEBUG - 2012-08-24 17:47:36 --> Output Class Initialized
DEBUG - 2012-08-24 17:47:36 --> Security Class Initialized
DEBUG - 2012-08-24 17:47:36 --> Input Class Initialized
DEBUG - 2012-08-24 17:47:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-24 17:47:36 --> Language Class Initialized
DEBUG - 2012-08-24 17:47:36 --> Loader Class Initialized
DEBUG - 2012-08-24 17:47:36 --> Helper loaded: date_helper
DEBUG - 2012-08-24 17:47:36 --> Controller Class Initialized
DEBUG - 2012-08-24 17:47:36 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-08-24 17:47:36 --> Final output sent to browser
DEBUG - 2012-08-24 17:47:36 --> Total execution time: 0.0226
DEBUG - 2012-08-24 17:48:42 --> Config Class Initialized
DEBUG - 2012-08-24 17:48:42 --> Hooks Class Initialized
DEBUG - 2012-08-24 17:48:42 --> Utf8 Class Initialized
DEBUG - 2012-08-24 17:48:42 --> UTF-8 Support Enabled
DEBUG - 2012-08-24 17:48:42 --> URI Class Initialized
DEBUG - 2012-08-24 17:48:42 --> Router Class Initialized
DEBUG - 2012-08-24 17:48:42 --> No URI present. Default controller set.
DEBUG - 2012-08-24 17:48:42 --> Output Class Initialized
DEBUG - 2012-08-24 17:48:42 --> Security Class Initialized
DEBUG - 2012-08-24 17:48:42 --> Input Class Initialized
DEBUG - 2012-08-24 17:48:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-24 17:48:42 --> Language Class Initialized
DEBUG - 2012-08-24 17:48:42 --> Loader Class Initialized
DEBUG - 2012-08-24 17:48:42 --> Helper loaded: date_helper
DEBUG - 2012-08-24 17:48:42 --> Controller Class Initialized
DEBUG - 2012-08-24 17:48:42 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-08-24 17:48:42 --> Final output sent to browser
DEBUG - 2012-08-24 17:48:42 --> Total execution time: 0.0257
DEBUG - 2012-08-24 17:50:32 --> Config Class Initialized
DEBUG - 2012-08-24 17:50:32 --> Hooks Class Initialized
DEBUG - 2012-08-24 17:50:32 --> Utf8 Class Initialized
DEBUG - 2012-08-24 17:50:32 --> UTF-8 Support Enabled
DEBUG - 2012-08-24 17:50:32 --> URI Class Initialized
DEBUG - 2012-08-24 17:50:32 --> Router Class Initialized
DEBUG - 2012-08-24 17:50:32 --> No URI present. Default controller set.
DEBUG - 2012-08-24 17:50:32 --> Output Class Initialized
DEBUG - 2012-08-24 17:50:32 --> Security Class Initialized
DEBUG - 2012-08-24 17:50:32 --> Input Class Initialized
DEBUG - 2012-08-24 17:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-24 17:50:32 --> Language Class Initialized
DEBUG - 2012-08-24 17:50:32 --> Loader Class Initialized
DEBUG - 2012-08-24 17:50:32 --> Helper loaded: date_helper
DEBUG - 2012-08-24 17:50:32 --> Controller Class Initialized
DEBUG - 2012-08-24 17:50:32 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-08-24 17:50:32 --> Final output sent to browser
DEBUG - 2012-08-24 17:50:32 --> Total execution time: 0.0230
DEBUG - 2012-08-24 17:51:25 --> Config Class Initialized
DEBUG - 2012-08-24 17:51:25 --> Hooks Class Initialized
DEBUG - 2012-08-24 17:51:25 --> Utf8 Class Initialized
DEBUG - 2012-08-24 17:51:25 --> UTF-8 Support Enabled
DEBUG - 2012-08-24 17:51:25 --> URI Class Initialized
DEBUG - 2012-08-24 17:51:25 --> Router Class Initialized
DEBUG - 2012-08-24 17:51:25 --> No URI present. Default controller set.
DEBUG - 2012-08-24 17:51:25 --> Output Class Initialized
DEBUG - 2012-08-24 17:51:25 --> Security Class Initialized
DEBUG - 2012-08-24 17:51:25 --> Input Class Initialized
DEBUG - 2012-08-24 17:51:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-24 17:51:25 --> Language Class Initialized
DEBUG - 2012-08-24 17:51:25 --> Loader Class Initialized
DEBUG - 2012-08-24 17:51:25 --> Helper loaded: date_helper
DEBUG - 2012-08-24 17:51:25 --> Controller Class Initialized
DEBUG - 2012-08-24 17:51:25 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-08-24 17:51:25 --> Final output sent to browser
DEBUG - 2012-08-24 17:51:25 --> Total execution time: 0.0386
DEBUG - 2012-08-24 17:51:33 --> Config Class Initialized
DEBUG - 2012-08-24 17:51:33 --> Hooks Class Initialized
DEBUG - 2012-08-24 17:51:33 --> Utf8 Class Initialized
DEBUG - 2012-08-24 17:51:33 --> UTF-8 Support Enabled
DEBUG - 2012-08-24 17:51:33 --> URI Class Initialized
DEBUG - 2012-08-24 17:51:33 --> Router Class Initialized
DEBUG - 2012-08-24 17:51:33 --> No URI present. Default controller set.
DEBUG - 2012-08-24 17:51:33 --> Output Class Initialized
DEBUG - 2012-08-24 17:51:33 --> Security Class Initialized
DEBUG - 2012-08-24 17:51:33 --> Input Class Initialized
DEBUG - 2012-08-24 17:51:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-24 17:51:33 --> Language Class Initialized
DEBUG - 2012-08-24 17:51:33 --> Loader Class Initialized
DEBUG - 2012-08-24 17:51:33 --> Helper loaded: date_helper
DEBUG - 2012-08-24 17:51:33 --> Controller Class Initialized
DEBUG - 2012-08-24 17:51:33 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-08-24 17:51:33 --> Final output sent to browser
DEBUG - 2012-08-24 17:51:33 --> Total execution time: 0.0262
DEBUG - 2012-08-24 17:52:33 --> Config Class Initialized
DEBUG - 2012-08-24 17:52:33 --> Hooks Class Initialized
DEBUG - 2012-08-24 17:52:33 --> Utf8 Class Initialized
DEBUG - 2012-08-24 17:52:33 --> UTF-8 Support Enabled
DEBUG - 2012-08-24 17:52:33 --> URI Class Initialized
DEBUG - 2012-08-24 17:52:33 --> Router Class Initialized
DEBUG - 2012-08-24 17:52:33 --> No URI present. Default controller set.
DEBUG - 2012-08-24 17:52:33 --> Output Class Initialized
DEBUG - 2012-08-24 17:52:33 --> Security Class Initialized
DEBUG - 2012-08-24 17:52:33 --> Input Class Initialized
DEBUG - 2012-08-24 17:52:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-24 17:52:33 --> Language Class Initialized
DEBUG - 2012-08-24 17:52:33 --> Loader Class Initialized
DEBUG - 2012-08-24 17:52:33 --> Helper loaded: date_helper
DEBUG - 2012-08-24 17:52:33 --> Controller Class Initialized
DEBUG - 2012-08-24 17:52:33 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-08-24 17:52:33 --> Final output sent to browser
DEBUG - 2012-08-24 17:52:33 --> Total execution time: 0.0228
DEBUG - 2012-08-24 17:52:43 --> Config Class Initialized
DEBUG - 2012-08-24 17:52:43 --> Hooks Class Initialized
DEBUG - 2012-08-24 17:52:43 --> Utf8 Class Initialized
DEBUG - 2012-08-24 17:52:43 --> UTF-8 Support Enabled
DEBUG - 2012-08-24 17:52:43 --> URI Class Initialized
DEBUG - 2012-08-24 17:52:43 --> Router Class Initialized
DEBUG - 2012-08-24 17:52:43 --> No URI present. Default controller set.
DEBUG - 2012-08-24 17:52:43 --> Output Class Initialized
DEBUG - 2012-08-24 17:52:43 --> Security Class Initialized
DEBUG - 2012-08-24 17:52:43 --> Input Class Initialized
DEBUG - 2012-08-24 17:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-24 17:52:43 --> Language Class Initialized
DEBUG - 2012-08-24 17:52:43 --> Loader Class Initialized
DEBUG - 2012-08-24 17:52:43 --> Helper loaded: date_helper
DEBUG - 2012-08-24 17:52:43 --> Controller Class Initialized
DEBUG - 2012-08-24 17:52:43 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-08-24 17:52:43 --> Final output sent to browser
DEBUG - 2012-08-24 17:52:43 --> Total execution time: 0.0213
DEBUG - 2012-08-24 18:21:02 --> Config Class Initialized
DEBUG - 2012-08-24 18:21:02 --> Hooks Class Initialized
DEBUG - 2012-08-24 18:21:02 --> Utf8 Class Initialized
DEBUG - 2012-08-24 18:21:02 --> UTF-8 Support Enabled
DEBUG - 2012-08-24 18:21:02 --> URI Class Initialized
DEBUG - 2012-08-24 18:21:02 --> Router Class Initialized
DEBUG - 2012-08-24 18:21:02 --> No URI present. Default controller set.
DEBUG - 2012-08-24 18:21:02 --> Output Class Initialized
DEBUG - 2012-08-24 18:21:02 --> Security Class Initialized
DEBUG - 2012-08-24 18:21:02 --> Input Class Initialized
DEBUG - 2012-08-24 18:21:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-24 18:21:02 --> Language Class Initialized
DEBUG - 2012-08-24 18:21:02 --> Loader Class Initialized
DEBUG - 2012-08-24 18:21:02 --> Helper loaded: date_helper
DEBUG - 2012-08-24 18:21:02 --> Controller Class Initialized
DEBUG - 2012-08-24 18:21:02 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-08-24 18:21:02 --> Final output sent to browser
DEBUG - 2012-08-24 18:21:02 --> Total execution time: 0.0259
