<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-09-22 05:09:56 --> Config Class Initialized
DEBUG - 2012-09-22 05:09:56 --> Hooks Class Initialized
DEBUG - 2012-09-22 05:09:56 --> Utf8 Class Initialized
DEBUG - 2012-09-22 05:09:56 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 05:09:56 --> URI Class Initialized
DEBUG - 2012-09-22 05:09:56 --> Router Class Initialized
ERROR - 2012-09-22 05:09:56 --> 404 Page Not Found --> admin
DEBUG - 2012-09-22 05:09:57 --> Config Class Initialized
DEBUG - 2012-09-22 05:09:57 --> Hooks Class Initialized
DEBUG - 2012-09-22 05:09:57 --> Utf8 Class Initialized
DEBUG - 2012-09-22 05:09:57 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 05:09:57 --> URI Class Initialized
DEBUG - 2012-09-22 05:09:57 --> Router Class Initialized
ERROR - 2012-09-22 05:09:57 --> 404 Page Not Found --> admin
DEBUG - 2012-09-22 05:09:57 --> Config Class Initialized
DEBUG - 2012-09-22 05:09:57 --> Hooks Class Initialized
DEBUG - 2012-09-22 05:09:57 --> Utf8 Class Initialized
DEBUG - 2012-09-22 05:09:57 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 05:09:57 --> URI Class Initialized
DEBUG - 2012-09-22 05:09:57 --> Router Class Initialized
ERROR - 2012-09-22 05:09:57 --> 404 Page Not Found --> admin
DEBUG - 2012-09-22 16:32:53 --> Config Class Initialized
DEBUG - 2012-09-22 16:32:53 --> Hooks Class Initialized
DEBUG - 2012-09-22 16:32:53 --> Utf8 Class Initialized
DEBUG - 2012-09-22 16:32:53 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 16:32:53 --> URI Class Initialized
DEBUG - 2012-09-22 16:32:53 --> Router Class Initialized
DEBUG - 2012-09-22 16:32:53 --> No URI present. Default controller set.
DEBUG - 2012-09-22 16:32:53 --> Output Class Initialized
DEBUG - 2012-09-22 16:32:53 --> Security Class Initialized
DEBUG - 2012-09-22 16:32:53 --> Input Class Initialized
DEBUG - 2012-09-22 16:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-22 16:32:53 --> Language Class Initialized
DEBUG - 2012-09-22 16:32:53 --> Loader Class Initialized
DEBUG - 2012-09-22 16:32:53 --> Helper loaded: date_helper
DEBUG - 2012-09-22 16:32:53 --> Controller Class Initialized
DEBUG - 2012-09-22 16:32:53 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-09-22 16:32:53 --> Final output sent to browser
DEBUG - 2012-09-22 16:32:53 --> Total execution time: 0.2348
DEBUG - 2012-09-22 17:23:15 --> Config Class Initialized
DEBUG - 2012-09-22 17:23:15 --> Hooks Class Initialized
DEBUG - 2012-09-22 17:23:15 --> Utf8 Class Initialized
DEBUG - 2012-09-22 17:23:15 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 17:23:15 --> URI Class Initialized
DEBUG - 2012-09-22 17:23:15 --> Router Class Initialized
ERROR - 2012-09-22 17:23:15 --> 404 Page Not Found --> scrape
DEBUG - 2012-09-22 17:23:15 --> Config Class Initialized
DEBUG - 2012-09-22 17:23:15 --> Hooks Class Initialized
DEBUG - 2012-09-22 17:23:15 --> Utf8 Class Initialized
DEBUG - 2012-09-22 17:23:15 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 17:23:15 --> URI Class Initialized
DEBUG - 2012-09-22 17:23:15 --> Router Class Initialized
ERROR - 2012-09-22 17:23:16 --> 404 Page Not Found --> announce
DEBUG - 2012-09-22 20:01:36 --> Config Class Initialized
DEBUG - 2012-09-22 20:01:36 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:01:36 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:01:36 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:01:36 --> URI Class Initialized
DEBUG - 2012-09-22 20:01:36 --> Router Class Initialized
ERROR - 2012-09-22 20:01:36 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:01:37 --> Config Class Initialized
DEBUG - 2012-09-22 20:01:37 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:01:37 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:01:37 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:01:37 --> URI Class Initialized
DEBUG - 2012-09-22 20:01:37 --> Router Class Initialized
ERROR - 2012-09-22 20:01:37 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:01:53 --> Config Class Initialized
DEBUG - 2012-09-22 20:01:53 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:01:53 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:01:53 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:01:53 --> URI Class Initialized
DEBUG - 2012-09-22 20:01:53 --> Router Class Initialized
ERROR - 2012-09-22 20:01:53 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:01:53 --> Config Class Initialized
DEBUG - 2012-09-22 20:01:53 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:01:53 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:01:53 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:01:53 --> URI Class Initialized
DEBUG - 2012-09-22 20:01:53 --> Router Class Initialized
ERROR - 2012-09-22 20:01:53 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:02:16 --> Config Class Initialized
DEBUG - 2012-09-22 20:02:16 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:02:16 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:02:16 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:02:16 --> URI Class Initialized
DEBUG - 2012-09-22 20:02:16 --> Router Class Initialized
ERROR - 2012-09-22 20:02:16 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:02:16 --> Config Class Initialized
DEBUG - 2012-09-22 20:02:16 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:02:16 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:02:16 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:02:16 --> URI Class Initialized
DEBUG - 2012-09-22 20:02:16 --> Router Class Initialized
ERROR - 2012-09-22 20:02:16 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:02:27 --> Config Class Initialized
DEBUG - 2012-09-22 20:02:27 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:02:27 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:02:27 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:02:27 --> URI Class Initialized
DEBUG - 2012-09-22 20:02:27 --> Router Class Initialized
ERROR - 2012-09-22 20:02:27 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:02:27 --> Config Class Initialized
DEBUG - 2012-09-22 20:02:27 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:02:27 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:02:27 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:02:27 --> URI Class Initialized
DEBUG - 2012-09-22 20:02:27 --> Router Class Initialized
ERROR - 2012-09-22 20:02:27 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:02:35 --> Config Class Initialized
DEBUG - 2012-09-22 20:02:35 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:02:35 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:02:35 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:02:35 --> URI Class Initialized
DEBUG - 2012-09-22 20:02:35 --> Router Class Initialized
ERROR - 2012-09-22 20:02:35 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:02:35 --> Config Class Initialized
DEBUG - 2012-09-22 20:02:35 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:02:35 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:02:35 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:02:35 --> URI Class Initialized
DEBUG - 2012-09-22 20:02:35 --> Router Class Initialized
ERROR - 2012-09-22 20:02:35 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:02:43 --> Config Class Initialized
DEBUG - 2012-09-22 20:02:43 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:02:43 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:02:43 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:02:43 --> URI Class Initialized
DEBUG - 2012-09-22 20:02:43 --> Router Class Initialized
ERROR - 2012-09-22 20:02:43 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:02:43 --> Config Class Initialized
DEBUG - 2012-09-22 20:02:43 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:02:43 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:02:43 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:02:43 --> URI Class Initialized
DEBUG - 2012-09-22 20:02:43 --> Router Class Initialized
ERROR - 2012-09-22 20:02:43 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:02:52 --> Config Class Initialized
DEBUG - 2012-09-22 20:02:52 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:02:52 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:02:52 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:02:52 --> URI Class Initialized
DEBUG - 2012-09-22 20:02:52 --> Router Class Initialized
ERROR - 2012-09-22 20:02:52 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:02:52 --> Config Class Initialized
DEBUG - 2012-09-22 20:02:52 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:02:52 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:02:52 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:02:52 --> URI Class Initialized
DEBUG - 2012-09-22 20:02:52 --> Router Class Initialized
ERROR - 2012-09-22 20:02:52 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:03:10 --> Config Class Initialized
DEBUG - 2012-09-22 20:03:10 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:03:10 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:03:10 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:03:10 --> URI Class Initialized
DEBUG - 2012-09-22 20:03:10 --> Router Class Initialized
ERROR - 2012-09-22 20:03:10 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:03:10 --> Config Class Initialized
DEBUG - 2012-09-22 20:03:10 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:03:10 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:03:10 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:03:10 --> URI Class Initialized
DEBUG - 2012-09-22 20:03:10 --> Router Class Initialized
ERROR - 2012-09-22 20:03:10 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:03:13 --> Config Class Initialized
DEBUG - 2012-09-22 20:03:13 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:03:13 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:03:13 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:03:13 --> URI Class Initialized
DEBUG - 2012-09-22 20:03:13 --> Router Class Initialized
ERROR - 2012-09-22 20:03:13 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:03:13 --> Config Class Initialized
DEBUG - 2012-09-22 20:03:13 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:03:13 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:03:13 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:03:13 --> URI Class Initialized
DEBUG - 2012-09-22 20:03:13 --> Router Class Initialized
ERROR - 2012-09-22 20:03:13 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:03:22 --> Config Class Initialized
DEBUG - 2012-09-22 20:03:22 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:03:22 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:03:22 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:03:22 --> URI Class Initialized
DEBUG - 2012-09-22 20:03:22 --> Router Class Initialized
ERROR - 2012-09-22 20:03:22 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:03:22 --> Config Class Initialized
DEBUG - 2012-09-22 20:03:22 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:03:22 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:03:22 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:03:22 --> URI Class Initialized
DEBUG - 2012-09-22 20:03:22 --> Router Class Initialized
ERROR - 2012-09-22 20:03:22 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:03:34 --> Config Class Initialized
DEBUG - 2012-09-22 20:03:34 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:03:34 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:03:34 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:03:34 --> URI Class Initialized
DEBUG - 2012-09-22 20:03:34 --> Router Class Initialized
ERROR - 2012-09-22 20:03:34 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:03:34 --> Config Class Initialized
DEBUG - 2012-09-22 20:03:34 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:03:34 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:03:34 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:03:34 --> URI Class Initialized
DEBUG - 2012-09-22 20:03:34 --> Router Class Initialized
ERROR - 2012-09-22 20:03:34 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:03:38 --> Config Class Initialized
DEBUG - 2012-09-22 20:03:38 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:03:38 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:03:38 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:03:38 --> URI Class Initialized
DEBUG - 2012-09-22 20:03:38 --> Router Class Initialized
ERROR - 2012-09-22 20:03:38 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:03:38 --> Config Class Initialized
DEBUG - 2012-09-22 20:03:38 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:03:38 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:03:38 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:03:38 --> URI Class Initialized
DEBUG - 2012-09-22 20:03:38 --> Router Class Initialized
ERROR - 2012-09-22 20:03:38 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:03:48 --> Config Class Initialized
DEBUG - 2012-09-22 20:03:48 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:03:48 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:03:48 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:03:48 --> URI Class Initialized
DEBUG - 2012-09-22 20:03:48 --> Router Class Initialized
ERROR - 2012-09-22 20:03:48 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:03:49 --> Config Class Initialized
DEBUG - 2012-09-22 20:03:49 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:03:49 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:03:49 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:03:49 --> URI Class Initialized
DEBUG - 2012-09-22 20:03:49 --> Router Class Initialized
ERROR - 2012-09-22 20:03:49 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:03:57 --> Config Class Initialized
DEBUG - 2012-09-22 20:03:57 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:03:57 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:03:57 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:03:57 --> URI Class Initialized
DEBUG - 2012-09-22 20:03:57 --> Router Class Initialized
ERROR - 2012-09-22 20:03:57 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:03:57 --> Config Class Initialized
DEBUG - 2012-09-22 20:03:57 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:03:57 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:03:57 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:03:57 --> URI Class Initialized
DEBUG - 2012-09-22 20:03:57 --> Router Class Initialized
ERROR - 2012-09-22 20:03:57 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:04:06 --> Config Class Initialized
DEBUG - 2012-09-22 20:04:06 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:04:06 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:04:06 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:04:06 --> URI Class Initialized
DEBUG - 2012-09-22 20:04:06 --> Router Class Initialized
ERROR - 2012-09-22 20:04:06 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:04:06 --> Config Class Initialized
DEBUG - 2012-09-22 20:04:06 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:04:06 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:04:06 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:04:06 --> URI Class Initialized
DEBUG - 2012-09-22 20:04:06 --> Router Class Initialized
ERROR - 2012-09-22 20:04:06 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:04:27 --> Config Class Initialized
DEBUG - 2012-09-22 20:04:27 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:04:27 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:04:27 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:04:27 --> URI Class Initialized
DEBUG - 2012-09-22 20:04:27 --> Router Class Initialized
ERROR - 2012-09-22 20:04:27 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:04:28 --> Config Class Initialized
DEBUG - 2012-09-22 20:04:28 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:04:28 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:04:28 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:04:28 --> URI Class Initialized
DEBUG - 2012-09-22 20:04:28 --> Router Class Initialized
ERROR - 2012-09-22 20:04:28 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:04:34 --> Config Class Initialized
DEBUG - 2012-09-22 20:04:34 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:04:34 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:04:34 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:04:34 --> URI Class Initialized
DEBUG - 2012-09-22 20:04:34 --> Router Class Initialized
ERROR - 2012-09-22 20:04:34 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:04:34 --> Config Class Initialized
DEBUG - 2012-09-22 20:04:34 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:04:34 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:04:34 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:04:34 --> URI Class Initialized
DEBUG - 2012-09-22 20:04:34 --> Router Class Initialized
ERROR - 2012-09-22 20:04:34 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:04:44 --> Config Class Initialized
DEBUG - 2012-09-22 20:04:44 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:04:44 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:04:44 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:04:44 --> URI Class Initialized
DEBUG - 2012-09-22 20:04:44 --> Router Class Initialized
ERROR - 2012-09-22 20:04:44 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:04:44 --> Config Class Initialized
DEBUG - 2012-09-22 20:04:44 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:04:44 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:04:44 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:04:44 --> URI Class Initialized
DEBUG - 2012-09-22 20:04:44 --> Router Class Initialized
ERROR - 2012-09-22 20:04:44 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:04:53 --> Config Class Initialized
DEBUG - 2012-09-22 20:04:53 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:04:53 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:04:53 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:04:53 --> URI Class Initialized
DEBUG - 2012-09-22 20:04:53 --> Router Class Initialized
ERROR - 2012-09-22 20:04:53 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:04:53 --> Config Class Initialized
DEBUG - 2012-09-22 20:04:53 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:04:53 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:04:53 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:04:53 --> URI Class Initialized
DEBUG - 2012-09-22 20:04:53 --> Router Class Initialized
ERROR - 2012-09-22 20:04:53 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:04:59 --> Config Class Initialized
DEBUG - 2012-09-22 20:04:59 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:04:59 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:04:59 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:04:59 --> URI Class Initialized
DEBUG - 2012-09-22 20:04:59 --> Router Class Initialized
ERROR - 2012-09-22 20:04:59 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:04:59 --> Config Class Initialized
DEBUG - 2012-09-22 20:04:59 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:04:59 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:04:59 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:04:59 --> URI Class Initialized
DEBUG - 2012-09-22 20:04:59 --> Router Class Initialized
ERROR - 2012-09-22 20:04:59 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:05:07 --> Config Class Initialized
DEBUG - 2012-09-22 20:05:07 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:05:07 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:05:07 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:05:07 --> URI Class Initialized
DEBUG - 2012-09-22 20:05:07 --> Router Class Initialized
ERROR - 2012-09-22 20:05:07 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:05:08 --> Config Class Initialized
DEBUG - 2012-09-22 20:05:08 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:05:08 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:05:08 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:05:08 --> URI Class Initialized
DEBUG - 2012-09-22 20:05:08 --> Router Class Initialized
ERROR - 2012-09-22 20:05:08 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:05:15 --> Config Class Initialized
DEBUG - 2012-09-22 20:05:15 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:05:15 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:05:15 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:05:15 --> URI Class Initialized
DEBUG - 2012-09-22 20:05:15 --> Router Class Initialized
ERROR - 2012-09-22 20:05:15 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:05:16 --> Config Class Initialized
DEBUG - 2012-09-22 20:05:16 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:05:16 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:05:16 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:05:16 --> URI Class Initialized
DEBUG - 2012-09-22 20:05:16 --> Router Class Initialized
ERROR - 2012-09-22 20:05:16 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:05:25 --> Config Class Initialized
DEBUG - 2012-09-22 20:05:25 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:05:25 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:05:25 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:05:25 --> URI Class Initialized
DEBUG - 2012-09-22 20:05:25 --> Router Class Initialized
ERROR - 2012-09-22 20:05:25 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:05:25 --> Config Class Initialized
DEBUG - 2012-09-22 20:05:25 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:05:25 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:05:25 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:05:25 --> URI Class Initialized
DEBUG - 2012-09-22 20:05:25 --> Router Class Initialized
ERROR - 2012-09-22 20:05:25 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:05:36 --> Config Class Initialized
DEBUG - 2012-09-22 20:05:36 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:05:36 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:05:36 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:05:36 --> URI Class Initialized
DEBUG - 2012-09-22 20:05:36 --> Router Class Initialized
ERROR - 2012-09-22 20:05:36 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:05:36 --> Config Class Initialized
DEBUG - 2012-09-22 20:05:36 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:05:36 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:05:36 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:05:36 --> URI Class Initialized
DEBUG - 2012-09-22 20:05:36 --> Router Class Initialized
ERROR - 2012-09-22 20:05:36 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:05:45 --> Config Class Initialized
DEBUG - 2012-09-22 20:05:45 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:05:45 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:05:45 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:05:45 --> URI Class Initialized
DEBUG - 2012-09-22 20:05:45 --> Router Class Initialized
ERROR - 2012-09-22 20:05:45 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:05:45 --> Config Class Initialized
DEBUG - 2012-09-22 20:05:45 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:05:45 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:05:45 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:05:45 --> URI Class Initialized
DEBUG - 2012-09-22 20:05:45 --> Router Class Initialized
ERROR - 2012-09-22 20:05:45 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:05:59 --> Config Class Initialized
DEBUG - 2012-09-22 20:05:59 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:05:59 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:05:59 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:05:59 --> URI Class Initialized
DEBUG - 2012-09-22 20:05:59 --> Router Class Initialized
ERROR - 2012-09-22 20:05:59 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:05:59 --> Config Class Initialized
DEBUG - 2012-09-22 20:05:59 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:05:59 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:05:59 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:05:59 --> URI Class Initialized
DEBUG - 2012-09-22 20:05:59 --> Router Class Initialized
ERROR - 2012-09-22 20:05:59 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:06:12 --> Config Class Initialized
DEBUG - 2012-09-22 20:06:12 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:06:12 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:06:12 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:06:12 --> URI Class Initialized
DEBUG - 2012-09-22 20:06:12 --> Router Class Initialized
ERROR - 2012-09-22 20:06:12 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:06:12 --> Config Class Initialized
DEBUG - 2012-09-22 20:06:12 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:06:12 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:06:12 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:06:12 --> URI Class Initialized
DEBUG - 2012-09-22 20:06:12 --> Router Class Initialized
ERROR - 2012-09-22 20:06:12 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:06:20 --> Config Class Initialized
DEBUG - 2012-09-22 20:06:20 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:06:20 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:06:20 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:06:20 --> URI Class Initialized
DEBUG - 2012-09-22 20:06:20 --> Router Class Initialized
ERROR - 2012-09-22 20:06:20 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:06:20 --> Config Class Initialized
DEBUG - 2012-09-22 20:06:20 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:06:20 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:06:20 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:06:20 --> URI Class Initialized
DEBUG - 2012-09-22 20:06:20 --> Router Class Initialized
ERROR - 2012-09-22 20:06:20 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:06:36 --> Config Class Initialized
DEBUG - 2012-09-22 20:06:36 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:06:36 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:06:36 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:06:36 --> URI Class Initialized
DEBUG - 2012-09-22 20:06:36 --> Router Class Initialized
ERROR - 2012-09-22 20:06:36 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:06:36 --> Config Class Initialized
DEBUG - 2012-09-22 20:06:36 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:06:36 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:06:36 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:06:36 --> URI Class Initialized
DEBUG - 2012-09-22 20:06:36 --> Router Class Initialized
ERROR - 2012-09-22 20:06:36 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:06:45 --> Config Class Initialized
DEBUG - 2012-09-22 20:06:45 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:06:45 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:06:45 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:06:45 --> URI Class Initialized
DEBUG - 2012-09-22 20:06:45 --> Router Class Initialized
ERROR - 2012-09-22 20:06:45 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:06:46 --> Config Class Initialized
DEBUG - 2012-09-22 20:06:46 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:06:46 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:06:46 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:06:46 --> URI Class Initialized
DEBUG - 2012-09-22 20:06:46 --> Router Class Initialized
ERROR - 2012-09-22 20:06:46 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:06:53 --> Config Class Initialized
DEBUG - 2012-09-22 20:06:53 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:06:53 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:06:53 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:06:53 --> URI Class Initialized
DEBUG - 2012-09-22 20:06:53 --> Router Class Initialized
ERROR - 2012-09-22 20:06:53 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:06:54 --> Config Class Initialized
DEBUG - 2012-09-22 20:06:54 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:06:54 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:06:54 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:06:54 --> URI Class Initialized
DEBUG - 2012-09-22 20:06:54 --> Router Class Initialized
ERROR - 2012-09-22 20:06:54 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:07:08 --> Config Class Initialized
DEBUG - 2012-09-22 20:07:08 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:07:08 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:07:08 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:07:08 --> URI Class Initialized
DEBUG - 2012-09-22 20:07:08 --> Router Class Initialized
ERROR - 2012-09-22 20:07:08 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:07:09 --> Config Class Initialized
DEBUG - 2012-09-22 20:07:09 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:07:09 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:07:09 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:07:09 --> URI Class Initialized
DEBUG - 2012-09-22 20:07:09 --> Router Class Initialized
ERROR - 2012-09-22 20:07:09 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:07:15 --> Config Class Initialized
DEBUG - 2012-09-22 20:07:15 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:07:15 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:07:15 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:07:15 --> URI Class Initialized
DEBUG - 2012-09-22 20:07:15 --> Router Class Initialized
ERROR - 2012-09-22 20:07:15 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:07:15 --> Config Class Initialized
DEBUG - 2012-09-22 20:07:15 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:07:15 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:07:15 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:07:15 --> URI Class Initialized
DEBUG - 2012-09-22 20:07:15 --> Router Class Initialized
ERROR - 2012-09-22 20:07:15 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:07:25 --> Config Class Initialized
DEBUG - 2012-09-22 20:07:25 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:07:25 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:07:25 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:07:25 --> URI Class Initialized
DEBUG - 2012-09-22 20:07:25 --> Router Class Initialized
ERROR - 2012-09-22 20:07:25 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:07:25 --> Config Class Initialized
DEBUG - 2012-09-22 20:07:25 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:07:25 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:07:25 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:07:25 --> URI Class Initialized
DEBUG - 2012-09-22 20:07:25 --> Router Class Initialized
ERROR - 2012-09-22 20:07:25 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:07:40 --> Config Class Initialized
DEBUG - 2012-09-22 20:07:40 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:07:40 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:07:40 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:07:40 --> URI Class Initialized
DEBUG - 2012-09-22 20:07:40 --> Router Class Initialized
ERROR - 2012-09-22 20:07:40 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:07:41 --> Config Class Initialized
DEBUG - 2012-09-22 20:07:41 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:07:41 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:07:41 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:07:41 --> URI Class Initialized
DEBUG - 2012-09-22 20:07:41 --> Router Class Initialized
ERROR - 2012-09-22 20:07:41 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:08:22 --> Config Class Initialized
DEBUG - 2012-09-22 20:08:22 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:08:22 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:08:22 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:08:22 --> URI Class Initialized
DEBUG - 2012-09-22 20:08:22 --> Router Class Initialized
ERROR - 2012-09-22 20:08:22 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:08:22 --> Config Class Initialized
DEBUG - 2012-09-22 20:08:22 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:08:22 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:08:22 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:08:22 --> URI Class Initialized
DEBUG - 2012-09-22 20:08:22 --> Router Class Initialized
ERROR - 2012-09-22 20:08:22 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:08:27 --> Config Class Initialized
DEBUG - 2012-09-22 20:08:27 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:08:27 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:08:27 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:08:27 --> URI Class Initialized
DEBUG - 2012-09-22 20:08:27 --> Router Class Initialized
ERROR - 2012-09-22 20:08:27 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:08:28 --> Config Class Initialized
DEBUG - 2012-09-22 20:08:28 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:08:28 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:08:28 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:08:28 --> URI Class Initialized
DEBUG - 2012-09-22 20:08:28 --> Router Class Initialized
ERROR - 2012-09-22 20:08:28 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:08:32 --> Config Class Initialized
DEBUG - 2012-09-22 20:08:32 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:08:32 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:08:32 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:08:32 --> URI Class Initialized
DEBUG - 2012-09-22 20:08:32 --> Router Class Initialized
ERROR - 2012-09-22 20:08:32 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:08:32 --> Config Class Initialized
DEBUG - 2012-09-22 20:08:32 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:08:32 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:08:32 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:08:32 --> URI Class Initialized
DEBUG - 2012-09-22 20:08:32 --> Router Class Initialized
ERROR - 2012-09-22 20:08:32 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:08:40 --> Config Class Initialized
DEBUG - 2012-09-22 20:08:40 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:08:40 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:08:40 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:08:40 --> URI Class Initialized
DEBUG - 2012-09-22 20:08:40 --> Router Class Initialized
ERROR - 2012-09-22 20:08:40 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:08:40 --> Config Class Initialized
DEBUG - 2012-09-22 20:08:40 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:08:40 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:08:40 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:08:40 --> URI Class Initialized
DEBUG - 2012-09-22 20:08:40 --> Router Class Initialized
ERROR - 2012-09-22 20:08:40 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:08:44 --> Config Class Initialized
DEBUG - 2012-09-22 20:08:44 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:08:44 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:08:44 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:08:44 --> URI Class Initialized
DEBUG - 2012-09-22 20:08:44 --> Router Class Initialized
ERROR - 2012-09-22 20:08:44 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:08:44 --> Config Class Initialized
DEBUG - 2012-09-22 20:08:44 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:08:44 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:08:44 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:08:44 --> URI Class Initialized
DEBUG - 2012-09-22 20:08:44 --> Router Class Initialized
ERROR - 2012-09-22 20:08:44 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:09:02 --> Config Class Initialized
DEBUG - 2012-09-22 20:09:02 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:09:02 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:09:02 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:09:02 --> URI Class Initialized
DEBUG - 2012-09-22 20:09:02 --> Router Class Initialized
ERROR - 2012-09-22 20:09:02 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:09:02 --> Config Class Initialized
DEBUG - 2012-09-22 20:09:02 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:09:02 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:09:02 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:09:02 --> URI Class Initialized
DEBUG - 2012-09-22 20:09:02 --> Router Class Initialized
ERROR - 2012-09-22 20:09:02 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:09:10 --> Config Class Initialized
DEBUG - 2012-09-22 20:09:10 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:09:10 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:09:10 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:09:10 --> URI Class Initialized
DEBUG - 2012-09-22 20:09:10 --> Router Class Initialized
ERROR - 2012-09-22 20:09:10 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:09:10 --> Config Class Initialized
DEBUG - 2012-09-22 20:09:10 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:09:10 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:09:10 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:09:10 --> URI Class Initialized
DEBUG - 2012-09-22 20:09:10 --> Router Class Initialized
ERROR - 2012-09-22 20:09:10 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:11:01 --> Config Class Initialized
DEBUG - 2012-09-22 20:11:01 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:11:01 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:11:01 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:11:01 --> URI Class Initialized
DEBUG - 2012-09-22 20:11:01 --> Router Class Initialized
ERROR - 2012-09-22 20:11:01 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:11:01 --> Config Class Initialized
DEBUG - 2012-09-22 20:11:01 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:11:01 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:11:01 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:11:01 --> URI Class Initialized
DEBUG - 2012-09-22 20:11:01 --> Router Class Initialized
ERROR - 2012-09-22 20:11:01 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:12:37 --> Config Class Initialized
DEBUG - 2012-09-22 20:12:37 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:12:37 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:12:37 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:12:37 --> URI Class Initialized
DEBUG - 2012-09-22 20:12:37 --> Router Class Initialized
ERROR - 2012-09-22 20:12:37 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:12:37 --> Config Class Initialized
DEBUG - 2012-09-22 20:12:37 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:12:37 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:12:37 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:12:37 --> URI Class Initialized
DEBUG - 2012-09-22 20:12:37 --> Router Class Initialized
ERROR - 2012-09-22 20:12:37 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:12:45 --> Config Class Initialized
DEBUG - 2012-09-22 20:12:45 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:12:45 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:12:45 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:12:45 --> URI Class Initialized
DEBUG - 2012-09-22 20:12:45 --> Router Class Initialized
ERROR - 2012-09-22 20:12:45 --> 404 Page Not Found --> js9.js
DEBUG - 2012-09-22 20:12:45 --> Config Class Initialized
DEBUG - 2012-09-22 20:12:45 --> Hooks Class Initialized
DEBUG - 2012-09-22 20:12:45 --> Utf8 Class Initialized
DEBUG - 2012-09-22 20:12:45 --> UTF-8 Support Enabled
DEBUG - 2012-09-22 20:12:45 --> URI Class Initialized
DEBUG - 2012-09-22 20:12:45 --> Router Class Initialized
ERROR - 2012-09-22 20:12:45 --> 404 Page Not Found --> js9.js
