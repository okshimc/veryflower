<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-08-26 04:32:21 --> Config Class Initialized
DEBUG - 2012-08-26 04:32:21 --> Hooks Class Initialized
DEBUG - 2012-08-26 04:32:21 --> Utf8 Class Initialized
DEBUG - 2012-08-26 04:32:21 --> UTF-8 Support Enabled
DEBUG - 2012-08-26 04:32:21 --> URI Class Initialized
DEBUG - 2012-08-26 04:32:21 --> Router Class Initialized
ERROR - 2012-08-26 04:32:21 --> 404 Page Not Found --> 137.swf
DEBUG - 2012-08-26 05:11:08 --> Config Class Initialized
DEBUG - 2012-08-26 05:11:08 --> Hooks Class Initialized
DEBUG - 2012-08-26 05:11:08 --> Utf8 Class Initialized
DEBUG - 2012-08-26 05:11:08 --> UTF-8 Support Enabled
DEBUG - 2012-08-26 05:11:08 --> URI Class Initialized
DEBUG - 2012-08-26 05:11:08 --> Router Class Initialized
ERROR - 2012-08-26 05:11:08 --> 404 Page Not Found --> tc.js
DEBUG - 2012-08-26 05:11:51 --> Config Class Initialized
DEBUG - 2012-08-26 05:11:51 --> Hooks Class Initialized
DEBUG - 2012-08-26 05:11:51 --> Utf8 Class Initialized
DEBUG - 2012-08-26 05:11:51 --> UTF-8 Support Enabled
DEBUG - 2012-08-26 05:11:51 --> URI Class Initialized
DEBUG - 2012-08-26 05:11:51 --> Router Class Initialized
ERROR - 2012-08-26 05:11:51 --> 404 Page Not Found --> tc.js
DEBUG - 2012-08-26 05:13:30 --> Config Class Initialized
DEBUG - 2012-08-26 05:13:30 --> Hooks Class Initialized
DEBUG - 2012-08-26 05:13:30 --> Utf8 Class Initialized
DEBUG - 2012-08-26 05:13:30 --> UTF-8 Support Enabled
DEBUG - 2012-08-26 05:13:30 --> URI Class Initialized
DEBUG - 2012-08-26 05:13:30 --> Router Class Initialized
ERROR - 2012-08-26 05:13:30 --> 404 Page Not Found --> tc.js
DEBUG - 2012-08-26 05:13:54 --> Config Class Initialized
DEBUG - 2012-08-26 05:13:54 --> Hooks Class Initialized
DEBUG - 2012-08-26 05:13:54 --> Utf8 Class Initialized
DEBUG - 2012-08-26 05:13:54 --> UTF-8 Support Enabled
DEBUG - 2012-08-26 05:13:54 --> URI Class Initialized
DEBUG - 2012-08-26 05:13:54 --> Router Class Initialized
ERROR - 2012-08-26 05:13:54 --> 404 Page Not Found --> tc.js
