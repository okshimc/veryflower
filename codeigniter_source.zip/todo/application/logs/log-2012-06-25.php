<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-06-25 15:04:41 --> Config Class Initialized
DEBUG - 2012-06-25 15:04:41 --> Hooks Class Initialized
DEBUG - 2012-06-25 15:04:41 --> Utf8 Class Initialized
DEBUG - 2012-06-25 15:04:41 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 15:04:41 --> URI Class Initialized
DEBUG - 2012-06-25 15:04:41 --> Router Class Initialized
DEBUG - 2012-06-25 15:04:41 --> Output Class Initialized
DEBUG - 2012-06-25 15:04:41 --> Security Class Initialized
DEBUG - 2012-06-25 15:04:41 --> Input Class Initialized
DEBUG - 2012-06-25 15:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 15:04:41 --> Language Class Initialized
DEBUG - 2012-06-25 15:04:41 --> Loader Class Initialized
DEBUG - 2012-06-25 15:04:41 --> Helper loaded: date_helper
DEBUG - 2012-06-25 15:04:41 --> Controller Class Initialized
DEBUG - 2012-06-25 15:04:41 --> Final output sent to browser
DEBUG - 2012-06-25 15:04:41 --> Total execution time: 0.1999
DEBUG - 2012-06-25 15:07:20 --> Config Class Initialized
DEBUG - 2012-06-25 15:07:20 --> Hooks Class Initialized
DEBUG - 2012-06-25 15:07:20 --> Utf8 Class Initialized
DEBUG - 2012-06-25 15:07:20 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 15:07:20 --> URI Class Initialized
DEBUG - 2012-06-25 15:07:20 --> Router Class Initialized
DEBUG - 2012-06-25 15:07:20 --> Output Class Initialized
DEBUG - 2012-06-25 15:07:20 --> Security Class Initialized
DEBUG - 2012-06-25 15:07:20 --> Input Class Initialized
DEBUG - 2012-06-25 15:07:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 15:07:20 --> Language Class Initialized
DEBUG - 2012-06-25 15:07:20 --> Loader Class Initialized
DEBUG - 2012-06-25 15:07:20 --> Helper loaded: date_helper
DEBUG - 2012-06-25 15:07:20 --> Controller Class Initialized
DEBUG - 2012-06-25 15:07:20 --> Final output sent to browser
DEBUG - 2012-06-25 15:07:20 --> Total execution time: 0.0234
DEBUG - 2012-06-25 15:07:24 --> Config Class Initialized
DEBUG - 2012-06-25 15:07:24 --> Hooks Class Initialized
DEBUG - 2012-06-25 15:07:24 --> Utf8 Class Initialized
DEBUG - 2012-06-25 15:07:24 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 15:07:24 --> URI Class Initialized
DEBUG - 2012-06-25 15:07:24 --> Router Class Initialized
DEBUG - 2012-06-25 15:07:24 --> Output Class Initialized
DEBUG - 2012-06-25 15:07:24 --> Security Class Initialized
DEBUG - 2012-06-25 15:07:24 --> Input Class Initialized
DEBUG - 2012-06-25 15:07:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 15:07:24 --> Language Class Initialized
DEBUG - 2012-06-25 15:07:24 --> Loader Class Initialized
DEBUG - 2012-06-25 15:07:24 --> Helper loaded: date_helper
DEBUG - 2012-06-25 15:07:24 --> Controller Class Initialized
DEBUG - 2012-06-25 15:07:24 --> Final output sent to browser
DEBUG - 2012-06-25 15:07:24 --> Total execution time: 0.0304
DEBUG - 2012-06-25 15:08:50 --> Config Class Initialized
DEBUG - 2012-06-25 15:08:50 --> Hooks Class Initialized
DEBUG - 2012-06-25 15:08:50 --> Utf8 Class Initialized
DEBUG - 2012-06-25 15:08:50 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 15:08:50 --> URI Class Initialized
DEBUG - 2012-06-25 15:08:50 --> Router Class Initialized
DEBUG - 2012-06-25 15:08:50 --> Output Class Initialized
DEBUG - 2012-06-25 15:08:50 --> Security Class Initialized
DEBUG - 2012-06-25 15:08:50 --> Input Class Initialized
DEBUG - 2012-06-25 15:08:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 15:08:50 --> Language Class Initialized
DEBUG - 2012-06-25 15:08:50 --> Loader Class Initialized
DEBUG - 2012-06-25 15:08:50 --> Helper loaded: date_helper
DEBUG - 2012-06-25 15:08:50 --> Controller Class Initialized
DEBUG - 2012-06-25 15:08:50 --> Final output sent to browser
DEBUG - 2012-06-25 15:08:50 --> Total execution time: 0.0292
DEBUG - 2012-06-25 15:08:53 --> Config Class Initialized
DEBUG - 2012-06-25 15:08:53 --> Hooks Class Initialized
DEBUG - 2012-06-25 15:08:53 --> Utf8 Class Initialized
DEBUG - 2012-06-25 15:08:53 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 15:08:53 --> URI Class Initialized
DEBUG - 2012-06-25 15:08:53 --> Router Class Initialized
DEBUG - 2012-06-25 15:08:53 --> Output Class Initialized
DEBUG - 2012-06-25 15:08:53 --> Security Class Initialized
DEBUG - 2012-06-25 15:08:53 --> Input Class Initialized
DEBUG - 2012-06-25 15:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 15:08:53 --> Language Class Initialized
DEBUG - 2012-06-25 15:08:53 --> Loader Class Initialized
DEBUG - 2012-06-25 15:08:53 --> Helper loaded: date_helper
DEBUG - 2012-06-25 15:08:53 --> Controller Class Initialized
DEBUG - 2012-06-25 15:08:53 --> Final output sent to browser
DEBUG - 2012-06-25 15:08:53 --> Total execution time: 0.0308
DEBUG - 2012-06-25 15:09:17 --> Config Class Initialized
DEBUG - 2012-06-25 15:09:17 --> Hooks Class Initialized
DEBUG - 2012-06-25 15:09:17 --> Utf8 Class Initialized
DEBUG - 2012-06-25 15:09:17 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 15:09:17 --> URI Class Initialized
DEBUG - 2012-06-25 15:09:17 --> Router Class Initialized
DEBUG - 2012-06-25 15:09:17 --> Output Class Initialized
DEBUG - 2012-06-25 15:09:17 --> Security Class Initialized
DEBUG - 2012-06-25 15:09:17 --> Input Class Initialized
DEBUG - 2012-06-25 15:09:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 15:09:17 --> Language Class Initialized
DEBUG - 2012-06-25 15:09:17 --> Loader Class Initialized
DEBUG - 2012-06-25 15:09:17 --> Helper loaded: date_helper
DEBUG - 2012-06-25 15:09:17 --> Controller Class Initialized
DEBUG - 2012-06-25 15:09:17 --> Final output sent to browser
DEBUG - 2012-06-25 15:09:17 --> Total execution time: 0.0275
DEBUG - 2012-06-25 15:09:20 --> Config Class Initialized
DEBUG - 2012-06-25 15:09:20 --> Hooks Class Initialized
DEBUG - 2012-06-25 15:09:20 --> Utf8 Class Initialized
DEBUG - 2012-06-25 15:09:20 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 15:09:20 --> URI Class Initialized
DEBUG - 2012-06-25 15:09:20 --> Router Class Initialized
DEBUG - 2012-06-25 15:09:20 --> Output Class Initialized
DEBUG - 2012-06-25 15:09:20 --> Security Class Initialized
DEBUG - 2012-06-25 15:09:20 --> Input Class Initialized
DEBUG - 2012-06-25 15:09:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 15:09:20 --> Language Class Initialized
DEBUG - 2012-06-25 15:09:20 --> Loader Class Initialized
DEBUG - 2012-06-25 15:09:20 --> Helper loaded: date_helper
DEBUG - 2012-06-25 15:09:20 --> Controller Class Initialized
DEBUG - 2012-06-25 15:09:20 --> Final output sent to browser
DEBUG - 2012-06-25 15:09:20 --> Total execution time: 0.0323
DEBUG - 2012-06-25 15:09:23 --> Config Class Initialized
DEBUG - 2012-06-25 15:09:23 --> Hooks Class Initialized
DEBUG - 2012-06-25 15:09:23 --> Utf8 Class Initialized
DEBUG - 2012-06-25 15:09:23 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 15:09:23 --> URI Class Initialized
DEBUG - 2012-06-25 15:09:23 --> Router Class Initialized
DEBUG - 2012-06-25 15:09:24 --> Output Class Initialized
DEBUG - 2012-06-25 15:09:24 --> Security Class Initialized
DEBUG - 2012-06-25 15:09:24 --> Input Class Initialized
DEBUG - 2012-06-25 15:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 15:09:24 --> Language Class Initialized
DEBUG - 2012-06-25 15:09:24 --> Loader Class Initialized
DEBUG - 2012-06-25 15:09:24 --> Helper loaded: date_helper
DEBUG - 2012-06-25 15:09:24 --> Controller Class Initialized
DEBUG - 2012-06-25 15:09:24 --> Final output sent to browser
DEBUG - 2012-06-25 15:09:24 --> Total execution time: 0.0282
DEBUG - 2012-06-25 15:09:26 --> Config Class Initialized
DEBUG - 2012-06-25 15:09:26 --> Hooks Class Initialized
DEBUG - 2012-06-25 15:09:26 --> Utf8 Class Initialized
DEBUG - 2012-06-25 15:09:26 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 15:09:26 --> URI Class Initialized
DEBUG - 2012-06-25 15:09:26 --> Router Class Initialized
DEBUG - 2012-06-25 15:09:26 --> Output Class Initialized
DEBUG - 2012-06-25 15:09:26 --> Security Class Initialized
DEBUG - 2012-06-25 15:09:26 --> Input Class Initialized
DEBUG - 2012-06-25 15:09:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 15:09:26 --> Language Class Initialized
DEBUG - 2012-06-25 15:09:26 --> Loader Class Initialized
DEBUG - 2012-06-25 15:09:26 --> Helper loaded: date_helper
DEBUG - 2012-06-25 15:09:26 --> Controller Class Initialized
DEBUG - 2012-06-25 15:09:26 --> Final output sent to browser
DEBUG - 2012-06-25 15:09:26 --> Total execution time: 0.0306
DEBUG - 2012-06-25 15:09:51 --> Config Class Initialized
DEBUG - 2012-06-25 15:09:51 --> Hooks Class Initialized
DEBUG - 2012-06-25 15:09:51 --> Utf8 Class Initialized
DEBUG - 2012-06-25 15:09:51 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 15:09:51 --> URI Class Initialized
DEBUG - 2012-06-25 15:09:51 --> Router Class Initialized
DEBUG - 2012-06-25 15:09:51 --> Output Class Initialized
DEBUG - 2012-06-25 15:09:51 --> Security Class Initialized
DEBUG - 2012-06-25 15:09:51 --> Input Class Initialized
DEBUG - 2012-06-25 15:09:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 15:09:51 --> Language Class Initialized
DEBUG - 2012-06-25 15:09:51 --> Loader Class Initialized
DEBUG - 2012-06-25 15:09:51 --> Helper loaded: date_helper
DEBUG - 2012-06-25 15:09:51 --> Controller Class Initialized
DEBUG - 2012-06-25 15:09:51 --> Final output sent to browser
DEBUG - 2012-06-25 15:09:51 --> Total execution time: 0.0247
DEBUG - 2012-06-25 15:09:54 --> Config Class Initialized
DEBUG - 2012-06-25 15:09:54 --> Hooks Class Initialized
DEBUG - 2012-06-25 15:09:54 --> Utf8 Class Initialized
DEBUG - 2012-06-25 15:09:54 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 15:09:54 --> URI Class Initialized
DEBUG - 2012-06-25 15:09:54 --> Router Class Initialized
DEBUG - 2012-06-25 15:09:54 --> Output Class Initialized
DEBUG - 2012-06-25 15:09:54 --> Security Class Initialized
DEBUG - 2012-06-25 15:09:54 --> Input Class Initialized
DEBUG - 2012-06-25 15:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 15:09:54 --> Language Class Initialized
DEBUG - 2012-06-25 15:09:54 --> Loader Class Initialized
DEBUG - 2012-06-25 15:09:54 --> Helper loaded: date_helper
DEBUG - 2012-06-25 15:09:54 --> Controller Class Initialized
DEBUG - 2012-06-25 15:09:54 --> Final output sent to browser
DEBUG - 2012-06-25 15:09:54 --> Total execution time: 0.0277
DEBUG - 2012-06-25 15:12:32 --> Config Class Initialized
DEBUG - 2012-06-25 15:12:32 --> Hooks Class Initialized
DEBUG - 2012-06-25 15:12:32 --> Utf8 Class Initialized
DEBUG - 2012-06-25 15:12:32 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 15:12:32 --> URI Class Initialized
DEBUG - 2012-06-25 15:12:32 --> Router Class Initialized
DEBUG - 2012-06-25 15:12:32 --> Output Class Initialized
DEBUG - 2012-06-25 15:12:32 --> Security Class Initialized
DEBUG - 2012-06-25 15:12:32 --> Input Class Initialized
DEBUG - 2012-06-25 15:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 15:12:32 --> Language Class Initialized
DEBUG - 2012-06-25 15:12:32 --> Loader Class Initialized
DEBUG - 2012-06-25 15:12:32 --> Helper loaded: date_helper
DEBUG - 2012-06-25 15:12:32 --> Controller Class Initialized
DEBUG - 2012-06-25 15:12:32 --> Final output sent to browser
DEBUG - 2012-06-25 15:12:32 --> Total execution time: 0.0275
DEBUG - 2012-06-25 15:13:09 --> Config Class Initialized
DEBUG - 2012-06-25 15:13:09 --> Hooks Class Initialized
DEBUG - 2012-06-25 15:13:09 --> Utf8 Class Initialized
DEBUG - 2012-06-25 15:13:09 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 15:13:09 --> URI Class Initialized
DEBUG - 2012-06-25 15:13:09 --> Router Class Initialized
DEBUG - 2012-06-25 15:13:09 --> Output Class Initialized
DEBUG - 2012-06-25 15:13:09 --> Security Class Initialized
DEBUG - 2012-06-25 15:13:09 --> Input Class Initialized
DEBUG - 2012-06-25 15:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 15:13:09 --> Language Class Initialized
DEBUG - 2012-06-25 15:13:09 --> Loader Class Initialized
DEBUG - 2012-06-25 15:13:09 --> Helper loaded: date_helper
DEBUG - 2012-06-25 15:13:09 --> Controller Class Initialized
DEBUG - 2012-06-25 15:13:09 --> Final output sent to browser
DEBUG - 2012-06-25 15:13:09 --> Total execution time: 0.0208
DEBUG - 2012-06-25 15:13:11 --> Config Class Initialized
DEBUG - 2012-06-25 15:13:11 --> Hooks Class Initialized
DEBUG - 2012-06-25 15:13:11 --> Utf8 Class Initialized
DEBUG - 2012-06-25 15:13:11 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 15:13:11 --> URI Class Initialized
DEBUG - 2012-06-25 15:13:11 --> Router Class Initialized
DEBUG - 2012-06-25 15:13:11 --> Output Class Initialized
DEBUG - 2012-06-25 15:13:11 --> Security Class Initialized
DEBUG - 2012-06-25 15:13:11 --> Input Class Initialized
DEBUG - 2012-06-25 15:13:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 15:13:11 --> Language Class Initialized
DEBUG - 2012-06-25 15:13:11 --> Loader Class Initialized
DEBUG - 2012-06-25 15:13:11 --> Helper loaded: date_helper
DEBUG - 2012-06-25 15:13:11 --> Controller Class Initialized
DEBUG - 2012-06-25 15:13:11 --> Final output sent to browser
DEBUG - 2012-06-25 15:13:11 --> Total execution time: 0.0384
DEBUG - 2012-06-25 15:14:07 --> Config Class Initialized
DEBUG - 2012-06-25 15:14:07 --> Hooks Class Initialized
DEBUG - 2012-06-25 15:14:07 --> Utf8 Class Initialized
DEBUG - 2012-06-25 15:14:07 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 15:14:07 --> URI Class Initialized
DEBUG - 2012-06-25 15:14:07 --> Router Class Initialized
DEBUG - 2012-06-25 15:14:07 --> Output Class Initialized
DEBUG - 2012-06-25 15:14:07 --> Security Class Initialized
DEBUG - 2012-06-25 15:14:07 --> Input Class Initialized
DEBUG - 2012-06-25 15:14:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 15:14:07 --> Language Class Initialized
DEBUG - 2012-06-25 15:14:07 --> Loader Class Initialized
DEBUG - 2012-06-25 15:14:07 --> Helper loaded: date_helper
DEBUG - 2012-06-25 15:14:07 --> Controller Class Initialized
DEBUG - 2012-06-25 15:14:07 --> Final output sent to browser
DEBUG - 2012-06-25 15:14:07 --> Total execution time: 0.0244
DEBUG - 2012-06-25 15:14:09 --> Config Class Initialized
DEBUG - 2012-06-25 15:14:09 --> Hooks Class Initialized
DEBUG - 2012-06-25 15:14:09 --> Utf8 Class Initialized
DEBUG - 2012-06-25 15:14:09 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 15:14:09 --> URI Class Initialized
DEBUG - 2012-06-25 15:14:09 --> Router Class Initialized
DEBUG - 2012-06-25 15:14:09 --> Output Class Initialized
DEBUG - 2012-06-25 15:14:09 --> Security Class Initialized
DEBUG - 2012-06-25 15:14:09 --> Input Class Initialized
DEBUG - 2012-06-25 15:14:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 15:14:09 --> Language Class Initialized
DEBUG - 2012-06-25 15:14:09 --> Loader Class Initialized
DEBUG - 2012-06-25 15:14:09 --> Helper loaded: date_helper
DEBUG - 2012-06-25 15:14:09 --> Controller Class Initialized
DEBUG - 2012-06-25 15:14:09 --> Final output sent to browser
DEBUG - 2012-06-25 15:14:09 --> Total execution time: 0.0393
DEBUG - 2012-06-25 15:14:17 --> Config Class Initialized
DEBUG - 2012-06-25 15:14:17 --> Hooks Class Initialized
DEBUG - 2012-06-25 15:14:17 --> Utf8 Class Initialized
DEBUG - 2012-06-25 15:14:17 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 15:14:17 --> URI Class Initialized
DEBUG - 2012-06-25 15:14:17 --> Router Class Initialized
DEBUG - 2012-06-25 15:14:17 --> Output Class Initialized
DEBUG - 2012-06-25 15:14:17 --> Security Class Initialized
DEBUG - 2012-06-25 15:14:17 --> Input Class Initialized
DEBUG - 2012-06-25 15:14:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 15:14:17 --> Language Class Initialized
DEBUG - 2012-06-25 15:14:17 --> Loader Class Initialized
DEBUG - 2012-06-25 15:14:17 --> Helper loaded: date_helper
DEBUG - 2012-06-25 15:14:17 --> Controller Class Initialized
DEBUG - 2012-06-25 15:14:17 --> Final output sent to browser
DEBUG - 2012-06-25 15:14:17 --> Total execution time: 0.0285
DEBUG - 2012-06-25 15:14:19 --> Config Class Initialized
DEBUG - 2012-06-25 15:14:19 --> Hooks Class Initialized
DEBUG - 2012-06-25 15:14:19 --> Utf8 Class Initialized
DEBUG - 2012-06-25 15:14:19 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 15:14:19 --> URI Class Initialized
DEBUG - 2012-06-25 15:14:19 --> Router Class Initialized
DEBUG - 2012-06-25 15:14:19 --> Output Class Initialized
DEBUG - 2012-06-25 15:14:19 --> Security Class Initialized
DEBUG - 2012-06-25 15:14:19 --> Input Class Initialized
DEBUG - 2012-06-25 15:14:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 15:14:19 --> Language Class Initialized
DEBUG - 2012-06-25 15:14:19 --> Loader Class Initialized
DEBUG - 2012-06-25 15:14:19 --> Helper loaded: date_helper
DEBUG - 2012-06-25 15:14:19 --> Controller Class Initialized
DEBUG - 2012-06-25 15:14:19 --> Final output sent to browser
DEBUG - 2012-06-25 15:14:19 --> Total execution time: 0.0300
