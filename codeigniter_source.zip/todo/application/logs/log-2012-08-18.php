<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-08-18 14:08:46 --> Config Class Initialized
DEBUG - 2012-08-18 14:08:46 --> Hooks Class Initialized
DEBUG - 2012-08-18 14:08:46 --> Utf8 Class Initialized
DEBUG - 2012-08-18 14:08:46 --> UTF-8 Support Enabled
DEBUG - 2012-08-18 14:08:46 --> URI Class Initialized
DEBUG - 2012-08-18 14:08:46 --> Router Class Initialized
ERROR - 2012-08-18 14:08:46 --> 404 Page Not Found --> admin
