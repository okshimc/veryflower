<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-07-10 14:06:22 --> Config Class Initialized
DEBUG - 2012-07-10 14:06:22 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:06:22 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:06:22 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:06:22 --> URI Class Initialized
DEBUG - 2012-07-10 14:06:22 --> Router Class Initialized
DEBUG - 2012-07-10 14:06:22 --> Output Class Initialized
DEBUG - 2012-07-10 14:06:22 --> Security Class Initialized
DEBUG - 2012-07-10 14:06:22 --> Input Class Initialized
DEBUG - 2012-07-10 14:06:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:06:22 --> Language Class Initialized
DEBUG - 2012-07-10 14:06:22 --> Loader Class Initialized
DEBUG - 2012-07-10 14:06:22 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:06:22 --> Controller Class Initialized
DEBUG - 2012-07-10 14:06:22 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:06:22 --> Model Class Initialized
DEBUG - 2012-07-10 14:06:22 --> Model Class Initialized
DEBUG - 2012-07-10 14:06:22 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:06:22 --> Pagination Class Initialized
DEBUG - 2012-07-10 14:06:22 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-10 14:06:22 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-10 14:06:22 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-10 14:06:23 --> Helper loaded: text_helper
DEBUG - 2012-07-10 14:06:23 --> Final output sent to browser
DEBUG - 2012-07-10 14:06:23 --> Total execution time: 0.2839
DEBUG - 2012-07-10 14:06:28 --> Config Class Initialized
DEBUG - 2012-07-10 14:06:28 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:06:28 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:06:28 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:06:28 --> URI Class Initialized
DEBUG - 2012-07-10 14:06:28 --> Router Class Initialized
DEBUG - 2012-07-10 14:06:28 --> Output Class Initialized
DEBUG - 2012-07-10 14:06:28 --> Security Class Initialized
DEBUG - 2012-07-10 14:06:28 --> Input Class Initialized
DEBUG - 2012-07-10 14:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:06:28 --> Language Class Initialized
DEBUG - 2012-07-10 14:06:28 --> Loader Class Initialized
DEBUG - 2012-07-10 14:06:28 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:06:28 --> Controller Class Initialized
DEBUG - 2012-07-10 14:06:28 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:06:28 --> Model Class Initialized
DEBUG - 2012-07-10 14:06:28 --> Model Class Initialized
DEBUG - 2012-07-10 14:06:28 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:06:28 --> File loaded: application/views/board/write_v.php
DEBUG - 2012-07-10 14:06:28 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-10 14:06:28 --> Final output sent to browser
DEBUG - 2012-07-10 14:06:28 --> Total execution time: 0.0605
DEBUG - 2012-07-10 14:06:47 --> Config Class Initialized
DEBUG - 2012-07-10 14:06:47 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:06:47 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:06:47 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:06:47 --> URI Class Initialized
DEBUG - 2012-07-10 14:06:47 --> Router Class Initialized
DEBUG - 2012-07-10 14:06:47 --> Output Class Initialized
DEBUG - 2012-07-10 14:06:47 --> Security Class Initialized
DEBUG - 2012-07-10 14:06:47 --> Input Class Initialized
DEBUG - 2012-07-10 14:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:06:47 --> Language Class Initialized
DEBUG - 2012-07-10 14:06:47 --> Loader Class Initialized
DEBUG - 2012-07-10 14:06:47 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:06:47 --> Controller Class Initialized
DEBUG - 2012-07-10 14:06:47 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:06:47 --> Model Class Initialized
DEBUG - 2012-07-10 14:06:47 --> Model Class Initialized
DEBUG - 2012-07-10 14:06:47 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:06:47 --> Helper loaded: alert_helper
ERROR - 2012-07-10 14:06:47 --> Severity: Notice  --> Undefined offset: 4 E:\html\application\controllers\board.php 209
DEBUG - 2012-07-10 14:06:47 --> XSS Filtering completed
DEBUG - 2012-07-10 14:06:47 --> XSS Filtering completed
DEBUG - 2012-07-10 14:06:47 --> XSS Filtering completed
DEBUG - 2012-07-10 14:07:32 --> Config Class Initialized
DEBUG - 2012-07-10 14:07:32 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:07:32 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:07:32 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:07:32 --> URI Class Initialized
DEBUG - 2012-07-10 14:07:32 --> Router Class Initialized
DEBUG - 2012-07-10 14:07:32 --> Output Class Initialized
DEBUG - 2012-07-10 14:07:32 --> Security Class Initialized
DEBUG - 2012-07-10 14:07:32 --> Input Class Initialized
DEBUG - 2012-07-10 14:07:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:07:32 --> Language Class Initialized
DEBUG - 2012-07-10 14:07:32 --> Loader Class Initialized
DEBUG - 2012-07-10 14:07:32 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:07:32 --> Controller Class Initialized
DEBUG - 2012-07-10 14:07:32 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:07:32 --> Model Class Initialized
DEBUG - 2012-07-10 14:07:32 --> Model Class Initialized
DEBUG - 2012-07-10 14:07:32 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:07:32 --> Pagination Class Initialized
DEBUG - 2012-07-10 14:07:32 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-10 14:07:32 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-10 14:07:32 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-10 14:07:32 --> Helper loaded: text_helper
DEBUG - 2012-07-10 14:07:32 --> Final output sent to browser
DEBUG - 2012-07-10 14:07:32 --> Total execution time: 0.0443
DEBUG - 2012-07-10 14:07:35 --> Config Class Initialized
DEBUG - 2012-07-10 14:07:35 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:07:35 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:07:35 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:07:35 --> URI Class Initialized
DEBUG - 2012-07-10 14:07:35 --> Router Class Initialized
DEBUG - 2012-07-10 14:07:35 --> Output Class Initialized
DEBUG - 2012-07-10 14:07:35 --> Security Class Initialized
DEBUG - 2012-07-10 14:07:35 --> Input Class Initialized
DEBUG - 2012-07-10 14:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:07:35 --> Language Class Initialized
DEBUG - 2012-07-10 14:07:35 --> Loader Class Initialized
DEBUG - 2012-07-10 14:07:35 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:07:35 --> Controller Class Initialized
DEBUG - 2012-07-10 14:07:35 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:07:35 --> Model Class Initialized
DEBUG - 2012-07-10 14:07:35 --> Model Class Initialized
DEBUG - 2012-07-10 14:07:35 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:07:35 --> File loaded: application/views/board/write_v.php
DEBUG - 2012-07-10 14:07:35 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-10 14:07:35 --> Final output sent to browser
DEBUG - 2012-07-10 14:07:35 --> Total execution time: 0.0377
DEBUG - 2012-07-10 14:07:50 --> Config Class Initialized
DEBUG - 2012-07-10 14:07:50 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:07:50 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:07:50 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:07:50 --> URI Class Initialized
DEBUG - 2012-07-10 14:07:50 --> Router Class Initialized
DEBUG - 2012-07-10 14:07:50 --> Output Class Initialized
DEBUG - 2012-07-10 14:07:50 --> Security Class Initialized
DEBUG - 2012-07-10 14:07:50 --> Input Class Initialized
DEBUG - 2012-07-10 14:07:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:07:50 --> Language Class Initialized
DEBUG - 2012-07-10 14:07:50 --> Loader Class Initialized
DEBUG - 2012-07-10 14:07:50 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:07:50 --> Controller Class Initialized
DEBUG - 2012-07-10 14:07:50 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:07:50 --> Model Class Initialized
DEBUG - 2012-07-10 14:07:50 --> Model Class Initialized
DEBUG - 2012-07-10 14:07:50 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:07:50 --> Helper loaded: alert_helper
ERROR - 2012-07-10 14:07:50 --> Severity: Notice  --> Undefined offset: 4 E:\html\application\controllers\board.php 209
DEBUG - 2012-07-10 14:07:50 --> XSS Filtering completed
DEBUG - 2012-07-10 14:07:50 --> XSS Filtering completed
DEBUG - 2012-07-10 14:07:50 --> XSS Filtering completed
DEBUG - 2012-07-10 14:08:08 --> Config Class Initialized
DEBUG - 2012-07-10 14:08:08 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:08:08 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:08:08 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:08:08 --> URI Class Initialized
DEBUG - 2012-07-10 14:08:08 --> Router Class Initialized
DEBUG - 2012-07-10 14:08:08 --> Output Class Initialized
DEBUG - 2012-07-10 14:08:08 --> Security Class Initialized
DEBUG - 2012-07-10 14:08:08 --> Input Class Initialized
DEBUG - 2012-07-10 14:08:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:08:08 --> Language Class Initialized
DEBUG - 2012-07-10 14:08:08 --> Loader Class Initialized
DEBUG - 2012-07-10 14:08:08 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:08:08 --> Controller Class Initialized
DEBUG - 2012-07-10 14:08:08 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:08:08 --> Model Class Initialized
DEBUG - 2012-07-10 14:08:08 --> Model Class Initialized
DEBUG - 2012-07-10 14:08:08 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:08:08 --> Pagination Class Initialized
DEBUG - 2012-07-10 14:08:08 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-10 14:08:08 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-10 14:08:08 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-10 14:08:08 --> Helper loaded: text_helper
DEBUG - 2012-07-10 14:08:08 --> Final output sent to browser
DEBUG - 2012-07-10 14:08:08 --> Total execution time: 0.0417
DEBUG - 2012-07-10 14:08:09 --> Config Class Initialized
DEBUG - 2012-07-10 14:08:09 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:08:09 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:08:09 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:08:09 --> URI Class Initialized
DEBUG - 2012-07-10 14:08:09 --> Router Class Initialized
DEBUG - 2012-07-10 14:08:09 --> Output Class Initialized
DEBUG - 2012-07-10 14:08:09 --> Security Class Initialized
DEBUG - 2012-07-10 14:08:09 --> Input Class Initialized
DEBUG - 2012-07-10 14:08:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:08:09 --> Language Class Initialized
DEBUG - 2012-07-10 14:08:09 --> Loader Class Initialized
DEBUG - 2012-07-10 14:08:09 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:08:09 --> Controller Class Initialized
DEBUG - 2012-07-10 14:08:09 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:08:09 --> Model Class Initialized
DEBUG - 2012-07-10 14:08:09 --> Model Class Initialized
DEBUG - 2012-07-10 14:08:09 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:08:09 --> File loaded: application/views/board/write_v.php
DEBUG - 2012-07-10 14:08:09 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-10 14:08:09 --> Final output sent to browser
DEBUG - 2012-07-10 14:08:09 --> Total execution time: 0.0514
DEBUG - 2012-07-10 14:08:18 --> Config Class Initialized
DEBUG - 2012-07-10 14:08:18 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:08:18 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:08:18 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:08:18 --> URI Class Initialized
DEBUG - 2012-07-10 14:08:18 --> Router Class Initialized
DEBUG - 2012-07-10 14:08:18 --> Output Class Initialized
DEBUG - 2012-07-10 14:08:18 --> Security Class Initialized
DEBUG - 2012-07-10 14:08:18 --> Input Class Initialized
DEBUG - 2012-07-10 14:08:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:08:18 --> Language Class Initialized
DEBUG - 2012-07-10 14:08:18 --> Loader Class Initialized
DEBUG - 2012-07-10 14:08:18 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:08:18 --> Controller Class Initialized
DEBUG - 2012-07-10 14:08:18 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:08:18 --> Model Class Initialized
DEBUG - 2012-07-10 14:08:18 --> Model Class Initialized
DEBUG - 2012-07-10 14:08:18 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:08:18 --> Helper loaded: alert_helper
ERROR - 2012-07-10 14:08:18 --> Severity: Notice  --> Undefined offset: 4 E:\html\application\controllers\board.php 273
DEBUG - 2012-07-10 14:08:18 --> XSS Filtering completed
DEBUG - 2012-07-10 14:08:18 --> XSS Filtering completed
DEBUG - 2012-07-10 14:08:18 --> XSS Filtering completed
DEBUG - 2012-07-10 14:08:57 --> Config Class Initialized
DEBUG - 2012-07-10 14:08:57 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:08:57 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:08:57 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:08:57 --> URI Class Initialized
DEBUG - 2012-07-10 14:08:57 --> Router Class Initialized
DEBUG - 2012-07-10 14:08:57 --> Output Class Initialized
DEBUG - 2012-07-10 14:08:57 --> Security Class Initialized
DEBUG - 2012-07-10 14:08:57 --> Input Class Initialized
DEBUG - 2012-07-10 14:08:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:08:57 --> Language Class Initialized
DEBUG - 2012-07-10 14:08:57 --> Loader Class Initialized
DEBUG - 2012-07-10 14:08:57 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:08:57 --> Controller Class Initialized
DEBUG - 2012-07-10 14:08:57 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:08:57 --> Model Class Initialized
DEBUG - 2012-07-10 14:08:57 --> Model Class Initialized
DEBUG - 2012-07-10 14:08:57 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:08:57 --> Pagination Class Initialized
DEBUG - 2012-07-10 14:08:57 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-10 14:08:57 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-10 14:08:57 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-10 14:08:57 --> Helper loaded: text_helper
DEBUG - 2012-07-10 14:08:57 --> Final output sent to browser
DEBUG - 2012-07-10 14:08:57 --> Total execution time: 0.0529
DEBUG - 2012-07-10 14:09:01 --> Config Class Initialized
DEBUG - 2012-07-10 14:09:01 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:09:01 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:09:01 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:09:01 --> URI Class Initialized
DEBUG - 2012-07-10 14:09:01 --> Router Class Initialized
DEBUG - 2012-07-10 14:09:01 --> Output Class Initialized
DEBUG - 2012-07-10 14:09:01 --> Security Class Initialized
DEBUG - 2012-07-10 14:09:01 --> Input Class Initialized
DEBUG - 2012-07-10 14:09:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:09:01 --> Language Class Initialized
DEBUG - 2012-07-10 14:09:01 --> Loader Class Initialized
DEBUG - 2012-07-10 14:09:01 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:09:01 --> Controller Class Initialized
DEBUG - 2012-07-10 14:09:01 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:09:01 --> Model Class Initialized
DEBUG - 2012-07-10 14:09:01 --> Model Class Initialized
DEBUG - 2012-07-10 14:09:01 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:09:01 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-07-10 14:09:01 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-10 14:09:01 --> Final output sent to browser
DEBUG - 2012-07-10 14:09:01 --> Total execution time: 0.0587
DEBUG - 2012-07-10 14:09:04 --> Config Class Initialized
DEBUG - 2012-07-10 14:09:04 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:09:04 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:09:04 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:09:04 --> URI Class Initialized
DEBUG - 2012-07-10 14:09:04 --> Router Class Initialized
DEBUG - 2012-07-10 14:09:04 --> Output Class Initialized
DEBUG - 2012-07-10 14:09:04 --> Security Class Initialized
DEBUG - 2012-07-10 14:09:04 --> Input Class Initialized
DEBUG - 2012-07-10 14:09:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:09:04 --> Language Class Initialized
DEBUG - 2012-07-10 14:09:04 --> Loader Class Initialized
DEBUG - 2012-07-10 14:09:04 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:09:04 --> Controller Class Initialized
DEBUG - 2012-07-10 14:09:04 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:09:04 --> Model Class Initialized
DEBUG - 2012-07-10 14:09:04 --> Model Class Initialized
DEBUG - 2012-07-10 14:09:04 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:09:04 --> Pagination Class Initialized
DEBUG - 2012-07-10 14:09:04 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-10 14:09:04 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-10 14:09:04 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-10 14:09:04 --> Helper loaded: text_helper
DEBUG - 2012-07-10 14:09:04 --> Final output sent to browser
DEBUG - 2012-07-10 14:09:04 --> Total execution time: 0.0735
DEBUG - 2012-07-10 14:10:02 --> Config Class Initialized
DEBUG - 2012-07-10 14:10:02 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:10:02 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:10:02 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:10:02 --> URI Class Initialized
DEBUG - 2012-07-10 14:10:02 --> Router Class Initialized
DEBUG - 2012-07-10 14:10:02 --> Output Class Initialized
DEBUG - 2012-07-10 14:10:02 --> Security Class Initialized
DEBUG - 2012-07-10 14:10:02 --> Input Class Initialized
DEBUG - 2012-07-10 14:10:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:10:02 --> Language Class Initialized
DEBUG - 2012-07-10 14:10:02 --> Loader Class Initialized
DEBUG - 2012-07-10 14:10:02 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:10:02 --> Controller Class Initialized
DEBUG - 2012-07-10 14:10:02 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:10:02 --> Model Class Initialized
DEBUG - 2012-07-10 14:10:02 --> Model Class Initialized
DEBUG - 2012-07-10 14:10:02 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:10:02 --> File loaded: application/views/board/write_v.php
DEBUG - 2012-07-10 14:10:02 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-10 14:10:02 --> Final output sent to browser
DEBUG - 2012-07-10 14:10:02 --> Total execution time: 0.0432
DEBUG - 2012-07-10 14:10:22 --> Config Class Initialized
DEBUG - 2012-07-10 14:10:22 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:10:22 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:10:22 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:10:22 --> URI Class Initialized
DEBUG - 2012-07-10 14:10:22 --> Router Class Initialized
DEBUG - 2012-07-10 14:10:22 --> Output Class Initialized
DEBUG - 2012-07-10 14:10:22 --> Security Class Initialized
DEBUG - 2012-07-10 14:10:22 --> Input Class Initialized
DEBUG - 2012-07-10 14:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:10:22 --> Language Class Initialized
DEBUG - 2012-07-10 14:10:22 --> Loader Class Initialized
DEBUG - 2012-07-10 14:10:22 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:10:22 --> Controller Class Initialized
DEBUG - 2012-07-10 14:10:22 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:10:22 --> Model Class Initialized
DEBUG - 2012-07-10 14:10:22 --> Model Class Initialized
DEBUG - 2012-07-10 14:10:22 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:10:22 --> Helper loaded: alert_helper
DEBUG - 2012-07-10 14:10:22 --> XSS Filtering completed
DEBUG - 2012-07-10 14:10:22 --> XSS Filtering completed
DEBUG - 2012-07-10 14:10:22 --> XSS Filtering completed
DEBUG - 2012-07-10 14:10:23 --> Config Class Initialized
DEBUG - 2012-07-10 14:10:23 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:10:23 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:10:23 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:10:23 --> URI Class Initialized
DEBUG - 2012-07-10 14:10:23 --> Router Class Initialized
DEBUG - 2012-07-10 14:10:23 --> Output Class Initialized
DEBUG - 2012-07-10 14:10:23 --> Security Class Initialized
DEBUG - 2012-07-10 14:10:23 --> Input Class Initialized
DEBUG - 2012-07-10 14:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:10:23 --> Language Class Initialized
DEBUG - 2012-07-10 14:10:23 --> Loader Class Initialized
DEBUG - 2012-07-10 14:10:23 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:10:23 --> Controller Class Initialized
DEBUG - 2012-07-10 14:10:23 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:10:23 --> Model Class Initialized
DEBUG - 2012-07-10 14:10:23 --> Model Class Initialized
DEBUG - 2012-07-10 14:10:23 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:10:23 --> Pagination Class Initialized
DEBUG - 2012-07-10 14:10:23 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-10 14:10:23 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-10 14:10:23 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-10 14:10:23 --> Helper loaded: text_helper
DEBUG - 2012-07-10 14:10:23 --> Final output sent to browser
DEBUG - 2012-07-10 14:10:23 --> Total execution time: 0.0398
DEBUG - 2012-07-10 14:11:52 --> Config Class Initialized
DEBUG - 2012-07-10 14:11:52 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:11:52 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:11:52 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:11:52 --> URI Class Initialized
DEBUG - 2012-07-10 14:11:52 --> Router Class Initialized
DEBUG - 2012-07-10 14:11:52 --> Output Class Initialized
DEBUG - 2012-07-10 14:11:52 --> Security Class Initialized
DEBUG - 2012-07-10 14:11:52 --> Input Class Initialized
DEBUG - 2012-07-10 14:11:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:11:52 --> Language Class Initialized
DEBUG - 2012-07-10 14:11:52 --> Loader Class Initialized
DEBUG - 2012-07-10 14:11:52 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:11:52 --> Controller Class Initialized
DEBUG - 2012-07-10 14:11:52 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:11:52 --> Model Class Initialized
DEBUG - 2012-07-10 14:11:52 --> Model Class Initialized
DEBUG - 2012-07-10 14:11:52 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:11:52 --> File loaded: application/views/board/write_v.php
DEBUG - 2012-07-10 14:11:52 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-10 14:11:52 --> Final output sent to browser
DEBUG - 2012-07-10 14:11:52 --> Total execution time: 0.0553
DEBUG - 2012-07-10 14:11:58 --> Config Class Initialized
DEBUG - 2012-07-10 14:11:58 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:11:58 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:11:58 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:11:58 --> URI Class Initialized
DEBUG - 2012-07-10 14:11:58 --> Router Class Initialized
DEBUG - 2012-07-10 14:11:58 --> Output Class Initialized
DEBUG - 2012-07-10 14:11:58 --> Security Class Initialized
DEBUG - 2012-07-10 14:11:58 --> Input Class Initialized
DEBUG - 2012-07-10 14:11:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:11:58 --> Language Class Initialized
DEBUG - 2012-07-10 14:11:58 --> Loader Class Initialized
DEBUG - 2012-07-10 14:11:58 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:11:58 --> Controller Class Initialized
DEBUG - 2012-07-10 14:11:58 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:11:58 --> Model Class Initialized
DEBUG - 2012-07-10 14:11:58 --> Model Class Initialized
DEBUG - 2012-07-10 14:11:58 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:11:58 --> Helper loaded: alert_helper
DEBUG - 2012-07-10 14:11:58 --> XSS Filtering completed
DEBUG - 2012-07-10 14:11:58 --> XSS Filtering completed
DEBUG - 2012-07-10 14:11:58 --> XSS Filtering completed
DEBUG - 2012-07-10 14:12:14 --> Config Class Initialized
DEBUG - 2012-07-10 14:12:14 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:12:14 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:12:14 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:12:14 --> URI Class Initialized
DEBUG - 2012-07-10 14:12:14 --> Router Class Initialized
DEBUG - 2012-07-10 14:12:14 --> Output Class Initialized
DEBUG - 2012-07-10 14:12:14 --> Security Class Initialized
DEBUG - 2012-07-10 14:12:14 --> Input Class Initialized
DEBUG - 2012-07-10 14:12:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:12:14 --> Language Class Initialized
DEBUG - 2012-07-10 14:12:14 --> Loader Class Initialized
DEBUG - 2012-07-10 14:12:14 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:12:14 --> Controller Class Initialized
DEBUG - 2012-07-10 14:12:14 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:12:14 --> Model Class Initialized
DEBUG - 2012-07-10 14:12:14 --> Model Class Initialized
DEBUG - 2012-07-10 14:12:14 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:12:14 --> Pagination Class Initialized
DEBUG - 2012-07-10 14:12:14 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-10 14:12:14 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-10 14:12:14 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-10 14:12:14 --> Helper loaded: text_helper
DEBUG - 2012-07-10 14:12:14 --> Final output sent to browser
DEBUG - 2012-07-10 14:12:14 --> Total execution time: 0.0463
DEBUG - 2012-07-10 14:13:12 --> Config Class Initialized
DEBUG - 2012-07-10 14:13:12 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:13:12 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:13:12 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:13:12 --> URI Class Initialized
DEBUG - 2012-07-10 14:13:12 --> Router Class Initialized
DEBUG - 2012-07-10 14:13:12 --> Output Class Initialized
DEBUG - 2012-07-10 14:13:12 --> Security Class Initialized
DEBUG - 2012-07-10 14:13:12 --> Input Class Initialized
DEBUG - 2012-07-10 14:13:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:13:12 --> Language Class Initialized
DEBUG - 2012-07-10 14:13:12 --> Loader Class Initialized
DEBUG - 2012-07-10 14:13:12 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:13:12 --> Controller Class Initialized
DEBUG - 2012-07-10 14:13:12 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:13:12 --> Model Class Initialized
DEBUG - 2012-07-10 14:13:12 --> Model Class Initialized
DEBUG - 2012-07-10 14:13:12 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:13:12 --> File loaded: application/views/board/write_v.php
DEBUG - 2012-07-10 14:13:12 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-10 14:13:12 --> Final output sent to browser
DEBUG - 2012-07-10 14:13:12 --> Total execution time: 0.0404
DEBUG - 2012-07-10 14:13:16 --> Config Class Initialized
DEBUG - 2012-07-10 14:13:16 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:13:16 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:13:16 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:13:16 --> URI Class Initialized
DEBUG - 2012-07-10 14:13:16 --> Router Class Initialized
DEBUG - 2012-07-10 14:13:16 --> Output Class Initialized
DEBUG - 2012-07-10 14:13:16 --> Security Class Initialized
DEBUG - 2012-07-10 14:13:16 --> Input Class Initialized
DEBUG - 2012-07-10 14:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:13:16 --> Language Class Initialized
DEBUG - 2012-07-10 14:13:16 --> Loader Class Initialized
DEBUG - 2012-07-10 14:13:16 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:13:16 --> Controller Class Initialized
DEBUG - 2012-07-10 14:13:16 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:13:16 --> Model Class Initialized
DEBUG - 2012-07-10 14:13:16 --> Model Class Initialized
DEBUG - 2012-07-10 14:13:16 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:13:16 --> Helper loaded: alert_helper
DEBUG - 2012-07-10 14:13:16 --> XSS Filtering completed
DEBUG - 2012-07-10 14:13:16 --> XSS Filtering completed
DEBUG - 2012-07-10 14:13:16 --> XSS Filtering completed
DEBUG - 2012-07-10 14:13:19 --> Config Class Initialized
DEBUG - 2012-07-10 14:13:19 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:13:19 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:13:19 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:13:19 --> URI Class Initialized
DEBUG - 2012-07-10 14:13:19 --> Router Class Initialized
DEBUG - 2012-07-10 14:13:19 --> Output Class Initialized
DEBUG - 2012-07-10 14:13:19 --> Security Class Initialized
DEBUG - 2012-07-10 14:13:19 --> Input Class Initialized
DEBUG - 2012-07-10 14:13:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:13:19 --> Language Class Initialized
DEBUG - 2012-07-10 14:13:19 --> Loader Class Initialized
DEBUG - 2012-07-10 14:13:19 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:13:19 --> Controller Class Initialized
DEBUG - 2012-07-10 14:13:19 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:13:19 --> Model Class Initialized
DEBUG - 2012-07-10 14:13:19 --> Model Class Initialized
DEBUG - 2012-07-10 14:13:19 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:13:19 --> Pagination Class Initialized
DEBUG - 2012-07-10 14:13:19 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-10 14:13:19 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-10 14:13:19 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-10 14:13:19 --> Helper loaded: text_helper
DEBUG - 2012-07-10 14:13:19 --> Final output sent to browser
DEBUG - 2012-07-10 14:13:19 --> Total execution time: 0.0465
DEBUG - 2012-07-10 14:14:45 --> Config Class Initialized
DEBUG - 2012-07-10 14:14:45 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:14:45 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:14:45 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:14:45 --> URI Class Initialized
DEBUG - 2012-07-10 14:14:45 --> Router Class Initialized
DEBUG - 2012-07-10 14:14:45 --> Output Class Initialized
DEBUG - 2012-07-10 14:14:45 --> Security Class Initialized
DEBUG - 2012-07-10 14:14:45 --> Input Class Initialized
DEBUG - 2012-07-10 14:14:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:14:45 --> Language Class Initialized
DEBUG - 2012-07-10 14:14:45 --> Loader Class Initialized
DEBUG - 2012-07-10 14:14:45 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:14:45 --> Controller Class Initialized
DEBUG - 2012-07-10 14:14:45 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:14:45 --> Model Class Initialized
DEBUG - 2012-07-10 14:14:45 --> Model Class Initialized
DEBUG - 2012-07-10 14:14:45 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:14:45 --> File loaded: application/views/board/write_v.php
DEBUG - 2012-07-10 14:14:45 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-10 14:14:45 --> Final output sent to browser
DEBUG - 2012-07-10 14:14:45 --> Total execution time: 0.0480
DEBUG - 2012-07-10 14:14:49 --> Config Class Initialized
DEBUG - 2012-07-10 14:14:49 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:14:49 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:14:49 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:14:49 --> URI Class Initialized
DEBUG - 2012-07-10 14:14:49 --> Router Class Initialized
DEBUG - 2012-07-10 14:14:49 --> Output Class Initialized
DEBUG - 2012-07-10 14:14:49 --> Security Class Initialized
DEBUG - 2012-07-10 14:14:49 --> Input Class Initialized
DEBUG - 2012-07-10 14:14:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:14:49 --> Language Class Initialized
DEBUG - 2012-07-10 14:14:49 --> Loader Class Initialized
DEBUG - 2012-07-10 14:14:49 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:14:49 --> Controller Class Initialized
DEBUG - 2012-07-10 14:14:49 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:14:49 --> Model Class Initialized
DEBUG - 2012-07-10 14:14:49 --> Model Class Initialized
DEBUG - 2012-07-10 14:14:49 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:14:49 --> Helper loaded: alert_helper
DEBUG - 2012-07-10 14:14:49 --> XSS Filtering completed
DEBUG - 2012-07-10 14:14:49 --> XSS Filtering completed
DEBUG - 2012-07-10 14:14:49 --> XSS Filtering completed
DEBUG - 2012-07-10 14:14:51 --> Config Class Initialized
DEBUG - 2012-07-10 14:14:51 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:14:51 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:14:51 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:14:51 --> URI Class Initialized
DEBUG - 2012-07-10 14:14:51 --> Router Class Initialized
DEBUG - 2012-07-10 14:14:51 --> Output Class Initialized
DEBUG - 2012-07-10 14:14:51 --> Security Class Initialized
DEBUG - 2012-07-10 14:14:51 --> Input Class Initialized
DEBUG - 2012-07-10 14:14:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:14:51 --> Language Class Initialized
DEBUG - 2012-07-10 14:14:51 --> Loader Class Initialized
DEBUG - 2012-07-10 14:14:51 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:14:51 --> Controller Class Initialized
DEBUG - 2012-07-10 14:14:51 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:14:51 --> Model Class Initialized
DEBUG - 2012-07-10 14:14:51 --> Model Class Initialized
DEBUG - 2012-07-10 14:14:51 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:14:51 --> Pagination Class Initialized
DEBUG - 2012-07-10 14:14:51 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-10 14:14:51 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-10 14:14:51 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-10 14:14:51 --> Helper loaded: text_helper
DEBUG - 2012-07-10 14:14:51 --> Final output sent to browser
DEBUG - 2012-07-10 14:14:51 --> Total execution time: 0.0377
DEBUG - 2012-07-10 14:31:14 --> Config Class Initialized
DEBUG - 2012-07-10 14:31:14 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:31:14 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:31:14 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:31:14 --> URI Class Initialized
DEBUG - 2012-07-10 14:31:14 --> Router Class Initialized
DEBUG - 2012-07-10 14:31:14 --> Output Class Initialized
DEBUG - 2012-07-10 14:31:14 --> Security Class Initialized
DEBUG - 2012-07-10 14:31:14 --> Input Class Initialized
DEBUG - 2012-07-10 14:31:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:31:14 --> Language Class Initialized
DEBUG - 2012-07-10 14:31:14 --> Loader Class Initialized
DEBUG - 2012-07-10 14:31:15 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:31:15 --> Controller Class Initialized
DEBUG - 2012-07-10 14:31:15 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:31:15 --> Model Class Initialized
DEBUG - 2012-07-10 14:31:15 --> Model Class Initialized
DEBUG - 2012-07-10 14:31:15 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:31:15 --> File loaded: application/views/board/write_v.php
DEBUG - 2012-07-10 14:31:15 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-10 14:31:15 --> Final output sent to browser
DEBUG - 2012-07-10 14:31:15 --> Total execution time: 0.0483
DEBUG - 2012-07-10 14:31:17 --> Config Class Initialized
DEBUG - 2012-07-10 14:31:17 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:31:17 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:31:17 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:31:17 --> URI Class Initialized
DEBUG - 2012-07-10 14:31:17 --> Router Class Initialized
DEBUG - 2012-07-10 14:31:17 --> Output Class Initialized
DEBUG - 2012-07-10 14:31:17 --> Security Class Initialized
DEBUG - 2012-07-10 14:31:17 --> Input Class Initialized
DEBUG - 2012-07-10 14:31:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:31:17 --> Language Class Initialized
DEBUG - 2012-07-10 14:31:17 --> Loader Class Initialized
DEBUG - 2012-07-10 14:31:17 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:31:17 --> Controller Class Initialized
DEBUG - 2012-07-10 14:31:17 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:31:17 --> Model Class Initialized
DEBUG - 2012-07-10 14:31:17 --> Model Class Initialized
DEBUG - 2012-07-10 14:31:17 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:31:17 --> Helper loaded: alert_helper
DEBUG - 2012-07-10 14:31:17 --> XSS Filtering completed
DEBUG - 2012-07-10 14:31:17 --> XSS Filtering completed
DEBUG - 2012-07-10 14:31:17 --> XSS Filtering completed
DEBUG - 2012-07-10 14:31:19 --> Config Class Initialized
DEBUG - 2012-07-10 14:31:19 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:31:19 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:31:19 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:31:19 --> URI Class Initialized
DEBUG - 2012-07-10 14:31:19 --> Router Class Initialized
DEBUG - 2012-07-10 14:31:19 --> Output Class Initialized
DEBUG - 2012-07-10 14:31:19 --> Security Class Initialized
DEBUG - 2012-07-10 14:31:19 --> Input Class Initialized
DEBUG - 2012-07-10 14:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:31:19 --> Language Class Initialized
DEBUG - 2012-07-10 14:31:19 --> Loader Class Initialized
DEBUG - 2012-07-10 14:31:19 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:31:19 --> Controller Class Initialized
DEBUG - 2012-07-10 14:31:19 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:31:19 --> Model Class Initialized
DEBUG - 2012-07-10 14:31:19 --> Model Class Initialized
DEBUG - 2012-07-10 14:31:19 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:31:19 --> Pagination Class Initialized
DEBUG - 2012-07-10 14:31:19 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-10 14:31:19 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-10 14:31:19 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-10 14:31:19 --> Helper loaded: text_helper
DEBUG - 2012-07-10 14:31:19 --> Final output sent to browser
DEBUG - 2012-07-10 14:31:19 --> Total execution time: 0.0378
DEBUG - 2012-07-10 14:31:20 --> Config Class Initialized
DEBUG - 2012-07-10 14:31:20 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:31:20 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:31:20 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:31:20 --> URI Class Initialized
DEBUG - 2012-07-10 14:31:20 --> Router Class Initialized
DEBUG - 2012-07-10 14:31:20 --> Output Class Initialized
DEBUG - 2012-07-10 14:31:20 --> Security Class Initialized
DEBUG - 2012-07-10 14:31:20 --> Input Class Initialized
DEBUG - 2012-07-10 14:31:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:31:20 --> Language Class Initialized
DEBUG - 2012-07-10 14:31:20 --> Loader Class Initialized
DEBUG - 2012-07-10 14:31:20 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:31:20 --> Controller Class Initialized
DEBUG - 2012-07-10 14:31:20 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:31:20 --> Model Class Initialized
DEBUG - 2012-07-10 14:31:20 --> Model Class Initialized
DEBUG - 2012-07-10 14:31:20 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:31:20 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-07-10 14:31:20 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-10 14:31:20 --> Final output sent to browser
DEBUG - 2012-07-10 14:31:20 --> Total execution time: 0.0536
DEBUG - 2012-07-10 14:33:22 --> Config Class Initialized
DEBUG - 2012-07-10 14:33:22 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:33:22 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:33:22 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:33:22 --> URI Class Initialized
DEBUG - 2012-07-10 14:33:22 --> Router Class Initialized
DEBUG - 2012-07-10 14:33:22 --> Output Class Initialized
DEBUG - 2012-07-10 14:33:22 --> Security Class Initialized
DEBUG - 2012-07-10 14:33:22 --> Input Class Initialized
DEBUG - 2012-07-10 14:33:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:33:22 --> Language Class Initialized
DEBUG - 2012-07-10 14:33:22 --> Loader Class Initialized
DEBUG - 2012-07-10 14:33:22 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:33:22 --> Controller Class Initialized
DEBUG - 2012-07-10 14:33:22 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:33:22 --> Model Class Initialized
DEBUG - 2012-07-10 14:33:22 --> Model Class Initialized
DEBUG - 2012-07-10 14:33:22 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:33:22 --> File loaded: application/views/board/write_v.php
DEBUG - 2012-07-10 14:33:22 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-10 14:33:22 --> Final output sent to browser
DEBUG - 2012-07-10 14:33:22 --> Total execution time: 0.0541
DEBUG - 2012-07-10 14:39:10 --> Config Class Initialized
DEBUG - 2012-07-10 14:39:10 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:39:10 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:39:10 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:39:10 --> URI Class Initialized
DEBUG - 2012-07-10 14:39:10 --> Router Class Initialized
DEBUG - 2012-07-10 14:39:10 --> Output Class Initialized
DEBUG - 2012-07-10 14:39:10 --> Security Class Initialized
DEBUG - 2012-07-10 14:39:10 --> Input Class Initialized
DEBUG - 2012-07-10 14:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:39:10 --> Language Class Initialized
DEBUG - 2012-07-10 14:39:10 --> Loader Class Initialized
DEBUG - 2012-07-10 14:39:10 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:39:10 --> Controller Class Initialized
DEBUG - 2012-07-10 14:39:10 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:39:10 --> Model Class Initialized
DEBUG - 2012-07-10 14:39:10 --> Model Class Initialized
DEBUG - 2012-07-10 14:39:10 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:39:10 --> Helper loaded: alert_helper
DEBUG - 2012-07-10 14:39:10 --> XSS Filtering completed
DEBUG - 2012-07-10 14:39:10 --> XSS Filtering completed
DEBUG - 2012-07-10 14:39:10 --> XSS Filtering completed
DEBUG - 2012-07-10 14:39:26 --> Config Class Initialized
DEBUG - 2012-07-10 14:39:26 --> Hooks Class Initialized
DEBUG - 2012-07-10 14:39:26 --> Utf8 Class Initialized
DEBUG - 2012-07-10 14:39:26 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 14:39:26 --> URI Class Initialized
DEBUG - 2012-07-10 14:39:26 --> Router Class Initialized
DEBUG - 2012-07-10 14:39:26 --> Output Class Initialized
DEBUG - 2012-07-10 14:39:26 --> Security Class Initialized
DEBUG - 2012-07-10 14:39:26 --> Input Class Initialized
DEBUG - 2012-07-10 14:39:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 14:39:26 --> Language Class Initialized
DEBUG - 2012-07-10 14:39:26 --> Loader Class Initialized
DEBUG - 2012-07-10 14:39:26 --> Helper loaded: date_helper
DEBUG - 2012-07-10 14:39:26 --> Controller Class Initialized
DEBUG - 2012-07-10 14:39:26 --> Database Driver Class Initialized
DEBUG - 2012-07-10 14:39:26 --> Model Class Initialized
DEBUG - 2012-07-10 14:39:26 --> Model Class Initialized
DEBUG - 2012-07-10 14:39:26 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 14:39:26 --> Pagination Class Initialized
DEBUG - 2012-07-10 14:39:26 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-10 14:39:26 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-10 14:39:26 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-10 14:39:26 --> Helper loaded: text_helper
DEBUG - 2012-07-10 14:39:26 --> Final output sent to browser
DEBUG - 2012-07-10 14:39:26 --> Total execution time: 0.0460
