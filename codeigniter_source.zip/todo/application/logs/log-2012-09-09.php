<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-09-09 06:07:14 --> Config Class Initialized
DEBUG - 2012-09-09 06:07:14 --> Hooks Class Initialized
DEBUG - 2012-09-09 06:07:14 --> Utf8 Class Initialized
DEBUG - 2012-09-09 06:07:14 --> UTF-8 Support Enabled
DEBUG - 2012-09-09 06:07:14 --> URI Class Initialized
DEBUG - 2012-09-09 06:07:14 --> Router Class Initialized
ERROR - 2012-09-09 06:07:14 --> 404 Page Not Found --> scrape
DEBUG - 2012-09-09 06:07:26 --> Config Class Initialized
DEBUG - 2012-09-09 06:07:26 --> Hooks Class Initialized
DEBUG - 2012-09-09 06:07:26 --> Utf8 Class Initialized
DEBUG - 2012-09-09 06:07:26 --> UTF-8 Support Enabled
DEBUG - 2012-09-09 06:07:26 --> URI Class Initialized
DEBUG - 2012-09-09 06:07:26 --> Router Class Initialized
ERROR - 2012-09-09 06:07:26 --> 404 Page Not Found --> announce
DEBUG - 2012-09-09 06:15:18 --> Config Class Initialized
DEBUG - 2012-09-09 06:15:18 --> Hooks Class Initialized
DEBUG - 2012-09-09 06:15:18 --> Utf8 Class Initialized
DEBUG - 2012-09-09 06:15:18 --> UTF-8 Support Enabled
DEBUG - 2012-09-09 06:15:18 --> URI Class Initialized
DEBUG - 2012-09-09 06:15:18 --> Router Class Initialized
DEBUG - 2012-09-09 06:15:18 --> No URI present. Default controller set.
DEBUG - 2012-09-09 06:15:19 --> Output Class Initialized
DEBUG - 2012-09-09 06:15:19 --> Security Class Initialized
DEBUG - 2012-09-09 06:15:19 --> Input Class Initialized
DEBUG - 2012-09-09 06:15:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-09 06:15:19 --> Language Class Initialized
DEBUG - 2012-09-09 06:15:19 --> Loader Class Initialized
DEBUG - 2012-09-09 06:15:19 --> Helper loaded: date_helper
DEBUG - 2012-09-09 06:15:19 --> Controller Class Initialized
DEBUG - 2012-09-09 06:15:19 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-09-09 06:15:19 --> Final output sent to browser
DEBUG - 2012-09-09 06:15:19 --> Total execution time: 0.1480
DEBUG - 2012-09-09 06:37:38 --> Config Class Initialized
DEBUG - 2012-09-09 06:37:38 --> Hooks Class Initialized
DEBUG - 2012-09-09 06:37:38 --> Utf8 Class Initialized
DEBUG - 2012-09-09 06:37:38 --> UTF-8 Support Enabled
DEBUG - 2012-09-09 06:37:38 --> URI Class Initialized
DEBUG - 2012-09-09 06:37:38 --> Router Class Initialized
ERROR - 2012-09-09 06:37:38 --> 404 Page Not Found --> announce
DEBUG - 2012-09-09 07:07:50 --> Config Class Initialized
DEBUG - 2012-09-09 07:07:50 --> Hooks Class Initialized
DEBUG - 2012-09-09 07:07:50 --> Utf8 Class Initialized
DEBUG - 2012-09-09 07:07:50 --> UTF-8 Support Enabled
DEBUG - 2012-09-09 07:07:50 --> URI Class Initialized
DEBUG - 2012-09-09 07:07:50 --> Router Class Initialized
ERROR - 2012-09-09 07:07:50 --> 404 Page Not Found --> announce
