<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-07-09 16:05:45 --> Config Class Initialized
DEBUG - 2012-07-09 16:05:45 --> Hooks Class Initialized
DEBUG - 2012-07-09 16:05:45 --> Utf8 Class Initialized
DEBUG - 2012-07-09 16:05:45 --> UTF-8 Support Enabled
DEBUG - 2012-07-09 16:05:45 --> URI Class Initialized
DEBUG - 2012-07-09 16:05:45 --> Router Class Initialized
DEBUG - 2012-07-09 16:05:45 --> Output Class Initialized
DEBUG - 2012-07-09 16:05:45 --> Security Class Initialized
DEBUG - 2012-07-09 16:05:45 --> Input Class Initialized
DEBUG - 2012-07-09 16:05:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-09 16:05:45 --> Language Class Initialized
DEBUG - 2012-07-09 16:05:45 --> Loader Class Initialized
DEBUG - 2012-07-09 16:05:45 --> Helper loaded: date_helper
DEBUG - 2012-07-09 16:05:45 --> Controller Class Initialized
DEBUG - 2012-07-09 16:05:45 --> Database Driver Class Initialized
DEBUG - 2012-07-09 16:05:46 --> Model Class Initialized
DEBUG - 2012-07-09 16:05:46 --> Model Class Initialized
DEBUG - 2012-07-09 16:05:46 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-09 16:05:46 --> Pagination Class Initialized
DEBUG - 2012-07-09 16:05:46 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-09 16:05:46 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-09 16:05:46 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-09 16:05:46 --> Helper loaded: text_helper
DEBUG - 2012-07-09 16:05:46 --> Final output sent to browser
DEBUG - 2012-07-09 16:05:46 --> Total execution time: 0.3263
DEBUG - 2012-07-09 16:05:58 --> Config Class Initialized
DEBUG - 2012-07-09 16:05:58 --> Hooks Class Initialized
DEBUG - 2012-07-09 16:05:58 --> Utf8 Class Initialized
DEBUG - 2012-07-09 16:05:58 --> UTF-8 Support Enabled
DEBUG - 2012-07-09 16:05:58 --> URI Class Initialized
DEBUG - 2012-07-09 16:05:58 --> Router Class Initialized
DEBUG - 2012-07-09 16:05:58 --> Output Class Initialized
DEBUG - 2012-07-09 16:05:58 --> Security Class Initialized
DEBUG - 2012-07-09 16:05:58 --> Input Class Initialized
DEBUG - 2012-07-09 16:05:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-09 16:05:58 --> Language Class Initialized
DEBUG - 2012-07-09 16:05:58 --> Loader Class Initialized
DEBUG - 2012-07-09 16:05:58 --> Helper loaded: date_helper
DEBUG - 2012-07-09 16:05:58 --> Controller Class Initialized
DEBUG - 2012-07-09 16:05:58 --> Database Driver Class Initialized
DEBUG - 2012-07-09 16:05:58 --> Model Class Initialized
DEBUG - 2012-07-09 16:05:58 --> Model Class Initialized
DEBUG - 2012-07-09 16:05:58 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-09 16:05:58 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-07-09 16:05:58 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-09 16:05:58 --> Final output sent to browser
DEBUG - 2012-07-09 16:05:58 --> Total execution time: 0.1081
DEBUG - 2012-07-09 16:06:15 --> Config Class Initialized
DEBUG - 2012-07-09 16:06:15 --> Hooks Class Initialized
DEBUG - 2012-07-09 16:06:15 --> Utf8 Class Initialized
DEBUG - 2012-07-09 16:06:15 --> UTF-8 Support Enabled
DEBUG - 2012-07-09 16:06:15 --> URI Class Initialized
DEBUG - 2012-07-09 16:06:15 --> Router Class Initialized
DEBUG - 2012-07-09 16:06:15 --> Output Class Initialized
DEBUG - 2012-07-09 16:06:15 --> Security Class Initialized
DEBUG - 2012-07-09 16:06:15 --> Input Class Initialized
DEBUG - 2012-07-09 16:06:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-09 16:06:15 --> Language Class Initialized
DEBUG - 2012-07-09 16:06:15 --> Loader Class Initialized
DEBUG - 2012-07-09 16:06:15 --> Helper loaded: date_helper
DEBUG - 2012-07-09 16:06:15 --> Controller Class Initialized
DEBUG - 2012-07-09 16:06:15 --> Database Driver Class Initialized
DEBUG - 2012-07-09 16:06:15 --> Model Class Initialized
DEBUG - 2012-07-09 16:06:15 --> Model Class Initialized
DEBUG - 2012-07-09 16:06:15 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-09 16:06:15 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-07-09 16:06:15 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-09 16:06:15 --> Final output sent to browser
DEBUG - 2012-07-09 16:06:15 --> Total execution time: 0.0445
DEBUG - 2012-07-09 16:13:26 --> Config Class Initialized
DEBUG - 2012-07-09 16:13:26 --> Hooks Class Initialized
DEBUG - 2012-07-09 16:13:26 --> Utf8 Class Initialized
DEBUG - 2012-07-09 16:13:26 --> UTF-8 Support Enabled
DEBUG - 2012-07-09 16:13:26 --> URI Class Initialized
DEBUG - 2012-07-09 16:13:26 --> Router Class Initialized
DEBUG - 2012-07-09 16:13:26 --> Output Class Initialized
DEBUG - 2012-07-09 16:13:26 --> Security Class Initialized
DEBUG - 2012-07-09 16:13:26 --> Input Class Initialized
DEBUG - 2012-07-09 16:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-09 16:13:26 --> Language Class Initialized
DEBUG - 2012-07-09 16:13:26 --> Loader Class Initialized
DEBUG - 2012-07-09 16:13:26 --> Helper loaded: date_helper
DEBUG - 2012-07-09 16:13:26 --> Controller Class Initialized
DEBUG - 2012-07-09 16:13:26 --> Database Driver Class Initialized
DEBUG - 2012-07-09 16:13:26 --> Model Class Initialized
DEBUG - 2012-07-09 16:13:26 --> Model Class Initialized
DEBUG - 2012-07-09 16:13:26 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-09 16:13:26 --> Pagination Class Initialized
DEBUG - 2012-07-09 16:13:26 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-09 16:13:26 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-09 16:13:26 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-09 16:13:26 --> Helper loaded: text_helper
DEBUG - 2012-07-09 16:13:26 --> Final output sent to browser
DEBUG - 2012-07-09 16:13:26 --> Total execution time: 0.0555
DEBUG - 2012-07-09 16:33:18 --> Config Class Initialized
DEBUG - 2012-07-09 16:33:18 --> Hooks Class Initialized
DEBUG - 2012-07-09 16:33:18 --> Utf8 Class Initialized
DEBUG - 2012-07-09 16:33:18 --> UTF-8 Support Enabled
DEBUG - 2012-07-09 16:33:18 --> URI Class Initialized
DEBUG - 2012-07-09 16:33:18 --> Router Class Initialized
DEBUG - 2012-07-09 16:33:18 --> Output Class Initialized
DEBUG - 2012-07-09 16:33:18 --> Security Class Initialized
DEBUG - 2012-07-09 16:33:18 --> Input Class Initialized
DEBUG - 2012-07-09 16:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-09 16:33:18 --> Language Class Initialized
DEBUG - 2012-07-09 16:33:18 --> Loader Class Initialized
DEBUG - 2012-07-09 16:33:18 --> Helper loaded: date_helper
DEBUG - 2012-07-09 16:33:18 --> Controller Class Initialized
DEBUG - 2012-07-09 16:33:19 --> Database Driver Class Initialized
DEBUG - 2012-07-09 16:33:19 --> Model Class Initialized
DEBUG - 2012-07-09 16:33:19 --> Model Class Initialized
DEBUG - 2012-07-09 16:33:19 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-09 16:33:19 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-07-09 16:33:19 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-09 16:33:19 --> Final output sent to browser
DEBUG - 2012-07-09 16:33:19 --> Total execution time: 0.0518
DEBUG - 2012-07-09 17:26:08 --> Config Class Initialized
DEBUG - 2012-07-09 17:26:08 --> Hooks Class Initialized
DEBUG - 2012-07-09 17:26:08 --> Utf8 Class Initialized
DEBUG - 2012-07-09 17:26:08 --> UTF-8 Support Enabled
DEBUG - 2012-07-09 17:26:08 --> URI Class Initialized
DEBUG - 2012-07-09 17:26:08 --> Router Class Initialized
DEBUG - 2012-07-09 17:26:08 --> Output Class Initialized
DEBUG - 2012-07-09 17:26:08 --> Security Class Initialized
DEBUG - 2012-07-09 17:26:08 --> Input Class Initialized
DEBUG - 2012-07-09 17:26:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-09 17:26:08 --> Language Class Initialized
DEBUG - 2012-07-09 17:26:08 --> Loader Class Initialized
DEBUG - 2012-07-09 17:26:08 --> Helper loaded: date_helper
DEBUG - 2012-07-09 17:26:08 --> Controller Class Initialized
DEBUG - 2012-07-09 17:26:08 --> Database Driver Class Initialized
DEBUG - 2012-07-09 17:26:08 --> Model Class Initialized
DEBUG - 2012-07-09 17:26:08 --> Model Class Initialized
DEBUG - 2012-07-09 17:26:08 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-09 17:26:08 --> File loaded: application/views/board/write_v.php
DEBUG - 2012-07-09 17:26:08 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-09 17:26:08 --> Final output sent to browser
DEBUG - 2012-07-09 17:26:08 --> Total execution time: 0.0628
