<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-09-23 04:11:02 --> Config Class Initialized
DEBUG - 2012-09-23 04:11:02 --> Hooks Class Initialized
DEBUG - 2012-09-23 04:11:02 --> Utf8 Class Initialized
DEBUG - 2012-09-23 04:11:02 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 04:11:02 --> URI Class Initialized
DEBUG - 2012-09-23 04:11:02 --> Router Class Initialized
DEBUG - 2012-09-23 04:11:02 --> No URI present. Default controller set.
DEBUG - 2012-09-23 04:11:02 --> Output Class Initialized
DEBUG - 2012-09-23 04:11:02 --> Security Class Initialized
DEBUG - 2012-09-23 04:11:02 --> Input Class Initialized
DEBUG - 2012-09-23 04:11:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 04:11:02 --> Language Class Initialized
DEBUG - 2012-09-23 04:11:02 --> Loader Class Initialized
DEBUG - 2012-09-23 04:11:02 --> Helper loaded: date_helper
DEBUG - 2012-09-23 04:11:02 --> Controller Class Initialized
DEBUG - 2012-09-23 04:11:02 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-09-23 04:11:02 --> Final output sent to browser
DEBUG - 2012-09-23 04:11:02 --> Total execution time: 0.2327
DEBUG - 2012-09-23 04:11:03 --> Config Class Initialized
DEBUG - 2012-09-23 04:11:03 --> Hooks Class Initialized
DEBUG - 2012-09-23 04:11:03 --> Utf8 Class Initialized
DEBUG - 2012-09-23 04:11:03 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 04:11:03 --> URI Class Initialized
DEBUG - 2012-09-23 04:11:03 --> Router Class Initialized
ERROR - 2012-09-23 04:11:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-09-23 04:11:30 --> Config Class Initialized
DEBUG - 2012-09-23 04:11:30 --> Hooks Class Initialized
DEBUG - 2012-09-23 04:11:30 --> Utf8 Class Initialized
DEBUG - 2012-09-23 04:11:30 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 04:11:30 --> URI Class Initialized
DEBUG - 2012-09-23 04:11:30 --> Router Class Initialized
ERROR - 2012-09-23 04:11:30 --> 404 Page Not Found --> togo
DEBUG - 2012-09-23 04:11:30 --> Config Class Initialized
DEBUG - 2012-09-23 04:11:30 --> Hooks Class Initialized
DEBUG - 2012-09-23 04:11:30 --> Utf8 Class Initialized
DEBUG - 2012-09-23 04:11:30 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 04:11:30 --> URI Class Initialized
DEBUG - 2012-09-23 04:11:30 --> Router Class Initialized
ERROR - 2012-09-23 04:11:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-09-23 04:11:36 --> Config Class Initialized
DEBUG - 2012-09-23 04:11:36 --> Hooks Class Initialized
DEBUG - 2012-09-23 04:11:36 --> Utf8 Class Initialized
DEBUG - 2012-09-23 04:11:36 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 04:11:36 --> URI Class Initialized
DEBUG - 2012-09-23 04:11:36 --> Router Class Initialized
ERROR - 2012-09-23 04:11:36 --> 404 Page Not Found --> todo
DEBUG - 2012-09-23 04:11:36 --> Config Class Initialized
DEBUG - 2012-09-23 04:11:36 --> Hooks Class Initialized
DEBUG - 2012-09-23 04:11:36 --> Utf8 Class Initialized
DEBUG - 2012-09-23 04:11:36 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 04:11:36 --> URI Class Initialized
DEBUG - 2012-09-23 04:11:36 --> Router Class Initialized
ERROR - 2012-09-23 04:11:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-09-23 04:14:02 --> Config Class Initialized
DEBUG - 2012-09-23 04:14:02 --> Hooks Class Initialized
DEBUG - 2012-09-23 04:14:02 --> Utf8 Class Initialized
DEBUG - 2012-09-23 04:14:02 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 04:14:02 --> URI Class Initialized
DEBUG - 2012-09-23 04:14:02 --> Router Class Initialized
DEBUG - 2012-09-23 04:14:02 --> No URI present. Default controller set.
DEBUG - 2012-09-23 04:14:02 --> Output Class Initialized
DEBUG - 2012-09-23 04:14:02 --> Security Class Initialized
DEBUG - 2012-09-23 04:14:02 --> Input Class Initialized
DEBUG - 2012-09-23 04:14:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 04:14:02 --> Language Class Initialized
DEBUG - 2012-09-23 04:14:02 --> Loader Class Initialized
DEBUG - 2012-09-23 04:14:02 --> Helper loaded: date_helper
DEBUG - 2012-09-23 04:14:02 --> Controller Class Initialized
DEBUG - 2012-09-23 04:14:02 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-09-23 04:14:02 --> Final output sent to browser
DEBUG - 2012-09-23 04:14:02 --> Total execution time: 0.0258
DEBUG - 2012-09-23 05:54:25 --> Config Class Initialized
DEBUG - 2012-09-23 05:54:25 --> Hooks Class Initialized
DEBUG - 2012-09-23 05:54:25 --> Utf8 Class Initialized
DEBUG - 2012-09-23 05:54:25 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 05:54:25 --> URI Class Initialized
DEBUG - 2012-09-23 05:54:25 --> Router Class Initialized
DEBUG - 2012-09-23 05:54:25 --> No URI present. Default controller set.
DEBUG - 2012-09-23 05:54:25 --> Output Class Initialized
DEBUG - 2012-09-23 05:54:25 --> Security Class Initialized
DEBUG - 2012-09-23 05:54:25 --> Input Class Initialized
DEBUG - 2012-09-23 05:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 05:54:25 --> Language Class Initialized
DEBUG - 2012-09-23 05:54:25 --> Loader Class Initialized
DEBUG - 2012-09-23 05:54:25 --> Helper loaded: date_helper
DEBUG - 2012-09-23 05:54:25 --> Controller Class Initialized
DEBUG - 2012-09-23 05:54:25 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-09-23 05:54:25 --> Final output sent to browser
DEBUG - 2012-09-23 05:54:25 --> Total execution time: 0.0287
DEBUG - 2012-09-23 05:54:27 --> Config Class Initialized
DEBUG - 2012-09-23 05:54:27 --> Hooks Class Initialized
DEBUG - 2012-09-23 05:54:27 --> Utf8 Class Initialized
DEBUG - 2012-09-23 05:54:27 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 05:54:27 --> URI Class Initialized
DEBUG - 2012-09-23 05:54:27 --> Router Class Initialized
DEBUG - 2012-09-23 05:54:27 --> No URI present. Default controller set.
DEBUG - 2012-09-23 05:54:27 --> Output Class Initialized
DEBUG - 2012-09-23 05:54:27 --> Security Class Initialized
DEBUG - 2012-09-23 05:54:27 --> Input Class Initialized
DEBUG - 2012-09-23 05:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 05:54:27 --> Language Class Initialized
DEBUG - 2012-09-23 05:54:27 --> Loader Class Initialized
DEBUG - 2012-09-23 05:54:27 --> Helper loaded: date_helper
DEBUG - 2012-09-23 05:54:27 --> Controller Class Initialized
DEBUG - 2012-09-23 05:54:27 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-09-23 05:54:27 --> Final output sent to browser
DEBUG - 2012-09-23 05:54:27 --> Total execution time: 0.0318
DEBUG - 2012-09-23 05:55:32 --> Config Class Initialized
DEBUG - 2012-09-23 05:55:32 --> Hooks Class Initialized
DEBUG - 2012-09-23 05:55:32 --> Utf8 Class Initialized
DEBUG - 2012-09-23 05:55:32 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 05:55:32 --> URI Class Initialized
DEBUG - 2012-09-23 05:55:32 --> Router Class Initialized
DEBUG - 2012-09-23 05:55:32 --> No URI present. Default controller set.
DEBUG - 2012-09-23 05:55:32 --> Output Class Initialized
DEBUG - 2012-09-23 05:55:32 --> Security Class Initialized
DEBUG - 2012-09-23 05:55:32 --> Input Class Initialized
DEBUG - 2012-09-23 05:55:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 05:55:32 --> Language Class Initialized
DEBUG - 2012-09-23 05:55:32 --> Loader Class Initialized
DEBUG - 2012-09-23 05:55:32 --> Helper loaded: date_helper
DEBUG - 2012-09-23 05:55:32 --> Controller Class Initialized
DEBUG - 2012-09-23 05:55:32 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-09-23 05:55:32 --> Final output sent to browser
DEBUG - 2012-09-23 05:55:32 --> Total execution time: 0.0273
DEBUG - 2012-09-23 05:56:01 --> Config Class Initialized
DEBUG - 2012-09-23 05:56:01 --> Hooks Class Initialized
DEBUG - 2012-09-23 05:56:01 --> Utf8 Class Initialized
DEBUG - 2012-09-23 05:56:01 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 05:56:01 --> URI Class Initialized
DEBUG - 2012-09-23 05:56:01 --> Router Class Initialized
DEBUG - 2012-09-23 05:56:01 --> No URI present. Default controller set.
DEBUG - 2012-09-23 05:56:01 --> Output Class Initialized
DEBUG - 2012-09-23 05:56:01 --> Security Class Initialized
DEBUG - 2012-09-23 05:56:01 --> Input Class Initialized
DEBUG - 2012-09-23 05:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 05:56:01 --> Language Class Initialized
DEBUG - 2012-09-23 05:56:01 --> Loader Class Initialized
DEBUG - 2012-09-23 05:56:01 --> Helper loaded: date_helper
DEBUG - 2012-09-23 05:56:01 --> Controller Class Initialized
DEBUG - 2012-09-23 05:56:01 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-09-23 05:56:01 --> Final output sent to browser
DEBUG - 2012-09-23 05:56:01 --> Total execution time: 0.0260
DEBUG - 2012-09-23 05:57:48 --> Config Class Initialized
DEBUG - 2012-09-23 05:57:48 --> Hooks Class Initialized
DEBUG - 2012-09-23 05:57:48 --> Utf8 Class Initialized
DEBUG - 2012-09-23 05:57:48 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 05:57:48 --> URI Class Initialized
DEBUG - 2012-09-23 05:57:48 --> Router Class Initialized
DEBUG - 2012-09-23 05:57:48 --> No URI present. Default controller set.
DEBUG - 2012-09-23 05:57:48 --> Output Class Initialized
DEBUG - 2012-09-23 05:57:48 --> Security Class Initialized
DEBUG - 2012-09-23 05:57:48 --> Input Class Initialized
DEBUG - 2012-09-23 05:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 05:57:48 --> Language Class Initialized
DEBUG - 2012-09-23 05:57:48 --> Loader Class Initialized
DEBUG - 2012-09-23 05:57:48 --> Helper loaded: date_helper
DEBUG - 2012-09-23 05:57:48 --> Controller Class Initialized
DEBUG - 2012-09-23 05:57:48 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-09-23 05:57:48 --> Final output sent to browser
DEBUG - 2012-09-23 05:57:48 --> Total execution time: 0.0224
DEBUG - 2012-09-23 05:58:12 --> Config Class Initialized
DEBUG - 2012-09-23 05:58:12 --> Hooks Class Initialized
DEBUG - 2012-09-23 05:58:12 --> Utf8 Class Initialized
DEBUG - 2012-09-23 05:58:12 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 05:58:12 --> URI Class Initialized
DEBUG - 2012-09-23 05:58:12 --> Router Class Initialized
DEBUG - 2012-09-23 05:58:12 --> No URI present. Default controller set.
DEBUG - 2012-09-23 05:58:12 --> Output Class Initialized
DEBUG - 2012-09-23 05:58:12 --> Security Class Initialized
DEBUG - 2012-09-23 05:58:12 --> Input Class Initialized
DEBUG - 2012-09-23 05:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 05:58:12 --> Language Class Initialized
DEBUG - 2012-09-23 05:58:12 --> Loader Class Initialized
DEBUG - 2012-09-23 05:58:12 --> Helper loaded: date_helper
DEBUG - 2012-09-23 05:58:12 --> Controller Class Initialized
DEBUG - 2012-09-23 05:58:12 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-09-23 05:58:12 --> Final output sent to browser
DEBUG - 2012-09-23 05:58:12 --> Total execution time: 0.0304
DEBUG - 2012-09-23 05:58:36 --> Config Class Initialized
DEBUG - 2012-09-23 05:58:36 --> Hooks Class Initialized
DEBUG - 2012-09-23 05:58:36 --> Utf8 Class Initialized
DEBUG - 2012-09-23 05:58:36 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 05:58:36 --> URI Class Initialized
DEBUG - 2012-09-23 05:58:36 --> Router Class Initialized
DEBUG - 2012-09-23 05:58:36 --> Output Class Initialized
DEBUG - 2012-09-23 05:58:36 --> Security Class Initialized
DEBUG - 2012-09-23 05:58:36 --> Input Class Initialized
DEBUG - 2012-09-23 05:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 05:58:36 --> Language Class Initialized
DEBUG - 2012-09-23 05:58:36 --> Loader Class Initialized
DEBUG - 2012-09-23 05:58:36 --> Helper loaded: date_helper
DEBUG - 2012-09-23 05:58:36 --> Controller Class Initialized
DEBUG - 2012-09-23 05:58:36 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:15:14 --> Config Class Initialized
DEBUG - 2012-09-23 06:15:14 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:15:14 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:15:14 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:15:14 --> URI Class Initialized
DEBUG - 2012-09-23 06:15:14 --> Router Class Initialized
DEBUG - 2012-09-23 06:15:14 --> Output Class Initialized
DEBUG - 2012-09-23 06:15:14 --> Security Class Initialized
DEBUG - 2012-09-23 06:15:14 --> Input Class Initialized
DEBUG - 2012-09-23 06:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:15:14 --> Language Class Initialized
DEBUG - 2012-09-23 06:15:14 --> Loader Class Initialized
DEBUG - 2012-09-23 06:15:14 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:15:14 --> Controller Class Initialized
DEBUG - 2012-09-23 06:15:14 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:15:14 --> Model Class Initialized
DEBUG - 2012-09-23 06:15:45 --> Config Class Initialized
DEBUG - 2012-09-23 06:15:45 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:15:45 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:15:45 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:15:45 --> URI Class Initialized
DEBUG - 2012-09-23 06:15:45 --> Router Class Initialized
DEBUG - 2012-09-23 06:15:45 --> Output Class Initialized
DEBUG - 2012-09-23 06:15:45 --> Security Class Initialized
DEBUG - 2012-09-23 06:15:45 --> Input Class Initialized
DEBUG - 2012-09-23 06:15:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:15:45 --> Language Class Initialized
DEBUG - 2012-09-23 06:15:45 --> Loader Class Initialized
DEBUG - 2012-09-23 06:15:45 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:15:45 --> Controller Class Initialized
DEBUG - 2012-09-23 06:15:45 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:15:45 --> Model Class Initialized
DEBUG - 2012-09-23 06:15:51 --> Config Class Initialized
DEBUG - 2012-09-23 06:15:51 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:15:51 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:15:51 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:15:51 --> URI Class Initialized
DEBUG - 2012-09-23 06:15:51 --> Router Class Initialized
DEBUG - 2012-09-23 06:15:51 --> Output Class Initialized
DEBUG - 2012-09-23 06:15:51 --> Security Class Initialized
DEBUG - 2012-09-23 06:15:51 --> Input Class Initialized
DEBUG - 2012-09-23 06:15:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:15:51 --> Language Class Initialized
DEBUG - 2012-09-23 06:15:51 --> Loader Class Initialized
DEBUG - 2012-09-23 06:15:51 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:15:51 --> Controller Class Initialized
DEBUG - 2012-09-23 06:15:51 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:15:51 --> Model Class Initialized
DEBUG - 2012-09-23 06:15:51 --> Model Class Initialized
DEBUG - 2012-09-23 06:15:51 --> DB Transaction Failure
ERROR - 2012-09-23 06:15:51 --> Query error: Table 'ci_book.items' doesn't exist
DEBUG - 2012-09-23 06:15:51 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-09-23 06:16:30 --> Config Class Initialized
DEBUG - 2012-09-23 06:16:30 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:16:30 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:16:30 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:16:30 --> URI Class Initialized
DEBUG - 2012-09-23 06:16:30 --> Router Class Initialized
DEBUG - 2012-09-23 06:16:30 --> Output Class Initialized
DEBUG - 2012-09-23 06:16:30 --> Security Class Initialized
DEBUG - 2012-09-23 06:16:30 --> Input Class Initialized
DEBUG - 2012-09-23 06:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:16:30 --> Language Class Initialized
DEBUG - 2012-09-23 06:16:30 --> Loader Class Initialized
DEBUG - 2012-09-23 06:16:30 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:16:30 --> Controller Class Initialized
DEBUG - 2012-09-23 06:16:30 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:16:30 --> Model Class Initialized
DEBUG - 2012-09-23 06:16:30 --> Model Class Initialized
DEBUG - 2012-09-23 06:16:51 --> Config Class Initialized
DEBUG - 2012-09-23 06:16:51 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:16:51 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:16:51 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:16:51 --> URI Class Initialized
DEBUG - 2012-09-23 06:16:51 --> Router Class Initialized
DEBUG - 2012-09-23 06:16:51 --> Output Class Initialized
DEBUG - 2012-09-23 06:16:51 --> Security Class Initialized
DEBUG - 2012-09-23 06:16:51 --> Input Class Initialized
DEBUG - 2012-09-23 06:16:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:16:51 --> Language Class Initialized
DEBUG - 2012-09-23 06:16:51 --> Loader Class Initialized
DEBUG - 2012-09-23 06:16:51 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:16:51 --> Controller Class Initialized
DEBUG - 2012-09-23 06:16:51 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:16:51 --> Model Class Initialized
DEBUG - 2012-09-23 06:16:51 --> Model Class Initialized
ERROR - 2012-09-23 06:16:51 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 8
ERROR - 2012-09-23 06:16:51 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 9
ERROR - 2012-09-23 06:16:51 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 10
ERROR - 2012-09-23 06:16:51 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 11
ERROR - 2012-09-23 06:16:51 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 17
DEBUG - 2012-09-23 06:16:51 --> File loaded: application/views/todo/view_v.php
DEBUG - 2012-09-23 06:16:51 --> Final output sent to browser
DEBUG - 2012-09-23 06:16:51 --> Total execution time: 0.0645
DEBUG - 2012-09-23 06:17:42 --> Config Class Initialized
DEBUG - 2012-09-23 06:17:42 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:17:42 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:17:42 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:17:42 --> URI Class Initialized
DEBUG - 2012-09-23 06:17:42 --> Router Class Initialized
DEBUG - 2012-09-23 06:17:42 --> Output Class Initialized
DEBUG - 2012-09-23 06:17:42 --> Security Class Initialized
DEBUG - 2012-09-23 06:17:42 --> Input Class Initialized
DEBUG - 2012-09-23 06:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:17:42 --> Language Class Initialized
DEBUG - 2012-09-23 06:17:42 --> Loader Class Initialized
DEBUG - 2012-09-23 06:17:42 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:17:42 --> Controller Class Initialized
DEBUG - 2012-09-23 06:17:42 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:17:42 --> Model Class Initialized
DEBUG - 2012-09-23 06:17:42 --> Model Class Initialized
ERROR - 2012-09-23 06:17:42 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 36
ERROR - 2012-09-23 06:17:42 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 37
ERROR - 2012-09-23 06:17:42 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 38
ERROR - 2012-09-23 06:17:42 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 39
ERROR - 2012-09-23 06:17:42 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 45
DEBUG - 2012-09-23 06:17:42 --> File loaded: application/views/todo/view_v.php
DEBUG - 2012-09-23 06:17:42 --> Final output sent to browser
DEBUG - 2012-09-23 06:17:42 --> Total execution time: 0.0486
DEBUG - 2012-09-23 06:18:13 --> Config Class Initialized
DEBUG - 2012-09-23 06:18:13 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:18:13 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:18:13 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:18:13 --> URI Class Initialized
DEBUG - 2012-09-23 06:18:13 --> Router Class Initialized
DEBUG - 2012-09-23 06:18:13 --> Output Class Initialized
DEBUG - 2012-09-23 06:18:13 --> Security Class Initialized
DEBUG - 2012-09-23 06:18:13 --> Input Class Initialized
DEBUG - 2012-09-23 06:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:18:13 --> Language Class Initialized
DEBUG - 2012-09-23 06:18:13 --> Loader Class Initialized
DEBUG - 2012-09-23 06:18:13 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:18:13 --> Controller Class Initialized
DEBUG - 2012-09-23 06:18:13 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:18:13 --> Model Class Initialized
DEBUG - 2012-09-23 06:18:13 --> Model Class Initialized
ERROR - 2012-09-23 06:18:13 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 36
ERROR - 2012-09-23 06:18:13 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 37
ERROR - 2012-09-23 06:18:13 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 38
ERROR - 2012-09-23 06:18:13 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 39
ERROR - 2012-09-23 06:18:13 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 45
DEBUG - 2012-09-23 06:18:13 --> File loaded: application/views/todo/view_v.php
DEBUG - 2012-09-23 06:18:13 --> Final output sent to browser
DEBUG - 2012-09-23 06:18:13 --> Total execution time: 0.0555
DEBUG - 2012-09-23 06:22:24 --> Config Class Initialized
DEBUG - 2012-09-23 06:22:24 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:22:24 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:22:24 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:22:24 --> URI Class Initialized
DEBUG - 2012-09-23 06:22:24 --> Router Class Initialized
DEBUG - 2012-09-23 06:22:24 --> Output Class Initialized
DEBUG - 2012-09-23 06:22:24 --> Security Class Initialized
DEBUG - 2012-09-23 06:22:24 --> Input Class Initialized
DEBUG - 2012-09-23 06:22:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:22:24 --> Language Class Initialized
DEBUG - 2012-09-23 06:22:24 --> Loader Class Initialized
DEBUG - 2012-09-23 06:22:24 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:22:24 --> Controller Class Initialized
DEBUG - 2012-09-23 06:22:24 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:22:24 --> Model Class Initialized
DEBUG - 2012-09-23 06:22:24 --> Model Class Initialized
ERROR - 2012-09-23 06:22:24 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 36
ERROR - 2012-09-23 06:22:24 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 37
ERROR - 2012-09-23 06:22:24 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 38
ERROR - 2012-09-23 06:22:24 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 44
DEBUG - 2012-09-23 06:22:24 --> File loaded: application/views/todo/view_v.php
DEBUG - 2012-09-23 06:22:24 --> Final output sent to browser
DEBUG - 2012-09-23 06:22:24 --> Total execution time: 0.0439
DEBUG - 2012-09-23 06:22:36 --> Config Class Initialized
DEBUG - 2012-09-23 06:22:36 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:22:36 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:22:36 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:22:36 --> URI Class Initialized
DEBUG - 2012-09-23 06:22:36 --> Router Class Initialized
DEBUG - 2012-09-23 06:22:36 --> Output Class Initialized
DEBUG - 2012-09-23 06:22:36 --> Security Class Initialized
DEBUG - 2012-09-23 06:22:36 --> Input Class Initialized
DEBUG - 2012-09-23 06:22:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:22:36 --> Language Class Initialized
DEBUG - 2012-09-23 06:22:36 --> Loader Class Initialized
DEBUG - 2012-09-23 06:22:36 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:22:36 --> Controller Class Initialized
DEBUG - 2012-09-23 06:22:36 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:22:36 --> Model Class Initialized
DEBUG - 2012-09-23 06:22:36 --> Model Class Initialized
ERROR - 2012-09-23 06:22:36 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 36
ERROR - 2012-09-23 06:22:36 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 37
ERROR - 2012-09-23 06:22:36 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 38
ERROR - 2012-09-23 06:22:36 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 44
DEBUG - 2012-09-23 06:22:36 --> File loaded: application/views/todo/view_v.php
DEBUG - 2012-09-23 06:22:36 --> Final output sent to browser
DEBUG - 2012-09-23 06:22:36 --> Total execution time: 0.0566
DEBUG - 2012-09-23 06:22:58 --> Config Class Initialized
DEBUG - 2012-09-23 06:22:58 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:22:58 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:22:58 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:22:58 --> URI Class Initialized
DEBUG - 2012-09-23 06:22:58 --> Router Class Initialized
DEBUG - 2012-09-23 06:22:58 --> Output Class Initialized
DEBUG - 2012-09-23 06:22:58 --> Security Class Initialized
DEBUG - 2012-09-23 06:22:58 --> Input Class Initialized
DEBUG - 2012-09-23 06:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:22:58 --> Language Class Initialized
DEBUG - 2012-09-23 06:22:58 --> Loader Class Initialized
DEBUG - 2012-09-23 06:22:58 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:22:58 --> Controller Class Initialized
DEBUG - 2012-09-23 06:22:58 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:22:58 --> Model Class Initialized
DEBUG - 2012-09-23 06:22:58 --> Model Class Initialized
ERROR - 2012-09-23 06:22:58 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 36
ERROR - 2012-09-23 06:22:58 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 37
ERROR - 2012-09-23 06:22:58 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 38
ERROR - 2012-09-23 06:22:58 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 44
DEBUG - 2012-09-23 06:22:58 --> File loaded: application/views/todo/view_v.php
DEBUG - 2012-09-23 06:22:58 --> Final output sent to browser
DEBUG - 2012-09-23 06:22:58 --> Total execution time: 0.0475
DEBUG - 2012-09-23 06:23:25 --> Config Class Initialized
DEBUG - 2012-09-23 06:23:25 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:23:25 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:23:25 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:23:25 --> URI Class Initialized
DEBUG - 2012-09-23 06:23:25 --> Router Class Initialized
DEBUG - 2012-09-23 06:23:25 --> Output Class Initialized
DEBUG - 2012-09-23 06:23:25 --> Security Class Initialized
DEBUG - 2012-09-23 06:23:25 --> Input Class Initialized
DEBUG - 2012-09-23 06:23:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:23:25 --> Language Class Initialized
DEBUG - 2012-09-23 06:23:25 --> Loader Class Initialized
DEBUG - 2012-09-23 06:23:25 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:23:25 --> Controller Class Initialized
DEBUG - 2012-09-23 06:23:25 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:23:25 --> Model Class Initialized
DEBUG - 2012-09-23 06:23:25 --> Model Class Initialized
DEBUG - 2012-09-23 06:23:30 --> Config Class Initialized
DEBUG - 2012-09-23 06:23:30 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:23:30 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:23:30 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:23:30 --> URI Class Initialized
DEBUG - 2012-09-23 06:23:30 --> Router Class Initialized
DEBUG - 2012-09-23 06:23:30 --> Output Class Initialized
DEBUG - 2012-09-23 06:23:30 --> Security Class Initialized
DEBUG - 2012-09-23 06:23:30 --> Input Class Initialized
DEBUG - 2012-09-23 06:23:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:23:30 --> Language Class Initialized
DEBUG - 2012-09-23 06:23:30 --> Loader Class Initialized
DEBUG - 2012-09-23 06:23:30 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:23:30 --> Controller Class Initialized
DEBUG - 2012-09-23 06:23:30 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:23:30 --> Model Class Initialized
DEBUG - 2012-09-23 06:23:30 --> Model Class Initialized
DEBUG - 2012-09-23 06:23:31 --> Config Class Initialized
DEBUG - 2012-09-23 06:23:31 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:23:31 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:23:31 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:23:31 --> URI Class Initialized
DEBUG - 2012-09-23 06:23:31 --> Router Class Initialized
DEBUG - 2012-09-23 06:23:31 --> Output Class Initialized
DEBUG - 2012-09-23 06:23:31 --> Security Class Initialized
DEBUG - 2012-09-23 06:23:31 --> Input Class Initialized
DEBUG - 2012-09-23 06:23:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:23:31 --> Language Class Initialized
DEBUG - 2012-09-23 06:23:31 --> Loader Class Initialized
DEBUG - 2012-09-23 06:23:31 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:23:31 --> Controller Class Initialized
DEBUG - 2012-09-23 06:23:31 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:23:31 --> Model Class Initialized
DEBUG - 2012-09-23 06:23:31 --> Model Class Initialized
DEBUG - 2012-09-23 06:23:44 --> Config Class Initialized
DEBUG - 2012-09-23 06:23:44 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:23:44 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:23:44 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:23:44 --> URI Class Initialized
DEBUG - 2012-09-23 06:23:44 --> Router Class Initialized
DEBUG - 2012-09-23 06:23:44 --> Output Class Initialized
DEBUG - 2012-09-23 06:23:44 --> Security Class Initialized
DEBUG - 2012-09-23 06:23:44 --> Input Class Initialized
DEBUG - 2012-09-23 06:23:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:23:44 --> Language Class Initialized
DEBUG - 2012-09-23 06:23:44 --> Loader Class Initialized
DEBUG - 2012-09-23 06:23:44 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:23:44 --> Controller Class Initialized
DEBUG - 2012-09-23 06:23:44 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:23:44 --> Model Class Initialized
DEBUG - 2012-09-23 06:23:44 --> Model Class Initialized
DEBUG - 2012-09-23 06:23:53 --> Config Class Initialized
DEBUG - 2012-09-23 06:23:53 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:23:53 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:23:53 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:23:53 --> URI Class Initialized
DEBUG - 2012-09-23 06:23:53 --> Router Class Initialized
DEBUG - 2012-09-23 06:23:53 --> Output Class Initialized
DEBUG - 2012-09-23 06:23:53 --> Security Class Initialized
DEBUG - 2012-09-23 06:23:53 --> Input Class Initialized
DEBUG - 2012-09-23 06:23:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:23:53 --> Language Class Initialized
DEBUG - 2012-09-23 06:23:53 --> Loader Class Initialized
DEBUG - 2012-09-23 06:23:53 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:23:53 --> Controller Class Initialized
DEBUG - 2012-09-23 06:23:53 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:23:53 --> Model Class Initialized
DEBUG - 2012-09-23 06:23:53 --> Model Class Initialized
DEBUG - 2012-09-23 06:24:21 --> Config Class Initialized
DEBUG - 2012-09-23 06:24:21 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:24:21 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:24:21 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:24:21 --> URI Class Initialized
DEBUG - 2012-09-23 06:24:21 --> Router Class Initialized
DEBUG - 2012-09-23 06:24:21 --> Output Class Initialized
DEBUG - 2012-09-23 06:24:21 --> Security Class Initialized
DEBUG - 2012-09-23 06:24:21 --> Input Class Initialized
DEBUG - 2012-09-23 06:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:24:21 --> Language Class Initialized
DEBUG - 2012-09-23 06:24:21 --> Loader Class Initialized
DEBUG - 2012-09-23 06:24:21 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:24:21 --> Controller Class Initialized
DEBUG - 2012-09-23 06:24:21 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:24:21 --> Model Class Initialized
DEBUG - 2012-09-23 06:24:21 --> Model Class Initialized
DEBUG - 2012-09-23 06:24:21 --> File loaded: application/views/todo/view_v.php
DEBUG - 2012-09-23 06:24:21 --> Final output sent to browser
DEBUG - 2012-09-23 06:24:21 --> Total execution time: 0.0505
DEBUG - 2012-09-23 06:28:00 --> Config Class Initialized
DEBUG - 2012-09-23 06:28:00 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:28:00 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:28:00 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:28:00 --> URI Class Initialized
DEBUG - 2012-09-23 06:28:00 --> Router Class Initialized
DEBUG - 2012-09-23 06:28:00 --> Output Class Initialized
DEBUG - 2012-09-23 06:28:00 --> Security Class Initialized
DEBUG - 2012-09-23 06:28:00 --> Input Class Initialized
DEBUG - 2012-09-23 06:28:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:28:00 --> Language Class Initialized
DEBUG - 2012-09-23 06:28:00 --> Loader Class Initialized
DEBUG - 2012-09-23 06:28:00 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:28:00 --> Controller Class Initialized
DEBUG - 2012-09-23 06:28:00 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:28:00 --> Model Class Initialized
DEBUG - 2012-09-23 06:28:00 --> Model Class Initialized
DEBUG - 2012-09-23 06:28:00 --> File loaded: application/views/todo/view_v.php
DEBUG - 2012-09-23 06:28:00 --> Final output sent to browser
DEBUG - 2012-09-23 06:28:00 --> Total execution time: 0.0401
DEBUG - 2012-09-23 06:30:17 --> Config Class Initialized
DEBUG - 2012-09-23 06:30:17 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:30:17 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:30:17 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:30:17 --> URI Class Initialized
DEBUG - 2012-09-23 06:30:17 --> Router Class Initialized
DEBUG - 2012-09-23 06:30:17 --> Output Class Initialized
DEBUG - 2012-09-23 06:30:17 --> Security Class Initialized
DEBUG - 2012-09-23 06:30:17 --> Input Class Initialized
DEBUG - 2012-09-23 06:30:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:30:17 --> Language Class Initialized
DEBUG - 2012-09-23 06:30:17 --> Loader Class Initialized
DEBUG - 2012-09-23 06:30:17 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:30:17 --> Controller Class Initialized
DEBUG - 2012-09-23 06:30:17 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:30:17 --> Model Class Initialized
DEBUG - 2012-09-23 06:30:17 --> Model Class Initialized
DEBUG - 2012-09-23 06:30:17 --> File loaded: application/views/todo/view_v.php
DEBUG - 2012-09-23 06:30:17 --> Final output sent to browser
DEBUG - 2012-09-23 06:30:17 --> Total execution time: 0.0448
DEBUG - 2012-09-23 06:30:42 --> Config Class Initialized
DEBUG - 2012-09-23 06:30:42 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:30:42 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:30:42 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:30:42 --> URI Class Initialized
DEBUG - 2012-09-23 06:30:42 --> Router Class Initialized
DEBUG - 2012-09-23 06:30:42 --> Output Class Initialized
DEBUG - 2012-09-23 06:30:42 --> Security Class Initialized
DEBUG - 2012-09-23 06:30:42 --> Input Class Initialized
DEBUG - 2012-09-23 06:30:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:30:42 --> Language Class Initialized
DEBUG - 2012-09-23 06:30:42 --> Loader Class Initialized
DEBUG - 2012-09-23 06:30:42 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:30:42 --> Controller Class Initialized
DEBUG - 2012-09-23 06:30:42 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:30:42 --> Model Class Initialized
DEBUG - 2012-09-23 06:30:42 --> Model Class Initialized
DEBUG - 2012-09-23 06:30:42 --> File loaded: application/views/todo/view_v.php
DEBUG - 2012-09-23 06:30:42 --> Final output sent to browser
DEBUG - 2012-09-23 06:30:42 --> Total execution time: 0.0518
DEBUG - 2012-09-23 06:31:00 --> Config Class Initialized
DEBUG - 2012-09-23 06:31:00 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:31:00 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:31:00 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:31:00 --> URI Class Initialized
DEBUG - 2012-09-23 06:31:00 --> Router Class Initialized
DEBUG - 2012-09-23 06:31:00 --> Output Class Initialized
DEBUG - 2012-09-23 06:31:00 --> Security Class Initialized
DEBUG - 2012-09-23 06:31:00 --> Input Class Initialized
DEBUG - 2012-09-23 06:31:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:31:00 --> Language Class Initialized
DEBUG - 2012-09-23 06:31:00 --> Loader Class Initialized
DEBUG - 2012-09-23 06:31:00 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:31:00 --> Controller Class Initialized
DEBUG - 2012-09-23 06:31:00 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:31:00 --> Model Class Initialized
DEBUG - 2012-09-23 06:31:00 --> Model Class Initialized
DEBUG - 2012-09-23 06:31:00 --> DB Transaction Failure
ERROR - 2012-09-23 06:31:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'use ='1'' at line 1
DEBUG - 2012-09-23 06:31:00 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-09-23 06:37:48 --> Config Class Initialized
DEBUG - 2012-09-23 06:37:48 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:37:48 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:37:48 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:37:48 --> URI Class Initialized
DEBUG - 2012-09-23 06:37:48 --> Router Class Initialized
DEBUG - 2012-09-23 06:37:48 --> Output Class Initialized
DEBUG - 2012-09-23 06:37:48 --> Security Class Initialized
DEBUG - 2012-09-23 06:37:48 --> Input Class Initialized
DEBUG - 2012-09-23 06:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:37:48 --> Language Class Initialized
DEBUG - 2012-09-23 06:37:48 --> Loader Class Initialized
DEBUG - 2012-09-23 06:37:48 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:37:48 --> Controller Class Initialized
DEBUG - 2012-09-23 06:37:48 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:37:48 --> Model Class Initialized
DEBUG - 2012-09-23 06:37:48 --> Model Class Initialized
DEBUG - 2012-09-23 06:37:48 --> File loaded: application/views/todo/list_v.php
DEBUG - 2012-09-23 06:37:48 --> Final output sent to browser
DEBUG - 2012-09-23 06:37:48 --> Total execution time: 0.0558
DEBUG - 2012-09-23 06:38:05 --> Config Class Initialized
DEBUG - 2012-09-23 06:38:05 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:38:05 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:38:05 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:38:05 --> URI Class Initialized
DEBUG - 2012-09-23 06:38:05 --> Router Class Initialized
DEBUG - 2012-09-23 06:38:05 --> Output Class Initialized
DEBUG - 2012-09-23 06:38:05 --> Security Class Initialized
DEBUG - 2012-09-23 06:38:05 --> Input Class Initialized
DEBUG - 2012-09-23 06:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:38:05 --> Language Class Initialized
DEBUG - 2012-09-23 06:38:05 --> Loader Class Initialized
DEBUG - 2012-09-23 06:38:05 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:38:05 --> Controller Class Initialized
DEBUG - 2012-09-23 06:38:05 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:38:05 --> Model Class Initialized
DEBUG - 2012-09-23 06:38:05 --> Model Class Initialized
DEBUG - 2012-09-23 06:38:05 --> File loaded: application/views/todo/list_v.php
DEBUG - 2012-09-23 06:38:05 --> Final output sent to browser
DEBUG - 2012-09-23 06:38:05 --> Total execution time: 0.0480
DEBUG - 2012-09-23 06:38:50 --> Config Class Initialized
DEBUG - 2012-09-23 06:38:50 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:38:50 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:38:50 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:38:50 --> URI Class Initialized
DEBUG - 2012-09-23 06:38:50 --> Router Class Initialized
DEBUG - 2012-09-23 06:38:50 --> Output Class Initialized
DEBUG - 2012-09-23 06:38:50 --> Security Class Initialized
DEBUG - 2012-09-23 06:38:50 --> Input Class Initialized
DEBUG - 2012-09-23 06:38:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:38:50 --> Language Class Initialized
DEBUG - 2012-09-23 06:38:50 --> Loader Class Initialized
DEBUG - 2012-09-23 06:38:50 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:38:50 --> Controller Class Initialized
DEBUG - 2012-09-23 06:38:50 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:38:50 --> Model Class Initialized
DEBUG - 2012-09-23 06:38:50 --> Model Class Initialized
DEBUG - 2012-09-23 06:39:27 --> Config Class Initialized
DEBUG - 2012-09-23 06:39:27 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:39:27 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:39:27 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:39:27 --> URI Class Initialized
DEBUG - 2012-09-23 06:39:27 --> Router Class Initialized
DEBUG - 2012-09-23 06:39:27 --> Output Class Initialized
DEBUG - 2012-09-23 06:39:27 --> Security Class Initialized
DEBUG - 2012-09-23 06:39:27 --> Input Class Initialized
DEBUG - 2012-09-23 06:39:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:39:27 --> Language Class Initialized
DEBUG - 2012-09-23 06:39:27 --> Loader Class Initialized
DEBUG - 2012-09-23 06:39:27 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:39:27 --> Controller Class Initialized
DEBUG - 2012-09-23 06:39:27 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:39:27 --> Model Class Initialized
DEBUG - 2012-09-23 06:39:27 --> Model Class Initialized
DEBUG - 2012-09-23 06:39:27 --> File loaded: application/views/todo/list_v.php
DEBUG - 2012-09-23 06:39:27 --> Final output sent to browser
DEBUG - 2012-09-23 06:39:27 --> Total execution time: 0.0485
DEBUG - 2012-09-23 06:39:36 --> Config Class Initialized
DEBUG - 2012-09-23 06:39:36 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:39:36 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:39:36 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:39:36 --> URI Class Initialized
DEBUG - 2012-09-23 06:39:36 --> Router Class Initialized
DEBUG - 2012-09-23 06:39:36 --> Output Class Initialized
DEBUG - 2012-09-23 06:39:36 --> Security Class Initialized
DEBUG - 2012-09-23 06:39:36 --> Input Class Initialized
DEBUG - 2012-09-23 06:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:39:36 --> Language Class Initialized
DEBUG - 2012-09-23 06:39:36 --> Loader Class Initialized
DEBUG - 2012-09-23 06:39:36 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:39:36 --> Controller Class Initialized
DEBUG - 2012-09-23 06:39:36 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:39:36 --> Model Class Initialized
DEBUG - 2012-09-23 06:39:36 --> Model Class Initialized
ERROR - 2012-09-23 06:39:36 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 36
ERROR - 2012-09-23 06:39:36 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 37
ERROR - 2012-09-23 06:39:36 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 38
ERROR - 2012-09-23 06:39:36 --> Severity: Notice  --> Trying to get property of non-object F:\xampp\htdocs\todo\application\views\todo\view_v.php 44
DEBUG - 2012-09-23 06:39:36 --> File loaded: application/views/todo/view_v.php
DEBUG - 2012-09-23 06:39:36 --> Final output sent to browser
DEBUG - 2012-09-23 06:39:36 --> Total execution time: 0.0518
DEBUG - 2012-09-23 06:40:01 --> Config Class Initialized
DEBUG - 2012-09-23 06:40:01 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:40:01 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:40:01 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:40:01 --> URI Class Initialized
DEBUG - 2012-09-23 06:40:01 --> Router Class Initialized
DEBUG - 2012-09-23 06:40:01 --> Output Class Initialized
DEBUG - 2012-09-23 06:40:01 --> Security Class Initialized
DEBUG - 2012-09-23 06:40:01 --> Input Class Initialized
DEBUG - 2012-09-23 06:40:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:40:01 --> Language Class Initialized
DEBUG - 2012-09-23 06:40:01 --> Loader Class Initialized
DEBUG - 2012-09-23 06:40:01 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:40:01 --> Controller Class Initialized
DEBUG - 2012-09-23 06:40:01 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:40:01 --> Model Class Initialized
DEBUG - 2012-09-23 06:40:01 --> Model Class Initialized
DEBUG - 2012-09-23 06:40:01 --> File loaded: application/views/todo/list_v.php
DEBUG - 2012-09-23 06:40:01 --> Final output sent to browser
DEBUG - 2012-09-23 06:40:01 --> Total execution time: 0.0589
DEBUG - 2012-09-23 06:40:02 --> Config Class Initialized
DEBUG - 2012-09-23 06:40:02 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:40:02 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:40:02 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:40:02 --> URI Class Initialized
DEBUG - 2012-09-23 06:40:02 --> Router Class Initialized
DEBUG - 2012-09-23 06:40:02 --> Output Class Initialized
DEBUG - 2012-09-23 06:40:02 --> Security Class Initialized
DEBUG - 2012-09-23 06:40:02 --> Input Class Initialized
DEBUG - 2012-09-23 06:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:40:02 --> Language Class Initialized
DEBUG - 2012-09-23 06:40:02 --> Loader Class Initialized
DEBUG - 2012-09-23 06:40:02 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:40:02 --> Controller Class Initialized
DEBUG - 2012-09-23 06:40:02 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:40:02 --> Model Class Initialized
DEBUG - 2012-09-23 06:40:02 --> Model Class Initialized
DEBUG - 2012-09-23 06:40:02 --> File loaded: application/views/todo/view_v.php
DEBUG - 2012-09-23 06:40:02 --> Final output sent to browser
DEBUG - 2012-09-23 06:40:02 --> Total execution time: 0.0600
DEBUG - 2012-09-23 06:40:05 --> Config Class Initialized
DEBUG - 2012-09-23 06:40:05 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:40:05 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:40:05 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:40:05 --> URI Class Initialized
DEBUG - 2012-09-23 06:40:05 --> Router Class Initialized
DEBUG - 2012-09-23 06:40:05 --> Output Class Initialized
DEBUG - 2012-09-23 06:40:05 --> Security Class Initialized
DEBUG - 2012-09-23 06:40:05 --> Input Class Initialized
DEBUG - 2012-09-23 06:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:40:05 --> Language Class Initialized
DEBUG - 2012-09-23 06:40:05 --> Loader Class Initialized
DEBUG - 2012-09-23 06:40:05 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:40:05 --> Controller Class Initialized
DEBUG - 2012-09-23 06:40:05 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:40:05 --> Model Class Initialized
DEBUG - 2012-09-23 06:40:05 --> Model Class Initialized
DEBUG - 2012-09-23 06:40:05 --> File loaded: application/views/todo/view_v.php
DEBUG - 2012-09-23 06:40:05 --> Final output sent to browser
DEBUG - 2012-09-23 06:40:05 --> Total execution time: 0.0525
DEBUG - 2012-09-23 06:40:07 --> Config Class Initialized
DEBUG - 2012-09-23 06:40:07 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:40:07 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:40:07 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:40:07 --> URI Class Initialized
DEBUG - 2012-09-23 06:40:07 --> Router Class Initialized
DEBUG - 2012-09-23 06:40:07 --> Output Class Initialized
DEBUG - 2012-09-23 06:40:07 --> Security Class Initialized
DEBUG - 2012-09-23 06:40:07 --> Input Class Initialized
DEBUG - 2012-09-23 06:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:40:07 --> Language Class Initialized
DEBUG - 2012-09-23 06:40:07 --> Loader Class Initialized
DEBUG - 2012-09-23 06:40:07 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:40:07 --> Controller Class Initialized
DEBUG - 2012-09-23 06:40:07 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:40:07 --> Model Class Initialized
DEBUG - 2012-09-23 06:40:07 --> Model Class Initialized
DEBUG - 2012-09-23 06:40:07 --> File loaded: application/views/todo/view_v.php
DEBUG - 2012-09-23 06:40:07 --> Final output sent to browser
DEBUG - 2012-09-23 06:40:07 --> Total execution time: 0.0546
DEBUG - 2012-09-23 06:50:41 --> Config Class Initialized
DEBUG - 2012-09-23 06:50:41 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:50:41 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:50:41 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:50:41 --> URI Class Initialized
DEBUG - 2012-09-23 06:50:41 --> Router Class Initialized
DEBUG - 2012-09-23 06:50:41 --> Output Class Initialized
DEBUG - 2012-09-23 06:50:41 --> Security Class Initialized
DEBUG - 2012-09-23 06:50:41 --> Input Class Initialized
DEBUG - 2012-09-23 06:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:50:41 --> Language Class Initialized
DEBUG - 2012-09-23 06:50:41 --> Loader Class Initialized
DEBUG - 2012-09-23 06:50:41 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:50:41 --> Controller Class Initialized
DEBUG - 2012-09-23 06:50:41 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:50:41 --> Model Class Initialized
DEBUG - 2012-09-23 06:50:41 --> Model Class Initialized
DEBUG - 2012-09-23 06:50:41 --> File loaded: application/views/todo/view_v.php
DEBUG - 2012-09-23 06:50:41 --> Final output sent to browser
DEBUG - 2012-09-23 06:50:41 --> Total execution time: 0.0532
DEBUG - 2012-09-23 06:52:59 --> Config Class Initialized
DEBUG - 2012-09-23 06:52:59 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:52:59 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:52:59 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:52:59 --> URI Class Initialized
DEBUG - 2012-09-23 06:52:59 --> Router Class Initialized
DEBUG - 2012-09-23 06:52:59 --> Output Class Initialized
DEBUG - 2012-09-23 06:52:59 --> Security Class Initialized
DEBUG - 2012-09-23 06:52:59 --> Input Class Initialized
DEBUG - 2012-09-23 06:52:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:52:59 --> Language Class Initialized
DEBUG - 2012-09-23 06:52:59 --> Loader Class Initialized
DEBUG - 2012-09-23 06:52:59 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:52:59 --> Controller Class Initialized
DEBUG - 2012-09-23 06:52:59 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:52:59 --> Model Class Initialized
DEBUG - 2012-09-23 06:52:59 --> Model Class Initialized
DEBUG - 2012-09-23 06:52:59 --> File loaded: application/views/todo/view_v.php
DEBUG - 2012-09-23 06:52:59 --> Final output sent to browser
DEBUG - 2012-09-23 06:52:59 --> Total execution time: 0.0500
DEBUG - 2012-09-23 06:53:19 --> Config Class Initialized
DEBUG - 2012-09-23 06:53:19 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:53:19 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:53:19 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:53:19 --> URI Class Initialized
DEBUG - 2012-09-23 06:53:19 --> Router Class Initialized
DEBUG - 2012-09-23 06:53:19 --> Output Class Initialized
DEBUG - 2012-09-23 06:53:19 --> Security Class Initialized
DEBUG - 2012-09-23 06:53:19 --> Input Class Initialized
DEBUG - 2012-09-23 06:53:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:53:19 --> Language Class Initialized
DEBUG - 2012-09-23 06:53:19 --> Loader Class Initialized
DEBUG - 2012-09-23 06:53:19 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:53:19 --> Controller Class Initialized
DEBUG - 2012-09-23 06:53:19 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:53:19 --> Model Class Initialized
DEBUG - 2012-09-23 06:53:19 --> Model Class Initialized
DEBUG - 2012-09-23 06:53:19 --> File loaded: application/views/todo/list_v.php
DEBUG - 2012-09-23 06:53:19 --> Final output sent to browser
DEBUG - 2012-09-23 06:53:19 --> Total execution time: 0.0443
DEBUG - 2012-09-23 06:53:42 --> Config Class Initialized
DEBUG - 2012-09-23 06:53:42 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:53:42 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:53:42 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:53:42 --> URI Class Initialized
DEBUG - 2012-09-23 06:53:42 --> Router Class Initialized
DEBUG - 2012-09-23 06:53:42 --> Output Class Initialized
DEBUG - 2012-09-23 06:53:42 --> Security Class Initialized
DEBUG - 2012-09-23 06:53:42 --> Input Class Initialized
DEBUG - 2012-09-23 06:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:53:42 --> Language Class Initialized
DEBUG - 2012-09-23 06:53:42 --> Loader Class Initialized
DEBUG - 2012-09-23 06:53:42 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:53:42 --> Controller Class Initialized
DEBUG - 2012-09-23 06:53:42 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:53:42 --> Model Class Initialized
DEBUG - 2012-09-23 06:53:42 --> Model Class Initialized
DEBUG - 2012-09-23 06:53:42 --> File loaded: application/views/todo/write_v.php
DEBUG - 2012-09-23 06:53:42 --> Final output sent to browser
DEBUG - 2012-09-23 06:53:42 --> Total execution time: 0.0553
DEBUG - 2012-09-23 06:55:31 --> Config Class Initialized
DEBUG - 2012-09-23 06:55:31 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:55:31 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:55:31 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:55:31 --> URI Class Initialized
DEBUG - 2012-09-23 06:55:31 --> Router Class Initialized
DEBUG - 2012-09-23 06:55:31 --> Output Class Initialized
DEBUG - 2012-09-23 06:55:31 --> Security Class Initialized
DEBUG - 2012-09-23 06:55:31 --> Input Class Initialized
DEBUG - 2012-09-23 06:55:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:55:31 --> Language Class Initialized
DEBUG - 2012-09-23 06:55:31 --> Loader Class Initialized
DEBUG - 2012-09-23 06:55:31 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:55:31 --> Controller Class Initialized
DEBUG - 2012-09-23 06:55:31 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:55:31 --> Model Class Initialized
DEBUG - 2012-09-23 06:55:31 --> Model Class Initialized
DEBUG - 2012-09-23 06:55:31 --> File loaded: application/views/todo/write_v.php
DEBUG - 2012-09-23 06:55:31 --> Final output sent to browser
DEBUG - 2012-09-23 06:55:31 --> Total execution time: 0.0478
DEBUG - 2012-09-23 06:55:55 --> Config Class Initialized
DEBUG - 2012-09-23 06:55:55 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:55:55 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:55:55 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:55:55 --> URI Class Initialized
DEBUG - 2012-09-23 06:55:55 --> Router Class Initialized
DEBUG - 2012-09-23 06:55:55 --> Output Class Initialized
DEBUG - 2012-09-23 06:55:55 --> Security Class Initialized
DEBUG - 2012-09-23 06:55:55 --> Input Class Initialized
DEBUG - 2012-09-23 06:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:55:55 --> Language Class Initialized
DEBUG - 2012-09-23 06:55:55 --> Loader Class Initialized
DEBUG - 2012-09-23 06:55:55 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:55:55 --> Controller Class Initialized
DEBUG - 2012-09-23 06:55:55 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:55:55 --> Model Class Initialized
DEBUG - 2012-09-23 06:55:55 --> Model Class Initialized
DEBUG - 2012-09-23 06:55:55 --> File loaded: application/views/todo/write_v.php
DEBUG - 2012-09-23 06:55:55 --> Final output sent to browser
DEBUG - 2012-09-23 06:55:55 --> Total execution time: 0.0526
DEBUG - 2012-09-23 06:57:03 --> Config Class Initialized
DEBUG - 2012-09-23 06:57:03 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:57:03 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:57:03 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:57:03 --> URI Class Initialized
DEBUG - 2012-09-23 06:57:03 --> Router Class Initialized
DEBUG - 2012-09-23 06:57:03 --> Output Class Initialized
DEBUG - 2012-09-23 06:57:03 --> Security Class Initialized
DEBUG - 2012-09-23 06:57:03 --> Input Class Initialized
DEBUG - 2012-09-23 06:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:57:03 --> Language Class Initialized
DEBUG - 2012-09-23 06:57:03 --> Loader Class Initialized
DEBUG - 2012-09-23 06:57:03 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:57:03 --> Controller Class Initialized
DEBUG - 2012-09-23 06:57:03 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:57:03 --> Model Class Initialized
DEBUG - 2012-09-23 06:57:03 --> Model Class Initialized
DEBUG - 2012-09-23 06:57:03 --> File loaded: application/views/todo/write_v.php
DEBUG - 2012-09-23 06:57:03 --> Final output sent to browser
DEBUG - 2012-09-23 06:57:03 --> Total execution time: 0.0383
DEBUG - 2012-09-23 06:59:12 --> Config Class Initialized
DEBUG - 2012-09-23 06:59:12 --> Hooks Class Initialized
DEBUG - 2012-09-23 06:59:12 --> Utf8 Class Initialized
DEBUG - 2012-09-23 06:59:12 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 06:59:12 --> URI Class Initialized
DEBUG - 2012-09-23 06:59:12 --> Router Class Initialized
DEBUG - 2012-09-23 06:59:12 --> Output Class Initialized
DEBUG - 2012-09-23 06:59:12 --> Security Class Initialized
DEBUG - 2012-09-23 06:59:12 --> Input Class Initialized
DEBUG - 2012-09-23 06:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 06:59:12 --> Language Class Initialized
DEBUG - 2012-09-23 06:59:12 --> Loader Class Initialized
DEBUG - 2012-09-23 06:59:12 --> Helper loaded: date_helper
DEBUG - 2012-09-23 06:59:12 --> Controller Class Initialized
DEBUG - 2012-09-23 06:59:12 --> Database Driver Class Initialized
DEBUG - 2012-09-23 06:59:12 --> Model Class Initialized
DEBUG - 2012-09-23 06:59:12 --> Model Class Initialized
DEBUG - 2012-09-23 06:59:12 --> File loaded: application/views/todo/write_v.php
DEBUG - 2012-09-23 06:59:12 --> Final output sent to browser
DEBUG - 2012-09-23 06:59:12 --> Total execution time: 0.0493
DEBUG - 2012-09-23 07:02:35 --> Config Class Initialized
DEBUG - 2012-09-23 07:02:35 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:02:35 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:02:35 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:02:35 --> URI Class Initialized
DEBUG - 2012-09-23 07:02:35 --> Router Class Initialized
DEBUG - 2012-09-23 07:02:35 --> Output Class Initialized
DEBUG - 2012-09-23 07:02:35 --> Security Class Initialized
DEBUG - 2012-09-23 07:02:35 --> Input Class Initialized
DEBUG - 2012-09-23 07:02:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:02:35 --> Language Class Initialized
DEBUG - 2012-09-23 07:02:35 --> Loader Class Initialized
DEBUG - 2012-09-23 07:02:35 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:02:35 --> Controller Class Initialized
DEBUG - 2012-09-23 07:02:35 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:02:35 --> Model Class Initialized
DEBUG - 2012-09-23 07:02:35 --> Model Class Initialized
DEBUG - 2012-09-23 07:02:35 --> XSS Filtering completed
DEBUG - 2012-09-23 07:02:35 --> XSS Filtering completed
DEBUG - 2012-09-23 07:02:35 --> XSS Filtering completed
DEBUG - 2012-09-23 07:02:35 --> DB Transaction Failure
ERROR - 2012-09-23 07:02:35 --> Query error: Table 'todo.todo' doesn't exist
DEBUG - 2012-09-23 07:02:35 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-09-23 07:02:54 --> Config Class Initialized
DEBUG - 2012-09-23 07:02:54 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:02:54 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:02:54 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:02:54 --> URI Class Initialized
DEBUG - 2012-09-23 07:02:54 --> Router Class Initialized
DEBUG - 2012-09-23 07:02:54 --> Output Class Initialized
DEBUG - 2012-09-23 07:02:54 --> Security Class Initialized
DEBUG - 2012-09-23 07:02:54 --> Input Class Initialized
DEBUG - 2012-09-23 07:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:02:54 --> Language Class Initialized
DEBUG - 2012-09-23 07:02:54 --> Loader Class Initialized
DEBUG - 2012-09-23 07:02:54 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:02:54 --> Controller Class Initialized
DEBUG - 2012-09-23 07:02:54 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:02:54 --> Model Class Initialized
DEBUG - 2012-09-23 07:02:54 --> Model Class Initialized
DEBUG - 2012-09-23 07:02:54 --> XSS Filtering completed
DEBUG - 2012-09-23 07:02:54 --> XSS Filtering completed
DEBUG - 2012-09-23 07:02:54 --> XSS Filtering completed
DEBUG - 2012-09-23 07:02:54 --> DB Transaction Failure
ERROR - 2012-09-23 07:02:54 --> Query error: Unknown column '원고작성' in 'field list'
DEBUG - 2012-09-23 07:02:54 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-09-23 07:04:20 --> Config Class Initialized
DEBUG - 2012-09-23 07:04:20 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:04:20 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:04:20 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:04:20 --> URI Class Initialized
DEBUG - 2012-09-23 07:04:20 --> Router Class Initialized
DEBUG - 2012-09-23 07:04:20 --> Output Class Initialized
DEBUG - 2012-09-23 07:04:20 --> Security Class Initialized
DEBUG - 2012-09-23 07:04:20 --> Input Class Initialized
DEBUG - 2012-09-23 07:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:04:20 --> Language Class Initialized
DEBUG - 2012-09-23 07:04:20 --> Loader Class Initialized
DEBUG - 2012-09-23 07:04:20 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:04:20 --> Controller Class Initialized
DEBUG - 2012-09-23 07:04:20 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:04:20 --> Model Class Initialized
DEBUG - 2012-09-23 07:04:20 --> Model Class Initialized
DEBUG - 2012-09-23 07:04:20 --> XSS Filtering completed
DEBUG - 2012-09-23 07:04:20 --> XSS Filtering completed
DEBUG - 2012-09-23 07:04:20 --> XSS Filtering completed
DEBUG - 2012-09-23 07:05:07 --> Config Class Initialized
DEBUG - 2012-09-23 07:05:07 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:05:07 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:05:07 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:05:07 --> URI Class Initialized
DEBUG - 2012-09-23 07:05:07 --> Router Class Initialized
DEBUG - 2012-09-23 07:05:07 --> Output Class Initialized
DEBUG - 2012-09-23 07:05:07 --> Security Class Initialized
DEBUG - 2012-09-23 07:05:07 --> Input Class Initialized
DEBUG - 2012-09-23 07:05:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:05:07 --> Language Class Initialized
DEBUG - 2012-09-23 07:05:07 --> Loader Class Initialized
DEBUG - 2012-09-23 07:05:07 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:05:07 --> Controller Class Initialized
DEBUG - 2012-09-23 07:05:07 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:05:07 --> Model Class Initialized
DEBUG - 2012-09-23 07:05:07 --> Model Class Initialized
DEBUG - 2012-09-23 07:05:07 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:05:07 --> XSS Filtering completed
DEBUG - 2012-09-23 07:05:07 --> XSS Filtering completed
DEBUG - 2012-09-23 07:05:07 --> XSS Filtering completed
DEBUG - 2012-09-23 07:05:07 --> Config Class Initialized
DEBUG - 2012-09-23 07:05:07 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:05:07 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:05:07 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:05:07 --> URI Class Initialized
DEBUG - 2012-09-23 07:05:07 --> Router Class Initialized
ERROR - 2012-09-23 07:05:07 --> 404 Page Not Found --> todo
DEBUG - 2012-09-23 07:05:39 --> Config Class Initialized
DEBUG - 2012-09-23 07:05:39 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:05:39 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:05:39 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:05:39 --> URI Class Initialized
DEBUG - 2012-09-23 07:05:39 --> Router Class Initialized
DEBUG - 2012-09-23 07:05:39 --> Output Class Initialized
DEBUG - 2012-09-23 07:05:39 --> Security Class Initialized
DEBUG - 2012-09-23 07:05:39 --> Input Class Initialized
DEBUG - 2012-09-23 07:05:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:05:39 --> Language Class Initialized
DEBUG - 2012-09-23 07:05:39 --> Loader Class Initialized
DEBUG - 2012-09-23 07:05:39 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:05:39 --> Controller Class Initialized
DEBUG - 2012-09-23 07:05:39 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:05:39 --> Model Class Initialized
DEBUG - 2012-09-23 07:05:39 --> Model Class Initialized
DEBUG - 2012-09-23 07:05:39 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:05:39 --> File loaded: application/views/todo/list_v.php
DEBUG - 2012-09-23 07:05:39 --> Final output sent to browser
DEBUG - 2012-09-23 07:05:39 --> Total execution time: 0.0470
DEBUG - 2012-09-23 07:05:59 --> Config Class Initialized
DEBUG - 2012-09-23 07:05:59 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:05:59 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:05:59 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:05:59 --> URI Class Initialized
DEBUG - 2012-09-23 07:05:59 --> Router Class Initialized
DEBUG - 2012-09-23 07:05:59 --> Output Class Initialized
DEBUG - 2012-09-23 07:05:59 --> Security Class Initialized
DEBUG - 2012-09-23 07:05:59 --> Input Class Initialized
DEBUG - 2012-09-23 07:05:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:05:59 --> Language Class Initialized
DEBUG - 2012-09-23 07:05:59 --> Loader Class Initialized
DEBUG - 2012-09-23 07:05:59 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:05:59 --> Controller Class Initialized
DEBUG - 2012-09-23 07:05:59 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:05:59 --> Model Class Initialized
DEBUG - 2012-09-23 07:05:59 --> Model Class Initialized
DEBUG - 2012-09-23 07:05:59 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:05:59 --> File loaded: application/views/todo/view_v.php
DEBUG - 2012-09-23 07:05:59 --> Final output sent to browser
DEBUG - 2012-09-23 07:05:59 --> Total execution time: 0.0517
DEBUG - 2012-09-23 07:06:41 --> Config Class Initialized
DEBUG - 2012-09-23 07:06:41 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:06:41 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:06:41 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:06:41 --> URI Class Initialized
DEBUG - 2012-09-23 07:06:41 --> Router Class Initialized
DEBUG - 2012-09-23 07:06:41 --> Output Class Initialized
DEBUG - 2012-09-23 07:06:41 --> Security Class Initialized
DEBUG - 2012-09-23 07:06:41 --> Input Class Initialized
DEBUG - 2012-09-23 07:06:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:06:41 --> Language Class Initialized
DEBUG - 2012-09-23 07:06:41 --> Loader Class Initialized
DEBUG - 2012-09-23 07:06:41 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:06:41 --> Controller Class Initialized
DEBUG - 2012-09-23 07:06:41 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:06:41 --> Model Class Initialized
DEBUG - 2012-09-23 07:06:41 --> Model Class Initialized
DEBUG - 2012-09-23 07:06:41 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:06:41 --> File loaded: application/views/todo/list_v.php
DEBUG - 2012-09-23 07:06:41 --> Final output sent to browser
DEBUG - 2012-09-23 07:06:41 --> Total execution time: 0.0457
DEBUG - 2012-09-23 07:07:32 --> Config Class Initialized
DEBUG - 2012-09-23 07:07:32 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:07:32 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:07:32 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:07:32 --> URI Class Initialized
DEBUG - 2012-09-23 07:07:32 --> Router Class Initialized
DEBUG - 2012-09-23 07:07:32 --> Output Class Initialized
DEBUG - 2012-09-23 07:07:32 --> Security Class Initialized
DEBUG - 2012-09-23 07:07:32 --> Input Class Initialized
DEBUG - 2012-09-23 07:07:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:07:32 --> Language Class Initialized
DEBUG - 2012-09-23 07:07:32 --> Loader Class Initialized
DEBUG - 2012-09-23 07:07:32 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:07:32 --> Controller Class Initialized
DEBUG - 2012-09-23 07:07:32 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:07:32 --> Model Class Initialized
DEBUG - 2012-09-23 07:07:32 --> Model Class Initialized
DEBUG - 2012-09-23 07:07:32 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:07:32 --> File loaded: application/views/todo/list_v.php
DEBUG - 2012-09-23 07:07:32 --> Final output sent to browser
DEBUG - 2012-09-23 07:07:32 --> Total execution time: 0.0593
DEBUG - 2012-09-23 07:07:52 --> Config Class Initialized
DEBUG - 2012-09-23 07:07:52 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:07:52 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:07:52 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:07:52 --> URI Class Initialized
DEBUG - 2012-09-23 07:07:52 --> Router Class Initialized
DEBUG - 2012-09-23 07:07:52 --> Output Class Initialized
DEBUG - 2012-09-23 07:07:52 --> Security Class Initialized
DEBUG - 2012-09-23 07:07:52 --> Input Class Initialized
DEBUG - 2012-09-23 07:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:07:52 --> Language Class Initialized
DEBUG - 2012-09-23 07:07:52 --> Loader Class Initialized
DEBUG - 2012-09-23 07:07:52 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:07:52 --> Controller Class Initialized
DEBUG - 2012-09-23 07:07:52 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:07:52 --> Model Class Initialized
DEBUG - 2012-09-23 07:07:52 --> Model Class Initialized
DEBUG - 2012-09-23 07:07:52 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:07:52 --> File loaded: application/views/todo/view_v.php
DEBUG - 2012-09-23 07:07:52 --> Final output sent to browser
DEBUG - 2012-09-23 07:07:52 --> Total execution time: 0.0658
DEBUG - 2012-09-23 07:07:59 --> Config Class Initialized
DEBUG - 2012-09-23 07:07:59 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:07:59 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:07:59 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:07:59 --> URI Class Initialized
DEBUG - 2012-09-23 07:07:59 --> Router Class Initialized
DEBUG - 2012-09-23 07:07:59 --> Output Class Initialized
DEBUG - 2012-09-23 07:07:59 --> Security Class Initialized
DEBUG - 2012-09-23 07:07:59 --> Input Class Initialized
DEBUG - 2012-09-23 07:07:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:07:59 --> Language Class Initialized
DEBUG - 2012-09-23 07:07:59 --> Loader Class Initialized
DEBUG - 2012-09-23 07:07:59 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:07:59 --> Controller Class Initialized
DEBUG - 2012-09-23 07:07:59 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:07:59 --> Model Class Initialized
DEBUG - 2012-09-23 07:07:59 --> Model Class Initialized
DEBUG - 2012-09-23 07:07:59 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:08:46 --> Config Class Initialized
DEBUG - 2012-09-23 07:08:46 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:08:46 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:08:46 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:08:46 --> URI Class Initialized
DEBUG - 2012-09-23 07:08:46 --> Router Class Initialized
DEBUG - 2012-09-23 07:08:46 --> Output Class Initialized
DEBUG - 2012-09-23 07:08:46 --> Security Class Initialized
DEBUG - 2012-09-23 07:08:46 --> Input Class Initialized
DEBUG - 2012-09-23 07:08:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:08:46 --> Language Class Initialized
DEBUG - 2012-09-23 07:08:46 --> Loader Class Initialized
DEBUG - 2012-09-23 07:08:46 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:08:46 --> Controller Class Initialized
DEBUG - 2012-09-23 07:08:46 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:08:46 --> Model Class Initialized
DEBUG - 2012-09-23 07:08:46 --> Model Class Initialized
DEBUG - 2012-09-23 07:08:46 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:08:46 --> DB Transaction Failure
ERROR - 2012-09-23 07:08:46 --> Query error: Table 'todo.todo' doesn't exist
DEBUG - 2012-09-23 07:08:46 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-09-23 07:08:57 --> Config Class Initialized
DEBUG - 2012-09-23 07:08:57 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:08:57 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:08:57 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:08:57 --> URI Class Initialized
DEBUG - 2012-09-23 07:08:57 --> Router Class Initialized
DEBUG - 2012-09-23 07:08:57 --> Output Class Initialized
DEBUG - 2012-09-23 07:08:57 --> Security Class Initialized
DEBUG - 2012-09-23 07:08:57 --> Input Class Initialized
DEBUG - 2012-09-23 07:08:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:08:57 --> Language Class Initialized
DEBUG - 2012-09-23 07:08:57 --> Loader Class Initialized
DEBUG - 2012-09-23 07:08:57 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:08:57 --> Controller Class Initialized
DEBUG - 2012-09-23 07:08:57 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:08:57 --> Model Class Initialized
DEBUG - 2012-09-23 07:08:57 --> Model Class Initialized
DEBUG - 2012-09-23 07:08:57 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:08:57 --> Config Class Initialized
DEBUG - 2012-09-23 07:08:57 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:08:57 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:08:57 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:08:57 --> URI Class Initialized
DEBUG - 2012-09-23 07:08:57 --> Router Class Initialized
ERROR - 2012-09-23 07:08:57 --> 404 Page Not Found --> todo
DEBUG - 2012-09-23 07:09:35 --> Config Class Initialized
DEBUG - 2012-09-23 07:09:35 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:09:35 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:09:35 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:09:35 --> URI Class Initialized
DEBUG - 2012-09-23 07:09:35 --> Router Class Initialized
DEBUG - 2012-09-23 07:09:35 --> Output Class Initialized
DEBUG - 2012-09-23 07:09:35 --> Security Class Initialized
DEBUG - 2012-09-23 07:09:35 --> Input Class Initialized
DEBUG - 2012-09-23 07:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:09:35 --> Language Class Initialized
DEBUG - 2012-09-23 07:09:35 --> Loader Class Initialized
DEBUG - 2012-09-23 07:09:35 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:09:35 --> Controller Class Initialized
DEBUG - 2012-09-23 07:09:35 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:09:35 --> Model Class Initialized
DEBUG - 2012-09-23 07:09:35 --> Model Class Initialized
DEBUG - 2012-09-23 07:09:35 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:09:35 --> File loaded: application/views/todo/list_v.php
DEBUG - 2012-09-23 07:09:35 --> Final output sent to browser
DEBUG - 2012-09-23 07:09:35 --> Total execution time: 0.0489
DEBUG - 2012-09-23 07:10:10 --> Config Class Initialized
DEBUG - 2012-09-23 07:10:10 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:10:10 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:10:10 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:10:10 --> URI Class Initialized
DEBUG - 2012-09-23 07:10:10 --> Router Class Initialized
DEBUG - 2012-09-23 07:10:10 --> Output Class Initialized
DEBUG - 2012-09-23 07:10:10 --> Security Class Initialized
DEBUG - 2012-09-23 07:10:10 --> Input Class Initialized
DEBUG - 2012-09-23 07:10:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:10:10 --> Language Class Initialized
DEBUG - 2012-09-23 07:10:10 --> Loader Class Initialized
DEBUG - 2012-09-23 07:10:10 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:10:10 --> Controller Class Initialized
DEBUG - 2012-09-23 07:10:10 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:10:10 --> Model Class Initialized
DEBUG - 2012-09-23 07:10:10 --> Model Class Initialized
DEBUG - 2012-09-23 07:10:11 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:10:11 --> File loaded: application/views/todo/write_v.php
DEBUG - 2012-09-23 07:10:11 --> Final output sent to browser
DEBUG - 2012-09-23 07:10:11 --> Total execution time: 0.0520
DEBUG - 2012-09-23 07:10:12 --> Config Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:10:12 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:10:12 --> URI Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Router Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Output Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Security Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Input Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:10:12 --> Language Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Loader Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:10:12 --> Controller Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Model Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Model Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:10:12 --> XSS Filtering completed
DEBUG - 2012-09-23 07:10:12 --> XSS Filtering completed
DEBUG - 2012-09-23 07:10:12 --> XSS Filtering completed
DEBUG - 2012-09-23 07:10:12 --> Config Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:10:12 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:10:12 --> URI Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Router Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Output Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Security Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Input Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:10:12 --> Language Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Loader Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:10:12 --> Controller Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Model Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Model Class Initialized
DEBUG - 2012-09-23 07:10:12 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:10:13 --> File loaded: application/views/todo/list_v.php
DEBUG - 2012-09-23 07:10:13 --> Final output sent to browser
DEBUG - 2012-09-23 07:10:13 --> Total execution time: 0.0441
DEBUG - 2012-09-23 07:10:30 --> Config Class Initialized
DEBUG - 2012-09-23 07:10:30 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:10:30 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:10:30 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:10:30 --> URI Class Initialized
DEBUG - 2012-09-23 07:10:30 --> Router Class Initialized
DEBUG - 2012-09-23 07:10:30 --> Output Class Initialized
DEBUG - 2012-09-23 07:10:30 --> Security Class Initialized
DEBUG - 2012-09-23 07:10:30 --> Input Class Initialized
DEBUG - 2012-09-23 07:10:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:10:30 --> Language Class Initialized
DEBUG - 2012-09-23 07:10:30 --> Loader Class Initialized
DEBUG - 2012-09-23 07:10:30 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:10:30 --> Controller Class Initialized
DEBUG - 2012-09-23 07:10:30 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:10:30 --> Model Class Initialized
DEBUG - 2012-09-23 07:10:30 --> Model Class Initialized
DEBUG - 2012-09-23 07:10:30 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:10:30 --> File loaded: application/views/todo/view_v.php
DEBUG - 2012-09-23 07:10:30 --> Final output sent to browser
DEBUG - 2012-09-23 07:10:30 --> Total execution time: 0.0358
DEBUG - 2012-09-23 07:10:33 --> Config Class Initialized
DEBUG - 2012-09-23 07:10:33 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:10:33 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:10:33 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:10:33 --> URI Class Initialized
DEBUG - 2012-09-23 07:10:33 --> Router Class Initialized
DEBUG - 2012-09-23 07:10:33 --> Output Class Initialized
DEBUG - 2012-09-23 07:10:33 --> Security Class Initialized
DEBUG - 2012-09-23 07:10:33 --> Input Class Initialized
DEBUG - 2012-09-23 07:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:10:33 --> Language Class Initialized
DEBUG - 2012-09-23 07:10:33 --> Loader Class Initialized
DEBUG - 2012-09-23 07:10:33 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:10:33 --> Controller Class Initialized
DEBUG - 2012-09-23 07:10:33 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:10:33 --> Model Class Initialized
DEBUG - 2012-09-23 07:10:33 --> Model Class Initialized
DEBUG - 2012-09-23 07:10:33 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:10:33 --> File loaded: application/views/todo/view_v.php
DEBUG - 2012-09-23 07:10:33 --> Final output sent to browser
DEBUG - 2012-09-23 07:10:33 --> Total execution time: 0.0541
DEBUG - 2012-09-23 07:10:35 --> Config Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:10:35 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:10:35 --> URI Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Router Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Output Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Security Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Input Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:10:35 --> Language Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Loader Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:10:35 --> Controller Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Model Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Model Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:10:35 --> Config Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:10:35 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:10:35 --> URI Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Router Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Output Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Security Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Input Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:10:35 --> Language Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Loader Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:10:35 --> Controller Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Model Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Model Class Initialized
DEBUG - 2012-09-23 07:10:35 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:10:35 --> File loaded: application/views/todo/list_v.php
DEBUG - 2012-09-23 07:10:35 --> Final output sent to browser
DEBUG - 2012-09-23 07:10:35 --> Total execution time: 0.0356
DEBUG - 2012-09-23 07:11:04 --> Config Class Initialized
DEBUG - 2012-09-23 07:11:04 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:11:04 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:11:04 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:11:04 --> URI Class Initialized
DEBUG - 2012-09-23 07:11:04 --> Router Class Initialized
DEBUG - 2012-09-23 07:11:04 --> Output Class Initialized
DEBUG - 2012-09-23 07:11:04 --> Security Class Initialized
DEBUG - 2012-09-23 07:11:04 --> Input Class Initialized
DEBUG - 2012-09-23 07:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:11:04 --> Language Class Initialized
DEBUG - 2012-09-23 07:11:04 --> Loader Class Initialized
DEBUG - 2012-09-23 07:11:04 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:11:04 --> Controller Class Initialized
DEBUG - 2012-09-23 07:11:04 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:11:04 --> Model Class Initialized
DEBUG - 2012-09-23 07:11:04 --> Model Class Initialized
DEBUG - 2012-09-23 07:11:04 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:11:04 --> File loaded: application/views/todo/write_v.php
DEBUG - 2012-09-23 07:11:04 --> Final output sent to browser
DEBUG - 2012-09-23 07:11:04 --> Total execution time: 0.0511
DEBUG - 2012-09-23 07:11:05 --> Config Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:11:05 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:11:05 --> URI Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Router Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Output Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Security Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Input Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:11:05 --> Language Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Loader Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:11:05 --> Controller Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Model Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Model Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:11:05 --> XSS Filtering completed
DEBUG - 2012-09-23 07:11:05 --> XSS Filtering completed
DEBUG - 2012-09-23 07:11:05 --> XSS Filtering completed
DEBUG - 2012-09-23 07:11:05 --> Config Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:11:05 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:11:05 --> URI Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Router Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Output Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Security Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Input Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:11:05 --> Language Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Loader Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:11:05 --> Controller Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Model Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Model Class Initialized
DEBUG - 2012-09-23 07:11:05 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:11:05 --> File loaded: application/views/todo/list_v.php
DEBUG - 2012-09-23 07:11:05 --> Final output sent to browser
DEBUG - 2012-09-23 07:11:05 --> Total execution time: 0.0437
DEBUG - 2012-09-23 07:11:22 --> Config Class Initialized
DEBUG - 2012-09-23 07:11:22 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:11:22 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:11:22 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:11:22 --> URI Class Initialized
DEBUG - 2012-09-23 07:11:22 --> Router Class Initialized
DEBUG - 2012-09-23 07:11:22 --> Output Class Initialized
DEBUG - 2012-09-23 07:11:22 --> Security Class Initialized
DEBUG - 2012-09-23 07:11:22 --> Input Class Initialized
DEBUG - 2012-09-23 07:11:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:11:22 --> Language Class Initialized
DEBUG - 2012-09-23 07:11:22 --> Loader Class Initialized
DEBUG - 2012-09-23 07:11:22 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:11:22 --> Controller Class Initialized
DEBUG - 2012-09-23 07:11:22 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:11:22 --> Model Class Initialized
DEBUG - 2012-09-23 07:11:22 --> Model Class Initialized
DEBUG - 2012-09-23 07:11:22 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:11:22 --> File loaded: application/views/todo/write_v.php
DEBUG - 2012-09-23 07:11:22 --> Final output sent to browser
DEBUG - 2012-09-23 07:11:22 --> Total execution time: 0.0447
DEBUG - 2012-09-23 07:11:24 --> Config Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:11:24 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:11:24 --> URI Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Router Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Output Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Security Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Input Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:11:24 --> Language Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Loader Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:11:24 --> Controller Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Model Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Model Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:11:24 --> XSS Filtering completed
DEBUG - 2012-09-23 07:11:24 --> XSS Filtering completed
DEBUG - 2012-09-23 07:11:24 --> XSS Filtering completed
DEBUG - 2012-09-23 07:11:24 --> Config Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:11:24 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:11:24 --> URI Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Router Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Output Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Security Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Input Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:11:24 --> Language Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Loader Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:11:24 --> Controller Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Model Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Model Class Initialized
DEBUG - 2012-09-23 07:11:24 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:11:24 --> File loaded: application/views/todo/list_v.php
DEBUG - 2012-09-23 07:11:24 --> Final output sent to browser
DEBUG - 2012-09-23 07:11:24 --> Total execution time: 0.0370
DEBUG - 2012-09-23 07:12:21 --> Config Class Initialized
DEBUG - 2012-09-23 07:12:21 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:12:21 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:12:21 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:12:21 --> URI Class Initialized
DEBUG - 2012-09-23 07:12:21 --> Router Class Initialized
DEBUG - 2012-09-23 07:12:21 --> Output Class Initialized
DEBUG - 2012-09-23 07:12:21 --> Security Class Initialized
DEBUG - 2012-09-23 07:12:21 --> Input Class Initialized
DEBUG - 2012-09-23 07:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:12:21 --> Language Class Initialized
DEBUG - 2012-09-23 07:12:21 --> Loader Class Initialized
DEBUG - 2012-09-23 07:12:21 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:12:21 --> Controller Class Initialized
DEBUG - 2012-09-23 07:12:21 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:12:21 --> Model Class Initialized
DEBUG - 2012-09-23 07:12:21 --> Model Class Initialized
DEBUG - 2012-09-23 07:12:21 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:12:21 --> File loaded: application/views/todo/write_v.php
DEBUG - 2012-09-23 07:12:21 --> Final output sent to browser
DEBUG - 2012-09-23 07:12:21 --> Total execution time: 0.0398
DEBUG - 2012-09-23 07:12:23 --> Config Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:12:23 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:12:23 --> URI Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Router Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Output Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Security Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Input Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:12:23 --> Language Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Loader Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:12:23 --> Controller Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Model Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Model Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:12:23 --> XSS Filtering completed
DEBUG - 2012-09-23 07:12:23 --> XSS Filtering completed
DEBUG - 2012-09-23 07:12:23 --> XSS Filtering completed
DEBUG - 2012-09-23 07:12:23 --> Config Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:12:23 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:12:23 --> URI Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Router Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Output Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Security Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Input Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:12:23 --> Language Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Loader Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:12:23 --> Controller Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Model Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Model Class Initialized
DEBUG - 2012-09-23 07:12:23 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:12:23 --> File loaded: application/views/todo/list_v.php
DEBUG - 2012-09-23 07:12:23 --> Final output sent to browser
DEBUG - 2012-09-23 07:12:23 --> Total execution time: 0.0453
DEBUG - 2012-09-23 07:12:36 --> Config Class Initialized
DEBUG - 2012-09-23 07:12:36 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:12:36 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:12:36 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:12:36 --> URI Class Initialized
DEBUG - 2012-09-23 07:12:36 --> Router Class Initialized
DEBUG - 2012-09-23 07:12:36 --> Output Class Initialized
DEBUG - 2012-09-23 07:12:36 --> Security Class Initialized
DEBUG - 2012-09-23 07:12:36 --> Input Class Initialized
DEBUG - 2012-09-23 07:12:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:12:36 --> Language Class Initialized
DEBUG - 2012-09-23 07:12:36 --> Loader Class Initialized
DEBUG - 2012-09-23 07:12:36 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:12:36 --> Controller Class Initialized
DEBUG - 2012-09-23 07:12:36 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:12:36 --> Model Class Initialized
DEBUG - 2012-09-23 07:12:36 --> Model Class Initialized
DEBUG - 2012-09-23 07:12:36 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:12:36 --> File loaded: application/views/todo/write_v.php
DEBUG - 2012-09-23 07:12:36 --> Final output sent to browser
DEBUG - 2012-09-23 07:12:36 --> Total execution time: 0.0433
DEBUG - 2012-09-23 07:13:11 --> Config Class Initialized
DEBUG - 2012-09-23 07:13:11 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:13:11 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:13:11 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:13:11 --> URI Class Initialized
DEBUG - 2012-09-23 07:13:11 --> Router Class Initialized
DEBUG - 2012-09-23 07:13:11 --> Output Class Initialized
DEBUG - 2012-09-23 07:13:11 --> Security Class Initialized
DEBUG - 2012-09-23 07:13:11 --> Input Class Initialized
DEBUG - 2012-09-23 07:13:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:13:11 --> Language Class Initialized
DEBUG - 2012-09-23 07:13:11 --> Loader Class Initialized
DEBUG - 2012-09-23 07:13:11 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:13:11 --> Controller Class Initialized
DEBUG - 2012-09-23 07:13:11 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:13:11 --> Model Class Initialized
DEBUG - 2012-09-23 07:13:11 --> Model Class Initialized
DEBUG - 2012-09-23 07:13:11 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:13:11 --> File loaded: application/views/todo/write_v.php
DEBUG - 2012-09-23 07:13:11 --> Final output sent to browser
DEBUG - 2012-09-23 07:13:11 --> Total execution time: 0.0516
DEBUG - 2012-09-23 07:13:20 --> Config Class Initialized
DEBUG - 2012-09-23 07:13:20 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:13:20 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:13:20 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:13:20 --> URI Class Initialized
DEBUG - 2012-09-23 07:13:20 --> Router Class Initialized
DEBUG - 2012-09-23 07:13:20 --> Output Class Initialized
DEBUG - 2012-09-23 07:13:20 --> Security Class Initialized
DEBUG - 2012-09-23 07:13:20 --> Input Class Initialized
DEBUG - 2012-09-23 07:13:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:13:20 --> Language Class Initialized
DEBUG - 2012-09-23 07:13:20 --> Loader Class Initialized
DEBUG - 2012-09-23 07:13:20 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:13:20 --> Controller Class Initialized
DEBUG - 2012-09-23 07:13:20 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:13:20 --> Model Class Initialized
DEBUG - 2012-09-23 07:13:20 --> Model Class Initialized
DEBUG - 2012-09-23 07:13:20 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:13:20 --> XSS Filtering completed
DEBUG - 2012-09-23 07:13:20 --> XSS Filtering completed
DEBUG - 2012-09-23 07:13:20 --> XSS Filtering completed
DEBUG - 2012-09-23 07:13:20 --> Config Class Initialized
DEBUG - 2012-09-23 07:13:20 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:13:20 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:13:20 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:13:20 --> URI Class Initialized
DEBUG - 2012-09-23 07:13:20 --> Router Class Initialized
DEBUG - 2012-09-23 07:13:20 --> Output Class Initialized
DEBUG - 2012-09-23 07:13:20 --> Security Class Initialized
DEBUG - 2012-09-23 07:13:20 --> Input Class Initialized
DEBUG - 2012-09-23 07:13:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:13:20 --> Language Class Initialized
DEBUG - 2012-09-23 07:13:21 --> Loader Class Initialized
DEBUG - 2012-09-23 07:13:21 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:13:21 --> Controller Class Initialized
DEBUG - 2012-09-23 07:13:21 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:13:21 --> Model Class Initialized
DEBUG - 2012-09-23 07:13:21 --> Model Class Initialized
DEBUG - 2012-09-23 07:13:21 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:13:21 --> File loaded: application/views/todo/list_v.php
DEBUG - 2012-09-23 07:13:21 --> Final output sent to browser
DEBUG - 2012-09-23 07:13:21 --> Total execution time: 0.0457
DEBUG - 2012-09-23 07:13:23 --> Config Class Initialized
DEBUG - 2012-09-23 07:13:23 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:13:23 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:13:23 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:13:23 --> URI Class Initialized
DEBUG - 2012-09-23 07:13:23 --> Router Class Initialized
DEBUG - 2012-09-23 07:13:23 --> Output Class Initialized
DEBUG - 2012-09-23 07:13:23 --> Security Class Initialized
DEBUG - 2012-09-23 07:13:23 --> Input Class Initialized
DEBUG - 2012-09-23 07:13:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:13:23 --> Language Class Initialized
DEBUG - 2012-09-23 07:13:23 --> Loader Class Initialized
DEBUG - 2012-09-23 07:13:23 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:13:23 --> Controller Class Initialized
DEBUG - 2012-09-23 07:13:23 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:13:23 --> Model Class Initialized
DEBUG - 2012-09-23 07:13:23 --> Model Class Initialized
DEBUG - 2012-09-23 07:13:23 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:13:23 --> File loaded: application/views/todo/view_v.php
DEBUG - 2012-09-23 07:13:23 --> Final output sent to browser
DEBUG - 2012-09-23 07:13:23 --> Total execution time: 0.0669
DEBUG - 2012-09-23 07:13:51 --> Config Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:13:51 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:13:51 --> URI Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Router Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Output Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Security Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Input Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:13:51 --> Language Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Loader Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:13:51 --> Controller Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Model Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Model Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:13:51 --> Config Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:13:51 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:13:51 --> URI Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Router Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Output Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Security Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Input Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:13:51 --> Language Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Loader Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:13:51 --> Controller Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Model Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Model Class Initialized
DEBUG - 2012-09-23 07:13:51 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:13:51 --> File loaded: application/views/todo/list_v.php
DEBUG - 2012-09-23 07:13:51 --> Final output sent to browser
DEBUG - 2012-09-23 07:13:51 --> Total execution time: 0.0355
DEBUG - 2012-09-23 07:21:04 --> Config Class Initialized
DEBUG - 2012-09-23 07:21:04 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:21:04 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:21:04 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:21:04 --> URI Class Initialized
DEBUG - 2012-09-23 07:21:04 --> Router Class Initialized
DEBUG - 2012-09-23 07:21:04 --> Output Class Initialized
DEBUG - 2012-09-23 07:21:04 --> Security Class Initialized
DEBUG - 2012-09-23 07:21:04 --> Input Class Initialized
DEBUG - 2012-09-23 07:21:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:21:04 --> Language Class Initialized
DEBUG - 2012-09-23 07:21:04 --> Loader Class Initialized
DEBUG - 2012-09-23 07:21:04 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:21:04 --> Controller Class Initialized
DEBUG - 2012-09-23 07:21:04 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:21:04 --> Model Class Initialized
DEBUG - 2012-09-23 07:21:04 --> Model Class Initialized
DEBUG - 2012-09-23 07:21:04 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:21:04 --> File loaded: application/views/todo/list_v.php
DEBUG - 2012-09-23 07:21:04 --> Final output sent to browser
DEBUG - 2012-09-23 07:21:04 --> Total execution time: 0.0539
DEBUG - 2012-09-23 07:21:06 --> Config Class Initialized
DEBUG - 2012-09-23 07:21:06 --> Hooks Class Initialized
DEBUG - 2012-09-23 07:21:06 --> Utf8 Class Initialized
DEBUG - 2012-09-23 07:21:06 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 07:21:06 --> URI Class Initialized
DEBUG - 2012-09-23 07:21:06 --> Router Class Initialized
DEBUG - 2012-09-23 07:21:06 --> Output Class Initialized
DEBUG - 2012-09-23 07:21:06 --> Security Class Initialized
DEBUG - 2012-09-23 07:21:06 --> Input Class Initialized
DEBUG - 2012-09-23 07:21:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 07:21:06 --> Language Class Initialized
DEBUG - 2012-09-23 07:21:06 --> Loader Class Initialized
DEBUG - 2012-09-23 07:21:06 --> Helper loaded: date_helper
DEBUG - 2012-09-23 07:21:06 --> Controller Class Initialized
DEBUG - 2012-09-23 07:21:06 --> Database Driver Class Initialized
DEBUG - 2012-09-23 07:21:06 --> Model Class Initialized
DEBUG - 2012-09-23 07:21:06 --> Model Class Initialized
DEBUG - 2012-09-23 07:21:06 --> Helper loaded: url_helper
DEBUG - 2012-09-23 07:21:06 --> File loaded: application/views/todo/view_v.php
DEBUG - 2012-09-23 07:21:06 --> Final output sent to browser
DEBUG - 2012-09-23 07:21:06 --> Total execution time: 0.0562
DEBUG - 2012-09-23 09:13:13 --> Config Class Initialized
DEBUG - 2012-09-23 09:13:13 --> Hooks Class Initialized
DEBUG - 2012-09-23 09:13:13 --> Utf8 Class Initialized
DEBUG - 2012-09-23 09:13:13 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 09:13:13 --> URI Class Initialized
DEBUG - 2012-09-23 09:13:13 --> Router Class Initialized
DEBUG - 2012-09-23 09:13:13 --> Output Class Initialized
DEBUG - 2012-09-23 09:13:13 --> Security Class Initialized
DEBUG - 2012-09-23 09:13:13 --> Input Class Initialized
DEBUG - 2012-09-23 09:13:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 09:13:13 --> Language Class Initialized
DEBUG - 2012-09-23 09:13:13 --> Loader Class Initialized
DEBUG - 2012-09-23 09:13:13 --> Helper loaded: date_helper
DEBUG - 2012-09-23 09:13:13 --> Controller Class Initialized
DEBUG - 2012-09-23 09:13:13 --> Database Driver Class Initialized
DEBUG - 2012-09-23 09:13:13 --> Model Class Initialized
DEBUG - 2012-09-23 09:13:13 --> Model Class Initialized
DEBUG - 2012-09-23 09:13:13 --> Helper loaded: url_helper
DEBUG - 2012-09-23 09:13:13 --> File loaded: application/views/todo/view_v.php
DEBUG - 2012-09-23 09:13:13 --> Final output sent to browser
DEBUG - 2012-09-23 09:13:13 --> Total execution time: 0.0552
DEBUG - 2012-09-23 10:06:40 --> Config Class Initialized
DEBUG - 2012-09-23 10:06:40 --> Hooks Class Initialized
DEBUG - 2012-09-23 10:06:40 --> Utf8 Class Initialized
DEBUG - 2012-09-23 10:06:40 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 10:06:40 --> URI Class Initialized
DEBUG - 2012-09-23 10:06:40 --> Router Class Initialized
DEBUG - 2012-09-23 10:06:40 --> Output Class Initialized
DEBUG - 2012-09-23 10:06:40 --> Security Class Initialized
DEBUG - 2012-09-23 10:06:40 --> Input Class Initialized
DEBUG - 2012-09-23 10:06:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 10:06:40 --> Language Class Initialized
DEBUG - 2012-09-23 10:06:40 --> Loader Class Initialized
DEBUG - 2012-09-23 10:06:40 --> Helper loaded: date_helper
DEBUG - 2012-09-23 10:06:40 --> Controller Class Initialized
DEBUG - 2012-09-23 10:06:41 --> Database Driver Class Initialized
DEBUG - 2012-09-23 10:06:41 --> Model Class Initialized
DEBUG - 2012-09-23 10:06:41 --> Model Class Initialized
DEBUG - 2012-09-23 10:06:41 --> Helper loaded: url_helper
DEBUG - 2012-09-23 10:06:41 --> File loaded: application/views/todo/list_v.php
DEBUG - 2012-09-23 10:06:41 --> Final output sent to browser
DEBUG - 2012-09-23 10:06:41 --> Total execution time: 0.0728
DEBUG - 2012-09-23 10:29:55 --> Config Class Initialized
DEBUG - 2012-09-23 10:29:55 --> Hooks Class Initialized
DEBUG - 2012-09-23 10:29:55 --> Utf8 Class Initialized
DEBUG - 2012-09-23 10:29:55 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 10:29:55 --> URI Class Initialized
DEBUG - 2012-09-23 10:29:55 --> Router Class Initialized
DEBUG - 2012-09-23 10:29:55 --> Output Class Initialized
DEBUG - 2012-09-23 10:29:55 --> Security Class Initialized
DEBUG - 2012-09-23 10:29:55 --> Input Class Initialized
DEBUG - 2012-09-23 10:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 10:29:55 --> Language Class Initialized
DEBUG - 2012-09-23 10:29:55 --> Loader Class Initialized
DEBUG - 2012-09-23 10:29:55 --> Helper loaded: date_helper
DEBUG - 2012-09-23 10:29:55 --> Controller Class Initialized
DEBUG - 2012-09-23 10:29:55 --> Database Driver Class Initialized
DEBUG - 2012-09-23 10:29:55 --> Model Class Initialized
DEBUG - 2012-09-23 10:29:55 --> Model Class Initialized
DEBUG - 2012-09-23 10:29:55 --> Helper loaded: url_helper
DEBUG - 2012-09-23 10:29:55 --> File loaded: application/views/todo/list_v.php
DEBUG - 2012-09-23 10:29:55 --> Final output sent to browser
DEBUG - 2012-09-23 10:29:55 --> Total execution time: 0.0454
DEBUG - 2012-09-23 10:38:06 --> Config Class Initialized
DEBUG - 2012-09-23 10:38:06 --> Hooks Class Initialized
DEBUG - 2012-09-23 10:38:06 --> Utf8 Class Initialized
DEBUG - 2012-09-23 10:38:06 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 10:38:06 --> URI Class Initialized
DEBUG - 2012-09-23 10:38:06 --> Router Class Initialized
DEBUG - 2012-09-23 10:38:06 --> Output Class Initialized
DEBUG - 2012-09-23 10:38:06 --> Security Class Initialized
DEBUG - 2012-09-23 10:38:06 --> Input Class Initialized
DEBUG - 2012-09-23 10:38:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 10:38:06 --> Language Class Initialized
DEBUG - 2012-09-23 10:38:06 --> Loader Class Initialized
DEBUG - 2012-09-23 10:38:06 --> Helper loaded: date_helper
DEBUG - 2012-09-23 10:38:06 --> Controller Class Initialized
DEBUG - 2012-09-23 10:38:06 --> Database Driver Class Initialized
DEBUG - 2012-09-23 10:38:06 --> Model Class Initialized
DEBUG - 2012-09-23 10:38:06 --> Model Class Initialized
DEBUG - 2012-09-23 10:38:06 --> Helper loaded: url_helper
DEBUG - 2012-09-23 10:38:06 --> File loaded: application/views/todo/list_v.php
DEBUG - 2012-09-23 10:38:06 --> Final output sent to browser
DEBUG - 2012-09-23 10:38:06 --> Total execution time: 0.0549
DEBUG - 2012-09-23 10:41:31 --> Config Class Initialized
DEBUG - 2012-09-23 10:41:31 --> Hooks Class Initialized
DEBUG - 2012-09-23 10:41:31 --> Utf8 Class Initialized
DEBUG - 2012-09-23 10:41:31 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 10:41:31 --> URI Class Initialized
DEBUG - 2012-09-23 10:41:31 --> Router Class Initialized
DEBUG - 2012-09-23 10:41:31 --> Output Class Initialized
DEBUG - 2012-09-23 10:41:31 --> Security Class Initialized
DEBUG - 2012-09-23 10:41:32 --> Input Class Initialized
DEBUG - 2012-09-23 10:41:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 10:41:32 --> Language Class Initialized
DEBUG - 2012-09-23 10:41:32 --> Loader Class Initialized
DEBUG - 2012-09-23 10:41:32 --> Helper loaded: date_helper
DEBUG - 2012-09-23 10:41:32 --> Controller Class Initialized
DEBUG - 2012-09-23 10:41:32 --> Database Driver Class Initialized
DEBUG - 2012-09-23 10:41:32 --> Model Class Initialized
DEBUG - 2012-09-23 10:41:32 --> Model Class Initialized
DEBUG - 2012-09-23 10:41:32 --> Helper loaded: url_helper
DEBUG - 2012-09-23 10:41:32 --> File loaded: application/views/todo/list_v.php
DEBUG - 2012-09-23 10:41:32 --> Final output sent to browser
DEBUG - 2012-09-23 10:41:32 --> Total execution time: 0.0463
DEBUG - 2012-09-23 10:41:36 --> Config Class Initialized
DEBUG - 2012-09-23 10:41:36 --> Hooks Class Initialized
DEBUG - 2012-09-23 10:41:36 --> Utf8 Class Initialized
DEBUG - 2012-09-23 10:41:36 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 10:41:36 --> URI Class Initialized
DEBUG - 2012-09-23 10:41:36 --> Router Class Initialized
DEBUG - 2012-09-23 10:41:36 --> Output Class Initialized
DEBUG - 2012-09-23 10:41:36 --> Security Class Initialized
DEBUG - 2012-09-23 10:41:36 --> Input Class Initialized
DEBUG - 2012-09-23 10:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 10:41:36 --> Language Class Initialized
DEBUG - 2012-09-23 10:41:36 --> Loader Class Initialized
DEBUG - 2012-09-23 10:41:36 --> Helper loaded: date_helper
DEBUG - 2012-09-23 10:41:36 --> Controller Class Initialized
DEBUG - 2012-09-23 10:41:36 --> Database Driver Class Initialized
DEBUG - 2012-09-23 10:41:36 --> Model Class Initialized
DEBUG - 2012-09-23 10:41:36 --> Model Class Initialized
DEBUG - 2012-09-23 10:41:36 --> Helper loaded: url_helper
DEBUG - 2012-09-23 10:41:36 --> File loaded: application/views/todo/list_v.php
DEBUG - 2012-09-23 10:41:36 --> Final output sent to browser
DEBUG - 2012-09-23 10:41:36 --> Total execution time: 0.0506
DEBUG - 2012-09-23 10:42:11 --> Config Class Initialized
DEBUG - 2012-09-23 10:42:11 --> Hooks Class Initialized
DEBUG - 2012-09-23 10:42:11 --> Utf8 Class Initialized
DEBUG - 2012-09-23 10:42:11 --> UTF-8 Support Enabled
DEBUG - 2012-09-23 10:42:11 --> URI Class Initialized
DEBUG - 2012-09-23 10:42:11 --> Router Class Initialized
DEBUG - 2012-09-23 10:42:11 --> Output Class Initialized
DEBUG - 2012-09-23 10:42:11 --> Security Class Initialized
DEBUG - 2012-09-23 10:42:11 --> Input Class Initialized
DEBUG - 2012-09-23 10:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-23 10:42:11 --> Language Class Initialized
DEBUG - 2012-09-23 10:42:11 --> Loader Class Initialized
DEBUG - 2012-09-23 10:42:11 --> Helper loaded: date_helper
DEBUG - 2012-09-23 10:42:11 --> Controller Class Initialized
DEBUG - 2012-09-23 10:42:11 --> Database Driver Class Initialized
DEBUG - 2012-09-23 10:42:11 --> Model Class Initialized
DEBUG - 2012-09-23 10:42:11 --> Model Class Initialized
DEBUG - 2012-09-23 10:42:11 --> Helper loaded: url_helper
DEBUG - 2012-09-23 10:42:11 --> File loaded: application/views/todo/list_v.php
DEBUG - 2012-09-23 10:42:11 --> Final output sent to browser
DEBUG - 2012-09-23 10:42:11 --> Total execution time: 0.0652
