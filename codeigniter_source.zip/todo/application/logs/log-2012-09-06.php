<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-09-06 14:34:47 --> Config Class Initialized
DEBUG - 2012-09-06 14:34:47 --> Hooks Class Initialized
DEBUG - 2012-09-06 14:34:47 --> Utf8 Class Initialized
DEBUG - 2012-09-06 14:34:47 --> UTF-8 Support Enabled
DEBUG - 2012-09-06 14:34:47 --> URI Class Initialized
DEBUG - 2012-09-06 14:34:47 --> Router Class Initialized
DEBUG - 2012-09-06 14:34:48 --> No URI present. Default controller set.
DEBUG - 2012-09-06 14:34:48 --> Output Class Initialized
DEBUG - 2012-09-06 14:34:48 --> Security Class Initialized
DEBUG - 2012-09-06 14:34:48 --> Input Class Initialized
DEBUG - 2012-09-06 14:34:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-06 14:34:48 --> Language Class Initialized
DEBUG - 2012-09-06 14:34:48 --> Loader Class Initialized
DEBUG - 2012-09-06 14:34:48 --> Helper loaded: date_helper
DEBUG - 2012-09-06 14:34:48 --> Controller Class Initialized
DEBUG - 2012-09-06 14:34:48 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-09-06 14:34:48 --> Final output sent to browser
DEBUG - 2012-09-06 14:34:48 --> Total execution time: 0.2906
