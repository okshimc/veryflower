<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-07-14 09:27:25 --> Config Class Initialized
DEBUG - 2012-07-14 09:27:25 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:27:25 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:27:25 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:27:25 --> URI Class Initialized
DEBUG - 2012-07-14 09:27:25 --> Router Class Initialized
DEBUG - 2012-07-14 09:27:25 --> Output Class Initialized
DEBUG - 2012-07-14 09:27:25 --> Security Class Initialized
DEBUG - 2012-07-14 09:27:25 --> Input Class Initialized
DEBUG - 2012-07-14 09:27:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:27:25 --> Language Class Initialized
DEBUG - 2012-07-14 09:27:25 --> Loader Class Initialized
DEBUG - 2012-07-14 09:27:25 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:27:25 --> Controller Class Initialized
DEBUG - 2012-07-14 09:27:25 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:27:25 --> Model Class Initialized
DEBUG - 2012-07-14 09:27:25 --> Model Class Initialized
DEBUG - 2012-07-14 09:27:25 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:27:25 --> Pagination Class Initialized
DEBUG - 2012-07-14 09:27:25 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-14 09:27:25 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-14 09:27:25 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-14 09:27:25 --> Helper loaded: text_helper
DEBUG - 2012-07-14 09:27:25 --> Final output sent to browser
DEBUG - 2012-07-14 09:27:25 --> Total execution time: 0.1317
DEBUG - 2012-07-14 09:27:37 --> Config Class Initialized
DEBUG - 2012-07-14 09:27:37 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:27:37 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:27:37 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:27:37 --> URI Class Initialized
DEBUG - 2012-07-14 09:27:37 --> Router Class Initialized
DEBUG - 2012-07-14 09:27:37 --> Output Class Initialized
DEBUG - 2012-07-14 09:27:37 --> Security Class Initialized
DEBUG - 2012-07-14 09:27:37 --> Input Class Initialized
DEBUG - 2012-07-14 09:27:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:27:37 --> Language Class Initialized
DEBUG - 2012-07-14 09:27:37 --> Loader Class Initialized
DEBUG - 2012-07-14 09:27:37 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:27:37 --> Controller Class Initialized
DEBUG - 2012-07-14 09:27:37 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:27:37 --> Model Class Initialized
DEBUG - 2012-07-14 09:27:37 --> Model Class Initialized
DEBUG - 2012-07-14 09:27:37 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:27:37 --> Pagination Class Initialized
DEBUG - 2012-07-14 09:27:37 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-14 09:27:37 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-14 09:27:37 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-14 09:27:37 --> Helper loaded: text_helper
DEBUG - 2012-07-14 09:27:37 --> Final output sent to browser
DEBUG - 2012-07-14 09:27:37 --> Total execution time: 0.0737
DEBUG - 2012-07-14 09:27:40 --> Config Class Initialized
DEBUG - 2012-07-14 09:27:40 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:27:40 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:27:40 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:27:40 --> URI Class Initialized
DEBUG - 2012-07-14 09:27:40 --> Router Class Initialized
DEBUG - 2012-07-14 09:27:40 --> Output Class Initialized
DEBUG - 2012-07-14 09:27:40 --> Security Class Initialized
DEBUG - 2012-07-14 09:27:40 --> Input Class Initialized
DEBUG - 2012-07-14 09:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:27:40 --> Language Class Initialized
DEBUG - 2012-07-14 09:27:40 --> Loader Class Initialized
DEBUG - 2012-07-14 09:27:40 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:27:40 --> Controller Class Initialized
DEBUG - 2012-07-14 09:27:40 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:27:40 --> Model Class Initialized
DEBUG - 2012-07-14 09:27:40 --> Model Class Initialized
DEBUG - 2012-07-14 09:27:40 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:27:40 --> Pagination Class Initialized
DEBUG - 2012-07-14 09:27:40 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-14 09:27:40 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-14 09:27:40 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-14 09:27:40 --> Helper loaded: text_helper
DEBUG - 2012-07-14 09:27:40 --> Final output sent to browser
DEBUG - 2012-07-14 09:27:40 --> Total execution time: 0.0649
DEBUG - 2012-07-14 09:27:50 --> Config Class Initialized
DEBUG - 2012-07-14 09:27:50 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:27:50 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:27:50 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:27:50 --> URI Class Initialized
DEBUG - 2012-07-14 09:27:50 --> Router Class Initialized
DEBUG - 2012-07-14 09:27:50 --> Output Class Initialized
DEBUG - 2012-07-14 09:27:50 --> Security Class Initialized
DEBUG - 2012-07-14 09:27:50 --> Input Class Initialized
DEBUG - 2012-07-14 09:27:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:27:50 --> Language Class Initialized
DEBUG - 2012-07-14 09:27:50 --> Loader Class Initialized
DEBUG - 2012-07-14 09:27:50 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:27:50 --> Controller Class Initialized
DEBUG - 2012-07-14 09:27:50 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:27:50 --> Model Class Initialized
DEBUG - 2012-07-14 09:27:50 --> Model Class Initialized
DEBUG - 2012-07-14 09:27:50 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:27:50 --> Pagination Class Initialized
DEBUG - 2012-07-14 09:27:50 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-14 09:27:50 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-14 09:27:50 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-14 09:27:50 --> Helper loaded: text_helper
DEBUG - 2012-07-14 09:27:50 --> Final output sent to browser
DEBUG - 2012-07-14 09:27:50 --> Total execution time: 0.0604
DEBUG - 2012-07-14 09:27:53 --> Config Class Initialized
DEBUG - 2012-07-14 09:27:53 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:27:53 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:27:53 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:27:53 --> URI Class Initialized
DEBUG - 2012-07-14 09:27:53 --> Router Class Initialized
DEBUG - 2012-07-14 09:27:53 --> Output Class Initialized
DEBUG - 2012-07-14 09:27:53 --> Security Class Initialized
DEBUG - 2012-07-14 09:27:53 --> Input Class Initialized
DEBUG - 2012-07-14 09:27:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:27:53 --> Language Class Initialized
DEBUG - 2012-07-14 09:27:53 --> Loader Class Initialized
DEBUG - 2012-07-14 09:27:53 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:27:53 --> Controller Class Initialized
DEBUG - 2012-07-14 09:27:53 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:27:53 --> Model Class Initialized
DEBUG - 2012-07-14 09:27:53 --> Model Class Initialized
DEBUG - 2012-07-14 09:27:53 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:27:53 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-07-14 09:27:53 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-14 09:27:53 --> Final output sent to browser
DEBUG - 2012-07-14 09:27:53 --> Total execution time: 0.0639
DEBUG - 2012-07-14 09:27:58 --> Config Class Initialized
DEBUG - 2012-07-14 09:27:58 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:27:58 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:27:58 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:27:58 --> URI Class Initialized
DEBUG - 2012-07-14 09:27:58 --> Router Class Initialized
DEBUG - 2012-07-14 09:27:58 --> Output Class Initialized
DEBUG - 2012-07-14 09:27:58 --> Security Class Initialized
DEBUG - 2012-07-14 09:27:58 --> Input Class Initialized
DEBUG - 2012-07-14 09:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:27:58 --> Language Class Initialized
DEBUG - 2012-07-14 09:27:58 --> Loader Class Initialized
DEBUG - 2012-07-14 09:27:58 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:27:58 --> Controller Class Initialized
DEBUG - 2012-07-14 09:27:58 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:27:58 --> Model Class Initialized
DEBUG - 2012-07-14 09:27:58 --> Model Class Initialized
DEBUG - 2012-07-14 09:27:58 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:27:58 --> Helper loaded: alert_helper
DEBUG - 2012-07-14 09:27:59 --> Config Class Initialized
DEBUG - 2012-07-14 09:27:59 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:27:59 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:27:59 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:27:59 --> URI Class Initialized
DEBUG - 2012-07-14 09:27:59 --> Router Class Initialized
DEBUG - 2012-07-14 09:27:59 --> Output Class Initialized
DEBUG - 2012-07-14 09:27:59 --> Security Class Initialized
DEBUG - 2012-07-14 09:27:59 --> Input Class Initialized
DEBUG - 2012-07-14 09:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:27:59 --> Language Class Initialized
DEBUG - 2012-07-14 09:27:59 --> Loader Class Initialized
DEBUG - 2012-07-14 09:27:59 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:27:59 --> Controller Class Initialized
DEBUG - 2012-07-14 09:27:59 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:27:59 --> Model Class Initialized
DEBUG - 2012-07-14 09:27:59 --> Model Class Initialized
DEBUG - 2012-07-14 09:27:59 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:27:59 --> Pagination Class Initialized
DEBUG - 2012-07-14 09:27:59 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-14 09:27:59 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-14 09:27:59 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-14 09:27:59 --> Helper loaded: text_helper
DEBUG - 2012-07-14 09:27:59 --> Final output sent to browser
DEBUG - 2012-07-14 09:27:59 --> Total execution time: 0.0491
DEBUG - 2012-07-14 09:28:00 --> Config Class Initialized
DEBUG - 2012-07-14 09:28:00 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:28:00 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:28:00 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:28:00 --> URI Class Initialized
DEBUG - 2012-07-14 09:28:00 --> Router Class Initialized
DEBUG - 2012-07-14 09:28:00 --> Output Class Initialized
DEBUG - 2012-07-14 09:28:00 --> Security Class Initialized
DEBUG - 2012-07-14 09:28:00 --> Input Class Initialized
DEBUG - 2012-07-14 09:28:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:28:00 --> Language Class Initialized
DEBUG - 2012-07-14 09:28:00 --> Loader Class Initialized
DEBUG - 2012-07-14 09:28:00 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:28:00 --> Controller Class Initialized
DEBUG - 2012-07-14 09:28:00 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:28:00 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:00 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:00 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:28:00 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-07-14 09:28:00 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-14 09:28:00 --> Final output sent to browser
DEBUG - 2012-07-14 09:28:00 --> Total execution time: 0.0624
DEBUG - 2012-07-14 09:28:01 --> Config Class Initialized
DEBUG - 2012-07-14 09:28:01 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:28:01 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:28:01 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:28:01 --> URI Class Initialized
DEBUG - 2012-07-14 09:28:01 --> Router Class Initialized
DEBUG - 2012-07-14 09:28:01 --> Output Class Initialized
DEBUG - 2012-07-14 09:28:01 --> Security Class Initialized
DEBUG - 2012-07-14 09:28:01 --> Input Class Initialized
DEBUG - 2012-07-14 09:28:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:28:01 --> Language Class Initialized
DEBUG - 2012-07-14 09:28:01 --> Loader Class Initialized
DEBUG - 2012-07-14 09:28:01 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:28:01 --> Controller Class Initialized
DEBUG - 2012-07-14 09:28:01 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:28:01 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:01 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:01 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:28:01 --> Helper loaded: alert_helper
DEBUG - 2012-07-14 09:28:02 --> Config Class Initialized
DEBUG - 2012-07-14 09:28:02 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:28:02 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:28:02 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:28:02 --> URI Class Initialized
DEBUG - 2012-07-14 09:28:02 --> Router Class Initialized
DEBUG - 2012-07-14 09:28:02 --> Output Class Initialized
DEBUG - 2012-07-14 09:28:02 --> Security Class Initialized
DEBUG - 2012-07-14 09:28:02 --> Input Class Initialized
DEBUG - 2012-07-14 09:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:28:02 --> Language Class Initialized
DEBUG - 2012-07-14 09:28:02 --> Loader Class Initialized
DEBUG - 2012-07-14 09:28:02 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:28:02 --> Controller Class Initialized
DEBUG - 2012-07-14 09:28:02 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:28:02 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:02 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:02 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:28:02 --> Pagination Class Initialized
DEBUG - 2012-07-14 09:28:02 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-14 09:28:02 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-14 09:28:02 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-14 09:28:02 --> Helper loaded: text_helper
DEBUG - 2012-07-14 09:28:02 --> Final output sent to browser
DEBUG - 2012-07-14 09:28:02 --> Total execution time: 0.0504
DEBUG - 2012-07-14 09:28:04 --> Config Class Initialized
DEBUG - 2012-07-14 09:28:04 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:28:04 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:28:04 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:28:04 --> URI Class Initialized
DEBUG - 2012-07-14 09:28:04 --> Router Class Initialized
DEBUG - 2012-07-14 09:28:04 --> Output Class Initialized
DEBUG - 2012-07-14 09:28:04 --> Security Class Initialized
DEBUG - 2012-07-14 09:28:04 --> Input Class Initialized
DEBUG - 2012-07-14 09:28:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:28:04 --> Language Class Initialized
DEBUG - 2012-07-14 09:28:04 --> Loader Class Initialized
DEBUG - 2012-07-14 09:28:04 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:28:04 --> Controller Class Initialized
DEBUG - 2012-07-14 09:28:04 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:28:04 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:04 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:04 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:28:04 --> Pagination Class Initialized
DEBUG - 2012-07-14 09:28:04 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-14 09:28:04 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-14 09:28:04 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-14 09:28:04 --> Helper loaded: text_helper
DEBUG - 2012-07-14 09:28:04 --> Final output sent to browser
DEBUG - 2012-07-14 09:28:04 --> Total execution time: 0.0594
DEBUG - 2012-07-14 09:28:06 --> Config Class Initialized
DEBUG - 2012-07-14 09:28:06 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:28:06 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:28:06 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:28:06 --> URI Class Initialized
DEBUG - 2012-07-14 09:28:06 --> Router Class Initialized
DEBUG - 2012-07-14 09:28:06 --> Output Class Initialized
DEBUG - 2012-07-14 09:28:06 --> Security Class Initialized
DEBUG - 2012-07-14 09:28:06 --> Input Class Initialized
DEBUG - 2012-07-14 09:28:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:28:06 --> Language Class Initialized
DEBUG - 2012-07-14 09:28:06 --> Loader Class Initialized
DEBUG - 2012-07-14 09:28:06 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:28:06 --> Controller Class Initialized
DEBUG - 2012-07-14 09:28:06 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:28:06 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:06 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:06 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:28:06 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-07-14 09:28:06 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-14 09:28:06 --> Final output sent to browser
DEBUG - 2012-07-14 09:28:06 --> Total execution time: 0.0597
DEBUG - 2012-07-14 09:28:07 --> Config Class Initialized
DEBUG - 2012-07-14 09:28:07 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:28:07 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:28:07 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:28:07 --> URI Class Initialized
DEBUG - 2012-07-14 09:28:07 --> Router Class Initialized
DEBUG - 2012-07-14 09:28:07 --> Output Class Initialized
DEBUG - 2012-07-14 09:28:07 --> Security Class Initialized
DEBUG - 2012-07-14 09:28:07 --> Input Class Initialized
DEBUG - 2012-07-14 09:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:28:07 --> Language Class Initialized
DEBUG - 2012-07-14 09:28:07 --> Loader Class Initialized
DEBUG - 2012-07-14 09:28:07 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:28:07 --> Controller Class Initialized
DEBUG - 2012-07-14 09:28:07 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:28:07 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:07 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:07 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:28:07 --> Helper loaded: alert_helper
DEBUG - 2012-07-14 09:28:08 --> Config Class Initialized
DEBUG - 2012-07-14 09:28:08 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:28:08 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:28:08 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:28:08 --> URI Class Initialized
DEBUG - 2012-07-14 09:28:08 --> Router Class Initialized
DEBUG - 2012-07-14 09:28:08 --> Output Class Initialized
DEBUG - 2012-07-14 09:28:08 --> Security Class Initialized
DEBUG - 2012-07-14 09:28:08 --> Input Class Initialized
DEBUG - 2012-07-14 09:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:28:08 --> Language Class Initialized
DEBUG - 2012-07-14 09:28:08 --> Loader Class Initialized
DEBUG - 2012-07-14 09:28:08 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:28:08 --> Controller Class Initialized
DEBUG - 2012-07-14 09:28:08 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:28:08 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:08 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:08 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:28:08 --> Pagination Class Initialized
DEBUG - 2012-07-14 09:28:08 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-14 09:28:08 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-14 09:28:08 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-14 09:28:08 --> Helper loaded: text_helper
DEBUG - 2012-07-14 09:28:08 --> Final output sent to browser
DEBUG - 2012-07-14 09:28:08 --> Total execution time: 0.0486
DEBUG - 2012-07-14 09:28:10 --> Config Class Initialized
DEBUG - 2012-07-14 09:28:10 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:28:10 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:28:10 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:28:10 --> URI Class Initialized
DEBUG - 2012-07-14 09:28:10 --> Router Class Initialized
DEBUG - 2012-07-14 09:28:10 --> Output Class Initialized
DEBUG - 2012-07-14 09:28:10 --> Security Class Initialized
DEBUG - 2012-07-14 09:28:10 --> Input Class Initialized
DEBUG - 2012-07-14 09:28:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:28:10 --> Language Class Initialized
DEBUG - 2012-07-14 09:28:10 --> Loader Class Initialized
DEBUG - 2012-07-14 09:28:10 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:28:10 --> Controller Class Initialized
DEBUG - 2012-07-14 09:28:10 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:28:10 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:10 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:10 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:28:10 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-07-14 09:28:10 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-14 09:28:10 --> Final output sent to browser
DEBUG - 2012-07-14 09:28:10 --> Total execution time: 0.0435
DEBUG - 2012-07-14 09:28:11 --> Config Class Initialized
DEBUG - 2012-07-14 09:28:11 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:28:11 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:28:11 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:28:11 --> URI Class Initialized
DEBUG - 2012-07-14 09:28:11 --> Router Class Initialized
DEBUG - 2012-07-14 09:28:11 --> Output Class Initialized
DEBUG - 2012-07-14 09:28:11 --> Security Class Initialized
DEBUG - 2012-07-14 09:28:11 --> Input Class Initialized
DEBUG - 2012-07-14 09:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:28:11 --> Language Class Initialized
DEBUG - 2012-07-14 09:28:11 --> Loader Class Initialized
DEBUG - 2012-07-14 09:28:11 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:28:11 --> Controller Class Initialized
DEBUG - 2012-07-14 09:28:11 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:28:11 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:11 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:11 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:28:11 --> Helper loaded: alert_helper
DEBUG - 2012-07-14 09:28:12 --> Config Class Initialized
DEBUG - 2012-07-14 09:28:12 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:28:12 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:28:12 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:28:12 --> URI Class Initialized
DEBUG - 2012-07-14 09:28:12 --> Router Class Initialized
DEBUG - 2012-07-14 09:28:12 --> Output Class Initialized
DEBUG - 2012-07-14 09:28:12 --> Security Class Initialized
DEBUG - 2012-07-14 09:28:12 --> Input Class Initialized
DEBUG - 2012-07-14 09:28:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:28:12 --> Language Class Initialized
DEBUG - 2012-07-14 09:28:12 --> Loader Class Initialized
DEBUG - 2012-07-14 09:28:12 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:28:12 --> Controller Class Initialized
DEBUG - 2012-07-14 09:28:12 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:28:12 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:12 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:12 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:28:12 --> Pagination Class Initialized
DEBUG - 2012-07-14 09:28:12 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-14 09:28:12 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-14 09:28:12 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-14 09:28:12 --> Helper loaded: text_helper
DEBUG - 2012-07-14 09:28:12 --> Final output sent to browser
DEBUG - 2012-07-14 09:28:12 --> Total execution time: 0.0505
DEBUG - 2012-07-14 09:28:13 --> Config Class Initialized
DEBUG - 2012-07-14 09:28:13 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:28:13 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:28:13 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:28:13 --> URI Class Initialized
DEBUG - 2012-07-14 09:28:13 --> Router Class Initialized
DEBUG - 2012-07-14 09:28:13 --> Output Class Initialized
DEBUG - 2012-07-14 09:28:13 --> Security Class Initialized
DEBUG - 2012-07-14 09:28:13 --> Input Class Initialized
DEBUG - 2012-07-14 09:28:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:28:13 --> Language Class Initialized
DEBUG - 2012-07-14 09:28:13 --> Loader Class Initialized
DEBUG - 2012-07-14 09:28:13 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:28:13 --> Controller Class Initialized
DEBUG - 2012-07-14 09:28:13 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:28:13 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:13 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:13 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:28:13 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-07-14 09:28:13 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-14 09:28:13 --> Final output sent to browser
DEBUG - 2012-07-14 09:28:13 --> Total execution time: 0.0661
DEBUG - 2012-07-14 09:28:14 --> Config Class Initialized
DEBUG - 2012-07-14 09:28:14 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:28:14 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:28:14 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:28:14 --> URI Class Initialized
DEBUG - 2012-07-14 09:28:14 --> Router Class Initialized
DEBUG - 2012-07-14 09:28:14 --> Output Class Initialized
DEBUG - 2012-07-14 09:28:14 --> Security Class Initialized
DEBUG - 2012-07-14 09:28:14 --> Input Class Initialized
DEBUG - 2012-07-14 09:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:28:14 --> Language Class Initialized
DEBUG - 2012-07-14 09:28:14 --> Loader Class Initialized
DEBUG - 2012-07-14 09:28:14 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:28:14 --> Controller Class Initialized
DEBUG - 2012-07-14 09:28:14 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:28:14 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:14 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:14 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:28:14 --> Helper loaded: alert_helper
DEBUG - 2012-07-14 09:28:15 --> Config Class Initialized
DEBUG - 2012-07-14 09:28:15 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:28:15 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:28:15 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:28:15 --> URI Class Initialized
DEBUG - 2012-07-14 09:28:15 --> Router Class Initialized
DEBUG - 2012-07-14 09:28:15 --> Output Class Initialized
DEBUG - 2012-07-14 09:28:15 --> Security Class Initialized
DEBUG - 2012-07-14 09:28:15 --> Input Class Initialized
DEBUG - 2012-07-14 09:28:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:28:15 --> Language Class Initialized
DEBUG - 2012-07-14 09:28:15 --> Loader Class Initialized
DEBUG - 2012-07-14 09:28:15 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:28:15 --> Controller Class Initialized
DEBUG - 2012-07-14 09:28:15 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:28:15 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:15 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:15 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:28:15 --> Pagination Class Initialized
DEBUG - 2012-07-14 09:28:15 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-14 09:28:15 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-14 09:28:15 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-14 09:28:15 --> Helper loaded: text_helper
DEBUG - 2012-07-14 09:28:15 --> Final output sent to browser
DEBUG - 2012-07-14 09:28:15 --> Total execution time: 0.0502
DEBUG - 2012-07-14 09:28:16 --> Config Class Initialized
DEBUG - 2012-07-14 09:28:16 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:28:16 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:28:16 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:28:16 --> URI Class Initialized
DEBUG - 2012-07-14 09:28:16 --> Router Class Initialized
DEBUG - 2012-07-14 09:28:16 --> Output Class Initialized
DEBUG - 2012-07-14 09:28:16 --> Security Class Initialized
DEBUG - 2012-07-14 09:28:16 --> Input Class Initialized
DEBUG - 2012-07-14 09:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:28:16 --> Language Class Initialized
DEBUG - 2012-07-14 09:28:16 --> Loader Class Initialized
DEBUG - 2012-07-14 09:28:16 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:28:16 --> Controller Class Initialized
DEBUG - 2012-07-14 09:28:16 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:28:16 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:16 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:16 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:28:16 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-07-14 09:28:16 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-14 09:28:16 --> Final output sent to browser
DEBUG - 2012-07-14 09:28:16 --> Total execution time: 0.0567
DEBUG - 2012-07-14 09:28:17 --> Config Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:28:17 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:28:17 --> URI Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Router Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Output Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Security Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Input Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:28:17 --> Language Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Loader Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:28:17 --> Controller Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:17 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:28:17 --> Helper loaded: alert_helper
DEBUG - 2012-07-14 09:28:17 --> Config Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:28:17 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:28:17 --> URI Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Router Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Output Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Security Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Input Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:28:17 --> Language Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Loader Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:28:17 --> Controller Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:17 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:17 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:28:17 --> Pagination Class Initialized
DEBUG - 2012-07-14 09:28:17 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-14 09:28:17 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-14 09:28:17 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-14 09:28:17 --> Helper loaded: text_helper
DEBUG - 2012-07-14 09:28:17 --> Final output sent to browser
DEBUG - 2012-07-14 09:28:17 --> Total execution time: 0.0648
DEBUG - 2012-07-14 09:28:18 --> Config Class Initialized
DEBUG - 2012-07-14 09:28:18 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:28:18 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:28:18 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:28:18 --> URI Class Initialized
DEBUG - 2012-07-14 09:28:18 --> Router Class Initialized
DEBUG - 2012-07-14 09:28:18 --> Output Class Initialized
DEBUG - 2012-07-14 09:28:18 --> Security Class Initialized
DEBUG - 2012-07-14 09:28:18 --> Input Class Initialized
DEBUG - 2012-07-14 09:28:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:28:18 --> Language Class Initialized
DEBUG - 2012-07-14 09:28:18 --> Loader Class Initialized
DEBUG - 2012-07-14 09:28:18 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:28:18 --> Controller Class Initialized
DEBUG - 2012-07-14 09:28:18 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:28:18 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:18 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:18 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:28:18 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-07-14 09:28:18 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-14 09:28:18 --> Final output sent to browser
DEBUG - 2012-07-14 09:28:18 --> Total execution time: 0.0720
DEBUG - 2012-07-14 09:28:19 --> Config Class Initialized
DEBUG - 2012-07-14 09:28:19 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:28:19 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:28:19 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:28:19 --> URI Class Initialized
DEBUG - 2012-07-14 09:28:19 --> Router Class Initialized
DEBUG - 2012-07-14 09:28:19 --> Output Class Initialized
DEBUG - 2012-07-14 09:28:19 --> Security Class Initialized
DEBUG - 2012-07-14 09:28:19 --> Input Class Initialized
DEBUG - 2012-07-14 09:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:28:19 --> Language Class Initialized
DEBUG - 2012-07-14 09:28:19 --> Loader Class Initialized
DEBUG - 2012-07-14 09:28:19 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:28:19 --> Controller Class Initialized
DEBUG - 2012-07-14 09:28:19 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:28:19 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:19 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:19 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:28:19 --> Helper loaded: alert_helper
DEBUG - 2012-07-14 09:28:21 --> Config Class Initialized
DEBUG - 2012-07-14 09:28:21 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:28:21 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:28:21 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:28:21 --> URI Class Initialized
DEBUG - 2012-07-14 09:28:21 --> Router Class Initialized
DEBUG - 2012-07-14 09:28:21 --> Output Class Initialized
DEBUG - 2012-07-14 09:28:21 --> Security Class Initialized
DEBUG - 2012-07-14 09:28:21 --> Input Class Initialized
DEBUG - 2012-07-14 09:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:28:21 --> Language Class Initialized
DEBUG - 2012-07-14 09:28:21 --> Loader Class Initialized
DEBUG - 2012-07-14 09:28:21 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:28:21 --> Controller Class Initialized
DEBUG - 2012-07-14 09:28:21 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:28:21 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:21 --> Model Class Initialized
DEBUG - 2012-07-14 09:28:21 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:28:21 --> Pagination Class Initialized
DEBUG - 2012-07-14 09:28:21 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-14 09:28:21 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-14 09:28:21 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-14 09:28:21 --> Helper loaded: text_helper
DEBUG - 2012-07-14 09:28:21 --> Final output sent to browser
DEBUG - 2012-07-14 09:28:21 --> Total execution time: 0.0484
DEBUG - 2012-07-14 09:45:53 --> Config Class Initialized
DEBUG - 2012-07-14 09:45:53 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:45:53 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:45:53 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:45:53 --> URI Class Initialized
DEBUG - 2012-07-14 09:45:53 --> Router Class Initialized
DEBUG - 2012-07-14 09:45:53 --> Output Class Initialized
DEBUG - 2012-07-14 09:45:53 --> Security Class Initialized
DEBUG - 2012-07-14 09:45:53 --> Input Class Initialized
DEBUG - 2012-07-14 09:45:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:45:53 --> Language Class Initialized
DEBUG - 2012-07-14 09:45:53 --> Loader Class Initialized
DEBUG - 2012-07-14 09:45:53 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:45:53 --> Controller Class Initialized
DEBUG - 2012-07-14 09:45:53 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:45:53 --> Model Class Initialized
DEBUG - 2012-07-14 09:45:53 --> Model Class Initialized
DEBUG - 2012-07-14 09:45:53 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:45:53 --> Pagination Class Initialized
DEBUG - 2012-07-14 09:45:53 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-14 09:45:53 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-14 09:45:53 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-14 09:45:53 --> Helper loaded: text_helper
DEBUG - 2012-07-14 09:45:53 --> Final output sent to browser
DEBUG - 2012-07-14 09:45:53 --> Total execution time: 0.0513
DEBUG - 2012-07-14 09:45:53 --> Config Class Initialized
DEBUG - 2012-07-14 09:45:53 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:45:53 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:45:53 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:45:53 --> URI Class Initialized
DEBUG - 2012-07-14 09:45:53 --> Router Class Initialized
ERROR - 2012-07-14 09:45:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-14 09:54:16 --> Config Class Initialized
DEBUG - 2012-07-14 09:54:16 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:54:16 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:54:16 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:54:16 --> URI Class Initialized
DEBUG - 2012-07-14 09:54:16 --> Router Class Initialized
DEBUG - 2012-07-14 09:54:16 --> Output Class Initialized
DEBUG - 2012-07-14 09:54:16 --> Security Class Initialized
DEBUG - 2012-07-14 09:54:16 --> Input Class Initialized
DEBUG - 2012-07-14 09:54:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 09:54:16 --> Language Class Initialized
DEBUG - 2012-07-14 09:54:16 --> Loader Class Initialized
DEBUG - 2012-07-14 09:54:16 --> Helper loaded: date_helper
DEBUG - 2012-07-14 09:54:16 --> Controller Class Initialized
DEBUG - 2012-07-14 09:54:16 --> Database Driver Class Initialized
DEBUG - 2012-07-14 09:54:16 --> Model Class Initialized
DEBUG - 2012-07-14 09:54:16 --> Model Class Initialized
DEBUG - 2012-07-14 09:54:16 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-14 09:54:16 --> Pagination Class Initialized
DEBUG - 2012-07-14 09:54:16 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-14 09:54:16 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-14 09:54:16 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-14 09:54:16 --> Helper loaded: text_helper
DEBUG - 2012-07-14 09:54:16 --> Final output sent to browser
DEBUG - 2012-07-14 09:54:16 --> Total execution time: 0.0580
DEBUG - 2012-07-14 09:54:16 --> Config Class Initialized
DEBUG - 2012-07-14 09:54:16 --> Hooks Class Initialized
DEBUG - 2012-07-14 09:54:16 --> Utf8 Class Initialized
DEBUG - 2012-07-14 09:54:16 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 09:54:16 --> URI Class Initialized
DEBUG - 2012-07-14 09:54:16 --> Router Class Initialized
ERROR - 2012-07-14 09:54:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-14 10:11:39 --> Config Class Initialized
DEBUG - 2012-07-14 10:11:39 --> Hooks Class Initialized
DEBUG - 2012-07-14 10:11:39 --> Utf8 Class Initialized
DEBUG - 2012-07-14 10:11:39 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 10:11:39 --> URI Class Initialized
DEBUG - 2012-07-14 10:11:39 --> Router Class Initialized
DEBUG - 2012-07-14 10:11:39 --> No URI present. Default controller set.
DEBUG - 2012-07-14 10:11:39 --> Output Class Initialized
DEBUG - 2012-07-14 10:11:39 --> Security Class Initialized
DEBUG - 2012-07-14 10:11:39 --> Input Class Initialized
DEBUG - 2012-07-14 10:11:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-14 10:11:39 --> Language Class Initialized
DEBUG - 2012-07-14 10:11:39 --> Loader Class Initialized
DEBUG - 2012-07-14 10:11:39 --> Helper loaded: date_helper
DEBUG - 2012-07-14 10:11:39 --> Controller Class Initialized
DEBUG - 2012-07-14 10:11:39 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-07-14 10:11:39 --> Final output sent to browser
DEBUG - 2012-07-14 10:11:39 --> Total execution time: 0.1644
DEBUG - 2012-07-14 10:11:39 --> Config Class Initialized
DEBUG - 2012-07-14 10:11:39 --> Hooks Class Initialized
DEBUG - 2012-07-14 10:11:39 --> Utf8 Class Initialized
DEBUG - 2012-07-14 10:11:39 --> UTF-8 Support Enabled
DEBUG - 2012-07-14 10:11:39 --> URI Class Initialized
DEBUG - 2012-07-14 10:11:39 --> Router Class Initialized
ERROR - 2012-07-14 10:11:39 --> 404 Page Not Found --> favicon.ico
