<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-07-16 13:35:17 --> Config Class Initialized
DEBUG - 2012-07-16 13:35:17 --> Hooks Class Initialized
DEBUG - 2012-07-16 13:35:17 --> Utf8 Class Initialized
DEBUG - 2012-07-16 13:35:17 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 13:35:17 --> URI Class Initialized
DEBUG - 2012-07-16 13:35:17 --> Router Class Initialized
DEBUG - 2012-07-16 13:35:17 --> Output Class Initialized
DEBUG - 2012-07-16 13:35:17 --> Security Class Initialized
DEBUG - 2012-07-16 13:35:17 --> Input Class Initialized
DEBUG - 2012-07-16 13:35:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 13:35:17 --> Language Class Initialized
DEBUG - 2012-07-16 13:35:17 --> Loader Class Initialized
DEBUG - 2012-07-16 13:35:17 --> Helper loaded: date_helper
DEBUG - 2012-07-16 13:35:17 --> Controller Class Initialized
DEBUG - 2012-07-16 13:35:17 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 13:35:17 --> Helper loaded: form_helper
DEBUG - 2012-07-16 13:35:17 --> Form Validation Class Initialized
DEBUG - 2012-07-16 13:35:18 --> Config Class Initialized
DEBUG - 2012-07-16 13:35:18 --> Hooks Class Initialized
DEBUG - 2012-07-16 13:35:18 --> Utf8 Class Initialized
DEBUG - 2012-07-16 13:35:18 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 13:35:18 --> URI Class Initialized
DEBUG - 2012-07-16 13:35:18 --> Router Class Initialized
ERROR - 2012-07-16 13:35:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 13:36:01 --> Config Class Initialized
DEBUG - 2012-07-16 13:36:01 --> Hooks Class Initialized
DEBUG - 2012-07-16 13:36:01 --> Utf8 Class Initialized
DEBUG - 2012-07-16 13:36:01 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 13:36:01 --> URI Class Initialized
DEBUG - 2012-07-16 13:36:01 --> Router Class Initialized
DEBUG - 2012-07-16 13:36:01 --> Output Class Initialized
DEBUG - 2012-07-16 13:36:01 --> Security Class Initialized
DEBUG - 2012-07-16 13:36:01 --> Input Class Initialized
DEBUG - 2012-07-16 13:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 13:36:01 --> Language Class Initialized
DEBUG - 2012-07-16 13:36:01 --> Loader Class Initialized
DEBUG - 2012-07-16 13:36:01 --> Helper loaded: date_helper
DEBUG - 2012-07-16 13:36:01 --> Controller Class Initialized
DEBUG - 2012-07-16 13:36:01 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 13:36:01 --> Helper loaded: form_helper
DEBUG - 2012-07-16 13:36:01 --> Form Validation Class Initialized
DEBUG - 2012-07-16 13:36:01 --> File loaded: application/views/test/forms_v.php
DEBUG - 2012-07-16 13:36:01 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 13:36:01 --> Final output sent to browser
DEBUG - 2012-07-16 13:36:01 --> Total execution time: 0.0532
DEBUG - 2012-07-16 13:36:02 --> Config Class Initialized
DEBUG - 2012-07-16 13:36:02 --> Hooks Class Initialized
DEBUG - 2012-07-16 13:36:02 --> Utf8 Class Initialized
DEBUG - 2012-07-16 13:36:02 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 13:36:02 --> URI Class Initialized
DEBUG - 2012-07-16 13:36:02 --> Router Class Initialized
ERROR - 2012-07-16 13:36:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 13:38:12 --> Config Class Initialized
DEBUG - 2012-07-16 13:38:12 --> Hooks Class Initialized
DEBUG - 2012-07-16 13:38:12 --> Utf8 Class Initialized
DEBUG - 2012-07-16 13:38:12 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 13:38:12 --> URI Class Initialized
DEBUG - 2012-07-16 13:38:12 --> Router Class Initialized
DEBUG - 2012-07-16 13:38:12 --> Output Class Initialized
DEBUG - 2012-07-16 13:38:12 --> Security Class Initialized
DEBUG - 2012-07-16 13:38:12 --> Input Class Initialized
DEBUG - 2012-07-16 13:38:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 13:38:12 --> Language Class Initialized
DEBUG - 2012-07-16 13:38:12 --> Loader Class Initialized
DEBUG - 2012-07-16 13:38:12 --> Helper loaded: date_helper
DEBUG - 2012-07-16 13:38:12 --> Controller Class Initialized
DEBUG - 2012-07-16 13:38:12 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 13:38:12 --> Helper loaded: form_helper
DEBUG - 2012-07-16 13:38:12 --> Form Validation Class Initialized
DEBUG - 2012-07-16 13:38:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-16 13:38:12 --> File loaded: application/views/test/forms_v.php
DEBUG - 2012-07-16 13:38:12 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 13:38:12 --> Final output sent to browser
DEBUG - 2012-07-16 13:38:12 --> Total execution time: 0.0377
DEBUG - 2012-07-16 13:38:12 --> Config Class Initialized
DEBUG - 2012-07-16 13:38:12 --> Hooks Class Initialized
DEBUG - 2012-07-16 13:38:12 --> Utf8 Class Initialized
DEBUG - 2012-07-16 13:38:12 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 13:38:12 --> URI Class Initialized
DEBUG - 2012-07-16 13:38:12 --> Router Class Initialized
ERROR - 2012-07-16 13:38:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 13:38:38 --> Config Class Initialized
DEBUG - 2012-07-16 13:38:38 --> Hooks Class Initialized
DEBUG - 2012-07-16 13:38:38 --> Utf8 Class Initialized
DEBUG - 2012-07-16 13:38:38 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 13:38:38 --> URI Class Initialized
DEBUG - 2012-07-16 13:38:38 --> Router Class Initialized
DEBUG - 2012-07-16 13:38:38 --> Output Class Initialized
DEBUG - 2012-07-16 13:38:38 --> Security Class Initialized
DEBUG - 2012-07-16 13:38:38 --> Input Class Initialized
DEBUG - 2012-07-16 13:38:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 13:38:38 --> Language Class Initialized
DEBUG - 2012-07-16 13:38:38 --> Loader Class Initialized
DEBUG - 2012-07-16 13:38:38 --> Helper loaded: date_helper
DEBUG - 2012-07-16 13:38:38 --> Controller Class Initialized
DEBUG - 2012-07-16 13:38:38 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 13:38:38 --> Helper loaded: form_helper
DEBUG - 2012-07-16 13:38:38 --> Form Validation Class Initialized
DEBUG - 2012-07-16 13:38:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-16 13:38:38 --> File loaded: application/views/test/form_success_v.php
DEBUG - 2012-07-16 13:38:38 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 13:38:38 --> Final output sent to browser
DEBUG - 2012-07-16 13:38:38 --> Total execution time: 0.0301
DEBUG - 2012-07-16 13:38:38 --> Config Class Initialized
DEBUG - 2012-07-16 13:38:38 --> Hooks Class Initialized
DEBUG - 2012-07-16 13:38:38 --> Utf8 Class Initialized
DEBUG - 2012-07-16 13:38:38 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 13:38:38 --> URI Class Initialized
DEBUG - 2012-07-16 13:38:38 --> Router Class Initialized
ERROR - 2012-07-16 13:38:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 14:08:17 --> Config Class Initialized
DEBUG - 2012-07-16 14:08:17 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:08:17 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:08:17 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:08:17 --> URI Class Initialized
DEBUG - 2012-07-16 14:08:17 --> Router Class Initialized
ERROR - 2012-07-16 14:08:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 14:08:19 --> Config Class Initialized
DEBUG - 2012-07-16 14:08:19 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:08:19 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:08:19 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:08:19 --> URI Class Initialized
DEBUG - 2012-07-16 14:08:19 --> Router Class Initialized
DEBUG - 2012-07-16 14:08:19 --> Output Class Initialized
DEBUG - 2012-07-16 14:08:19 --> Security Class Initialized
DEBUG - 2012-07-16 14:08:19 --> Input Class Initialized
DEBUG - 2012-07-16 14:08:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 14:08:19 --> Language Class Initialized
DEBUG - 2012-07-16 14:08:19 --> Loader Class Initialized
DEBUG - 2012-07-16 14:08:19 --> Helper loaded: date_helper
DEBUG - 2012-07-16 14:08:19 --> Controller Class Initialized
DEBUG - 2012-07-16 14:08:19 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 14:08:19 --> Helper loaded: form_helper
DEBUG - 2012-07-16 14:08:19 --> Form Validation Class Initialized
DEBUG - 2012-07-16 14:08:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-16 14:08:19 --> File loaded: application/views/test/form_success_v.php
DEBUG - 2012-07-16 14:08:19 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 14:08:19 --> Final output sent to browser
DEBUG - 2012-07-16 14:08:19 --> Total execution time: 0.0471
DEBUG - 2012-07-16 14:08:19 --> Config Class Initialized
DEBUG - 2012-07-16 14:08:19 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:08:19 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:08:19 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:08:19 --> URI Class Initialized
DEBUG - 2012-07-16 14:08:19 --> Router Class Initialized
ERROR - 2012-07-16 14:08:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 14:08:21 --> Config Class Initialized
DEBUG - 2012-07-16 14:08:21 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:08:21 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:08:21 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:08:21 --> URI Class Initialized
DEBUG - 2012-07-16 14:08:21 --> Router Class Initialized
ERROR - 2012-07-16 14:08:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 14:08:24 --> Config Class Initialized
DEBUG - 2012-07-16 14:08:24 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:08:24 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:08:24 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:08:24 --> URI Class Initialized
DEBUG - 2012-07-16 14:08:24 --> Router Class Initialized
DEBUG - 2012-07-16 14:08:24 --> Output Class Initialized
DEBUG - 2012-07-16 14:08:24 --> Security Class Initialized
DEBUG - 2012-07-16 14:08:24 --> Input Class Initialized
DEBUG - 2012-07-16 14:08:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 14:08:24 --> Language Class Initialized
DEBUG - 2012-07-16 14:08:24 --> Loader Class Initialized
DEBUG - 2012-07-16 14:08:24 --> Helper loaded: date_helper
DEBUG - 2012-07-16 14:08:24 --> Controller Class Initialized
DEBUG - 2012-07-16 14:08:24 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 14:08:24 --> Helper loaded: form_helper
DEBUG - 2012-07-16 14:08:24 --> Form Validation Class Initialized
DEBUG - 2012-07-16 14:08:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-16 14:08:24 --> File loaded: application/views/test/forms_v.php
DEBUG - 2012-07-16 14:08:24 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 14:08:24 --> Final output sent to browser
DEBUG - 2012-07-16 14:08:24 --> Total execution time: 0.0336
DEBUG - 2012-07-16 14:08:25 --> Config Class Initialized
DEBUG - 2012-07-16 14:08:25 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:08:25 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:08:25 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:08:25 --> URI Class Initialized
DEBUG - 2012-07-16 14:08:25 --> Router Class Initialized
ERROR - 2012-07-16 14:08:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 14:08:33 --> Config Class Initialized
DEBUG - 2012-07-16 14:08:33 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:08:33 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:08:33 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:08:33 --> URI Class Initialized
DEBUG - 2012-07-16 14:08:33 --> Router Class Initialized
DEBUG - 2012-07-16 14:08:33 --> Output Class Initialized
DEBUG - 2012-07-16 14:08:33 --> Security Class Initialized
DEBUG - 2012-07-16 14:08:33 --> Input Class Initialized
DEBUG - 2012-07-16 14:08:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 14:08:33 --> Language Class Initialized
DEBUG - 2012-07-16 14:08:33 --> Loader Class Initialized
DEBUG - 2012-07-16 14:08:33 --> Helper loaded: date_helper
DEBUG - 2012-07-16 14:08:33 --> Controller Class Initialized
DEBUG - 2012-07-16 14:08:33 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 14:08:33 --> Helper loaded: form_helper
DEBUG - 2012-07-16 14:08:33 --> Form Validation Class Initialized
DEBUG - 2012-07-16 14:08:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-16 14:08:33 --> File loaded: application/views/test/forms_v.php
DEBUG - 2012-07-16 14:08:33 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 14:08:33 --> Final output sent to browser
DEBUG - 2012-07-16 14:08:33 --> Total execution time: 0.0390
DEBUG - 2012-07-16 14:08:33 --> Config Class Initialized
DEBUG - 2012-07-16 14:08:33 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:08:33 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:08:33 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:08:33 --> URI Class Initialized
DEBUG - 2012-07-16 14:08:33 --> Router Class Initialized
ERROR - 2012-07-16 14:08:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 14:09:10 --> Config Class Initialized
DEBUG - 2012-07-16 14:09:10 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:09:10 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:09:10 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:09:10 --> URI Class Initialized
DEBUG - 2012-07-16 14:09:10 --> Router Class Initialized
DEBUG - 2012-07-16 14:09:10 --> Output Class Initialized
DEBUG - 2012-07-16 14:09:10 --> Security Class Initialized
DEBUG - 2012-07-16 14:09:10 --> Input Class Initialized
DEBUG - 2012-07-16 14:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 14:09:10 --> Language Class Initialized
DEBUG - 2012-07-16 14:09:10 --> Loader Class Initialized
DEBUG - 2012-07-16 14:09:10 --> Helper loaded: date_helper
DEBUG - 2012-07-16 14:09:10 --> Controller Class Initialized
DEBUG - 2012-07-16 14:09:10 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 14:09:10 --> Helper loaded: form_helper
DEBUG - 2012-07-16 14:09:10 --> Form Validation Class Initialized
DEBUG - 2012-07-16 14:09:10 --> File loaded: application/views/test/forms_v.php
DEBUG - 2012-07-16 14:09:10 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 14:09:10 --> Final output sent to browser
DEBUG - 2012-07-16 14:09:10 --> Total execution time: 0.0366
DEBUG - 2012-07-16 14:09:10 --> Config Class Initialized
DEBUG - 2012-07-16 14:09:10 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:09:10 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:09:10 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:09:10 --> URI Class Initialized
DEBUG - 2012-07-16 14:09:10 --> Router Class Initialized
ERROR - 2012-07-16 14:09:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 14:09:15 --> Config Class Initialized
DEBUG - 2012-07-16 14:09:15 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:09:15 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:09:15 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:09:15 --> URI Class Initialized
DEBUG - 2012-07-16 14:09:15 --> Router Class Initialized
DEBUG - 2012-07-16 14:09:15 --> Output Class Initialized
DEBUG - 2012-07-16 14:09:15 --> Security Class Initialized
DEBUG - 2012-07-16 14:09:15 --> Input Class Initialized
DEBUG - 2012-07-16 14:09:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 14:09:15 --> Language Class Initialized
DEBUG - 2012-07-16 14:09:15 --> Loader Class Initialized
DEBUG - 2012-07-16 14:09:15 --> Helper loaded: date_helper
DEBUG - 2012-07-16 14:09:15 --> Controller Class Initialized
DEBUG - 2012-07-16 14:09:15 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 14:09:15 --> Helper loaded: form_helper
DEBUG - 2012-07-16 14:09:15 --> Form Validation Class Initialized
DEBUG - 2012-07-16 14:09:15 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-16 14:09:15 --> File loaded: application/views/test/forms_v.php
DEBUG - 2012-07-16 14:09:15 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 14:09:15 --> Final output sent to browser
DEBUG - 2012-07-16 14:09:15 --> Total execution time: 0.0316
DEBUG - 2012-07-16 14:09:16 --> Config Class Initialized
DEBUG - 2012-07-16 14:09:16 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:09:16 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:09:16 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:09:16 --> URI Class Initialized
DEBUG - 2012-07-16 14:09:16 --> Router Class Initialized
ERROR - 2012-07-16 14:09:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 14:09:32 --> Config Class Initialized
DEBUG - 2012-07-16 14:09:32 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:09:32 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:09:32 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:09:32 --> URI Class Initialized
DEBUG - 2012-07-16 14:09:32 --> Router Class Initialized
DEBUG - 2012-07-16 14:09:32 --> Output Class Initialized
DEBUG - 2012-07-16 14:09:32 --> Security Class Initialized
DEBUG - 2012-07-16 14:09:32 --> Input Class Initialized
DEBUG - 2012-07-16 14:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 14:09:32 --> Language Class Initialized
DEBUG - 2012-07-16 14:09:32 --> Loader Class Initialized
DEBUG - 2012-07-16 14:09:32 --> Helper loaded: date_helper
DEBUG - 2012-07-16 14:09:32 --> Controller Class Initialized
DEBUG - 2012-07-16 14:09:32 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 14:09:32 --> Helper loaded: form_helper
DEBUG - 2012-07-16 14:09:32 --> Form Validation Class Initialized
DEBUG - 2012-07-16 14:09:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-16 14:09:32 --> File loaded: application/views/test/forms_v.php
DEBUG - 2012-07-16 14:09:32 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 14:09:32 --> Final output sent to browser
DEBUG - 2012-07-16 14:09:32 --> Total execution time: 0.0364
DEBUG - 2012-07-16 14:09:32 --> Config Class Initialized
DEBUG - 2012-07-16 14:09:32 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:09:32 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:09:32 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:09:32 --> URI Class Initialized
DEBUG - 2012-07-16 14:09:32 --> Router Class Initialized
ERROR - 2012-07-16 14:09:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 14:10:04 --> Config Class Initialized
DEBUG - 2012-07-16 14:10:04 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:10:04 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:10:04 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:10:04 --> URI Class Initialized
DEBUG - 2012-07-16 14:10:04 --> Router Class Initialized
DEBUG - 2012-07-16 14:10:04 --> Output Class Initialized
DEBUG - 2012-07-16 14:10:04 --> Security Class Initialized
DEBUG - 2012-07-16 14:10:04 --> Input Class Initialized
DEBUG - 2012-07-16 14:10:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 14:10:04 --> Language Class Initialized
DEBUG - 2012-07-16 14:10:04 --> Loader Class Initialized
DEBUG - 2012-07-16 14:10:04 --> Helper loaded: date_helper
DEBUG - 2012-07-16 14:10:04 --> Controller Class Initialized
DEBUG - 2012-07-16 14:10:04 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 14:10:04 --> Helper loaded: form_helper
DEBUG - 2012-07-16 14:10:04 --> Form Validation Class Initialized
DEBUG - 2012-07-16 14:10:04 --> File loaded: application/views/test/forms_v.php
DEBUG - 2012-07-16 14:10:04 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 14:10:04 --> Final output sent to browser
DEBUG - 2012-07-16 14:10:04 --> Total execution time: 0.0287
DEBUG - 2012-07-16 14:10:04 --> Config Class Initialized
DEBUG - 2012-07-16 14:10:04 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:10:04 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:10:04 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:10:04 --> URI Class Initialized
DEBUG - 2012-07-16 14:10:04 --> Router Class Initialized
ERROR - 2012-07-16 14:10:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 14:10:08 --> Config Class Initialized
DEBUG - 2012-07-16 14:10:08 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:10:08 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:10:08 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:10:08 --> URI Class Initialized
DEBUG - 2012-07-16 14:10:08 --> Router Class Initialized
DEBUG - 2012-07-16 14:10:08 --> Output Class Initialized
DEBUG - 2012-07-16 14:10:08 --> Security Class Initialized
DEBUG - 2012-07-16 14:10:08 --> Input Class Initialized
DEBUG - 2012-07-16 14:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 14:10:08 --> Language Class Initialized
DEBUG - 2012-07-16 14:10:08 --> Loader Class Initialized
DEBUG - 2012-07-16 14:10:08 --> Helper loaded: date_helper
DEBUG - 2012-07-16 14:10:08 --> Controller Class Initialized
DEBUG - 2012-07-16 14:10:08 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 14:10:08 --> Helper loaded: form_helper
DEBUG - 2012-07-16 14:10:08 --> Form Validation Class Initialized
DEBUG - 2012-07-16 14:10:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-16 14:10:08 --> File loaded: application/views/test/forms_v.php
DEBUG - 2012-07-16 14:10:08 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 14:10:08 --> Final output sent to browser
DEBUG - 2012-07-16 14:10:08 --> Total execution time: 0.0375
DEBUG - 2012-07-16 14:10:08 --> Config Class Initialized
DEBUG - 2012-07-16 14:10:08 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:10:08 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:10:08 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:10:08 --> URI Class Initialized
DEBUG - 2012-07-16 14:10:08 --> Router Class Initialized
ERROR - 2012-07-16 14:10:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 14:12:09 --> Config Class Initialized
DEBUG - 2012-07-16 14:12:09 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:12:09 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:12:09 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:12:09 --> URI Class Initialized
DEBUG - 2012-07-16 14:12:09 --> Router Class Initialized
DEBUG - 2012-07-16 14:12:09 --> Output Class Initialized
DEBUG - 2012-07-16 14:12:09 --> Security Class Initialized
DEBUG - 2012-07-16 14:12:09 --> Input Class Initialized
DEBUG - 2012-07-16 14:12:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 14:12:09 --> Language Class Initialized
DEBUG - 2012-07-16 14:12:09 --> Loader Class Initialized
DEBUG - 2012-07-16 14:12:09 --> Helper loaded: date_helper
DEBUG - 2012-07-16 14:12:09 --> Controller Class Initialized
DEBUG - 2012-07-16 14:12:09 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 14:12:09 --> Helper loaded: form_helper
DEBUG - 2012-07-16 14:12:09 --> Form Validation Class Initialized
DEBUG - 2012-07-16 14:12:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-16 14:12:09 --> File loaded: application/views/test/forms_v.php
DEBUG - 2012-07-16 14:12:09 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 14:12:09 --> Final output sent to browser
DEBUG - 2012-07-16 14:12:09 --> Total execution time: 0.0328
DEBUG - 2012-07-16 14:12:10 --> Config Class Initialized
DEBUG - 2012-07-16 14:12:10 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:12:10 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:12:10 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:12:10 --> URI Class Initialized
DEBUG - 2012-07-16 14:12:10 --> Router Class Initialized
ERROR - 2012-07-16 14:12:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 14:12:31 --> Config Class Initialized
DEBUG - 2012-07-16 14:12:31 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:12:31 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:12:31 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:12:31 --> URI Class Initialized
DEBUG - 2012-07-16 14:12:31 --> Router Class Initialized
DEBUG - 2012-07-16 14:12:31 --> Output Class Initialized
DEBUG - 2012-07-16 14:12:31 --> Security Class Initialized
DEBUG - 2012-07-16 14:12:31 --> Input Class Initialized
DEBUG - 2012-07-16 14:12:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 14:12:31 --> Language Class Initialized
DEBUG - 2012-07-16 14:12:31 --> Loader Class Initialized
DEBUG - 2012-07-16 14:12:31 --> Helper loaded: date_helper
DEBUG - 2012-07-16 14:12:31 --> Controller Class Initialized
DEBUG - 2012-07-16 14:12:31 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 14:12:31 --> Helper loaded: form_helper
DEBUG - 2012-07-16 14:12:31 --> Form Validation Class Initialized
DEBUG - 2012-07-16 14:12:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-16 14:12:31 --> File loaded: application/views/test/forms_v.php
DEBUG - 2012-07-16 14:12:31 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 14:12:31 --> Final output sent to browser
DEBUG - 2012-07-16 14:12:31 --> Total execution time: 0.0364
DEBUG - 2012-07-16 14:12:31 --> Config Class Initialized
DEBUG - 2012-07-16 14:12:31 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:12:31 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:12:31 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:12:31 --> URI Class Initialized
DEBUG - 2012-07-16 14:12:31 --> Router Class Initialized
ERROR - 2012-07-16 14:12:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 14:12:56 --> Config Class Initialized
DEBUG - 2012-07-16 14:12:56 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:12:56 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:12:56 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:12:56 --> URI Class Initialized
DEBUG - 2012-07-16 14:12:56 --> Router Class Initialized
DEBUG - 2012-07-16 14:12:56 --> Output Class Initialized
DEBUG - 2012-07-16 14:12:56 --> Security Class Initialized
DEBUG - 2012-07-16 14:12:56 --> Input Class Initialized
DEBUG - 2012-07-16 14:12:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 14:12:56 --> Language Class Initialized
DEBUG - 2012-07-16 14:12:56 --> Loader Class Initialized
DEBUG - 2012-07-16 14:12:56 --> Helper loaded: date_helper
DEBUG - 2012-07-16 14:12:56 --> Controller Class Initialized
DEBUG - 2012-07-16 14:12:56 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 14:12:56 --> Helper loaded: form_helper
DEBUG - 2012-07-16 14:12:56 --> Form Validation Class Initialized
DEBUG - 2012-07-16 14:12:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-16 14:12:56 --> File loaded: application/views/test/forms_v.php
DEBUG - 2012-07-16 14:12:56 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 14:12:56 --> Final output sent to browser
DEBUG - 2012-07-16 14:12:56 --> Total execution time: 0.0310
DEBUG - 2012-07-16 14:12:56 --> Config Class Initialized
DEBUG - 2012-07-16 14:12:56 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:12:56 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:12:56 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:12:56 --> URI Class Initialized
DEBUG - 2012-07-16 14:12:56 --> Router Class Initialized
ERROR - 2012-07-16 14:12:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 14:38:31 --> Config Class Initialized
DEBUG - 2012-07-16 14:38:31 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:38:31 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:38:31 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:38:31 --> URI Class Initialized
DEBUG - 2012-07-16 14:38:31 --> Router Class Initialized
DEBUG - 2012-07-16 14:38:31 --> Output Class Initialized
DEBUG - 2012-07-16 14:38:31 --> Security Class Initialized
DEBUG - 2012-07-16 14:38:31 --> Input Class Initialized
DEBUG - 2012-07-16 14:38:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 14:38:31 --> Language Class Initialized
DEBUG - 2012-07-16 14:38:31 --> Loader Class Initialized
DEBUG - 2012-07-16 14:38:31 --> Helper loaded: date_helper
DEBUG - 2012-07-16 14:38:31 --> Controller Class Initialized
DEBUG - 2012-07-16 14:38:31 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 14:38:31 --> Helper loaded: form_helper
DEBUG - 2012-07-16 14:38:31 --> Form Validation Class Initialized
DEBUG - 2012-07-16 14:38:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-16 14:38:31 --> File loaded: application/views/test/forms_v.php
DEBUG - 2012-07-16 14:38:31 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 14:38:31 --> Final output sent to browser
DEBUG - 2012-07-16 14:38:31 --> Total execution time: 0.0364
DEBUG - 2012-07-16 14:38:31 --> Config Class Initialized
DEBUG - 2012-07-16 14:38:31 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:38:31 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:38:31 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:38:31 --> URI Class Initialized
DEBUG - 2012-07-16 14:38:31 --> Router Class Initialized
ERROR - 2012-07-16 14:38:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 14:38:59 --> Config Class Initialized
DEBUG - 2012-07-16 14:38:59 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:38:59 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:38:59 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:38:59 --> URI Class Initialized
DEBUG - 2012-07-16 14:38:59 --> Router Class Initialized
DEBUG - 2012-07-16 14:38:59 --> Output Class Initialized
DEBUG - 2012-07-16 14:38:59 --> Security Class Initialized
DEBUG - 2012-07-16 14:38:59 --> Input Class Initialized
DEBUG - 2012-07-16 14:38:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 14:38:59 --> Language Class Initialized
DEBUG - 2012-07-16 14:38:59 --> Loader Class Initialized
DEBUG - 2012-07-16 14:38:59 --> Helper loaded: date_helper
DEBUG - 2012-07-16 14:38:59 --> Controller Class Initialized
DEBUG - 2012-07-16 14:38:59 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 14:38:59 --> Helper loaded: form_helper
DEBUG - 2012-07-16 14:38:59 --> Form Validation Class Initialized
DEBUG - 2012-07-16 14:38:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-16 14:38:59 --> File loaded: application/views/test/forms_v.php
DEBUG - 2012-07-16 14:38:59 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 14:38:59 --> Final output sent to browser
DEBUG - 2012-07-16 14:38:59 --> Total execution time: 0.0334
DEBUG - 2012-07-16 14:38:59 --> Config Class Initialized
DEBUG - 2012-07-16 14:38:59 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:38:59 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:38:59 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:38:59 --> URI Class Initialized
DEBUG - 2012-07-16 14:38:59 --> Router Class Initialized
ERROR - 2012-07-16 14:38:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 14:39:21 --> Config Class Initialized
DEBUG - 2012-07-16 14:39:21 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:39:21 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:39:21 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:39:21 --> URI Class Initialized
DEBUG - 2012-07-16 14:39:21 --> Router Class Initialized
DEBUG - 2012-07-16 14:39:21 --> Output Class Initialized
DEBUG - 2012-07-16 14:39:21 --> Security Class Initialized
DEBUG - 2012-07-16 14:39:21 --> Input Class Initialized
DEBUG - 2012-07-16 14:39:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 14:39:21 --> Language Class Initialized
DEBUG - 2012-07-16 14:39:21 --> Loader Class Initialized
DEBUG - 2012-07-16 14:39:21 --> Helper loaded: date_helper
DEBUG - 2012-07-16 14:39:21 --> Controller Class Initialized
DEBUG - 2012-07-16 14:39:21 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 14:39:21 --> Helper loaded: form_helper
DEBUG - 2012-07-16 14:39:21 --> Form Validation Class Initialized
DEBUG - 2012-07-16 14:39:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-16 14:39:21 --> File loaded: application/views/test/forms_v.php
DEBUG - 2012-07-16 14:39:21 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 14:39:21 --> Final output sent to browser
DEBUG - 2012-07-16 14:39:21 --> Total execution time: 0.0335
DEBUG - 2012-07-16 14:39:21 --> Config Class Initialized
DEBUG - 2012-07-16 14:39:21 --> Hooks Class Initialized
DEBUG - 2012-07-16 14:39:21 --> Utf8 Class Initialized
DEBUG - 2012-07-16 14:39:21 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 14:39:21 --> URI Class Initialized
DEBUG - 2012-07-16 14:39:21 --> Router Class Initialized
ERROR - 2012-07-16 14:39:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 15:06:49 --> Config Class Initialized
DEBUG - 2012-07-16 15:06:49 --> Hooks Class Initialized
DEBUG - 2012-07-16 15:06:49 --> Utf8 Class Initialized
DEBUG - 2012-07-16 15:06:49 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 15:06:49 --> URI Class Initialized
DEBUG - 2012-07-16 15:06:49 --> Router Class Initialized
DEBUG - 2012-07-16 15:06:49 --> Output Class Initialized
DEBUG - 2012-07-16 15:06:49 --> Security Class Initialized
DEBUG - 2012-07-16 15:06:49 --> Input Class Initialized
DEBUG - 2012-07-16 15:06:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 15:06:49 --> Language Class Initialized
DEBUG - 2012-07-16 15:06:49 --> Loader Class Initialized
DEBUG - 2012-07-16 15:06:49 --> Helper loaded: date_helper
DEBUG - 2012-07-16 15:06:49 --> Controller Class Initialized
DEBUG - 2012-07-16 15:06:49 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 15:06:49 --> Helper loaded: form_helper
DEBUG - 2012-07-16 15:06:49 --> Form Validation Class Initialized
DEBUG - 2012-07-16 15:06:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-16 15:06:49 --> File loaded: application/views/test/forms_v.php
DEBUG - 2012-07-16 15:06:49 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 15:06:49 --> Final output sent to browser
DEBUG - 2012-07-16 15:06:49 --> Total execution time: 0.0501
DEBUG - 2012-07-16 15:06:50 --> Config Class Initialized
DEBUG - 2012-07-16 15:06:50 --> Hooks Class Initialized
DEBUG - 2012-07-16 15:06:50 --> Utf8 Class Initialized
DEBUG - 2012-07-16 15:06:50 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 15:06:50 --> URI Class Initialized
DEBUG - 2012-07-16 15:06:50 --> Router Class Initialized
ERROR - 2012-07-16 15:06:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 15:07:11 --> Config Class Initialized
DEBUG - 2012-07-16 15:07:11 --> Hooks Class Initialized
DEBUG - 2012-07-16 15:07:11 --> Utf8 Class Initialized
DEBUG - 2012-07-16 15:07:11 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 15:07:11 --> URI Class Initialized
DEBUG - 2012-07-16 15:07:11 --> Router Class Initialized
DEBUG - 2012-07-16 15:07:11 --> Output Class Initialized
DEBUG - 2012-07-16 15:07:11 --> Security Class Initialized
DEBUG - 2012-07-16 15:07:11 --> Input Class Initialized
DEBUG - 2012-07-16 15:07:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 15:07:11 --> Language Class Initialized
DEBUG - 2012-07-16 15:07:11 --> Loader Class Initialized
DEBUG - 2012-07-16 15:07:11 --> Helper loaded: date_helper
DEBUG - 2012-07-16 15:07:11 --> Controller Class Initialized
DEBUG - 2012-07-16 15:07:11 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 15:07:11 --> Helper loaded: form_helper
DEBUG - 2012-07-16 15:07:11 --> Form Validation Class Initialized
DEBUG - 2012-07-16 15:07:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-16 15:07:11 --> File loaded: application/views/test/forms_v.php
DEBUG - 2012-07-16 15:07:11 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 15:07:11 --> Final output sent to browser
DEBUG - 2012-07-16 15:07:11 --> Total execution time: 0.0350
DEBUG - 2012-07-16 15:07:11 --> Config Class Initialized
DEBUG - 2012-07-16 15:07:11 --> Hooks Class Initialized
DEBUG - 2012-07-16 15:07:11 --> Utf8 Class Initialized
DEBUG - 2012-07-16 15:07:11 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 15:07:11 --> URI Class Initialized
DEBUG - 2012-07-16 15:07:11 --> Router Class Initialized
ERROR - 2012-07-16 15:07:11 --> 404 Page Not Found --> favicon.ico
