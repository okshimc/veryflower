<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-08-22 16:42:28 --> Config Class Initialized
DEBUG - 2012-08-22 16:42:28 --> Hooks Class Initialized
DEBUG - 2012-08-22 16:42:28 --> Utf8 Class Initialized
DEBUG - 2012-08-22 16:42:29 --> UTF-8 Support Enabled
DEBUG - 2012-08-22 16:42:29 --> URI Class Initialized
DEBUG - 2012-08-22 16:42:29 --> Router Class Initialized
DEBUG - 2012-08-22 16:42:29 --> No URI present. Default controller set.
DEBUG - 2012-08-22 16:42:29 --> Output Class Initialized
DEBUG - 2012-08-22 16:42:29 --> Security Class Initialized
DEBUG - 2012-08-22 16:42:29 --> Input Class Initialized
DEBUG - 2012-08-22 16:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-22 16:42:29 --> Language Class Initialized
DEBUG - 2012-08-22 16:42:29 --> Loader Class Initialized
DEBUG - 2012-08-22 16:42:29 --> Helper loaded: date_helper
DEBUG - 2012-08-22 16:42:29 --> Controller Class Initialized
DEBUG - 2012-08-22 16:42:29 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-08-22 16:42:29 --> Final output sent to browser
DEBUG - 2012-08-22 16:42:29 --> Total execution time: 0.2230
