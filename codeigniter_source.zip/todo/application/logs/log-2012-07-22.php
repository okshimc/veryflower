<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-07-22 09:15:53 --> Config Class Initialized
DEBUG - 2012-07-22 09:15:53 --> Hooks Class Initialized
DEBUG - 2012-07-22 09:15:53 --> Utf8 Class Initialized
DEBUG - 2012-07-22 09:15:53 --> UTF-8 Support Enabled
DEBUG - 2012-07-22 09:15:53 --> URI Class Initialized
DEBUG - 2012-07-22 09:15:53 --> Router Class Initialized
DEBUG - 2012-07-22 09:15:53 --> No URI present. Default controller set.
DEBUG - 2012-07-22 09:15:53 --> Output Class Initialized
DEBUG - 2012-07-22 09:15:53 --> Security Class Initialized
DEBUG - 2012-07-22 09:15:53 --> Input Class Initialized
DEBUG - 2012-07-22 09:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-22 09:15:53 --> Language Class Initialized
DEBUG - 2012-07-22 09:15:53 --> Loader Class Initialized
DEBUG - 2012-07-22 09:15:53 --> Helper loaded: date_helper
DEBUG - 2012-07-22 09:15:53 --> Controller Class Initialized
DEBUG - 2012-07-22 09:15:53 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-07-22 09:15:53 --> Final output sent to browser
DEBUG - 2012-07-22 09:15:53 --> Total execution time: 0.0687
