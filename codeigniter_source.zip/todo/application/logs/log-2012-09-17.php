<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-09-17 08:45:39 --> Config Class Initialized
DEBUG - 2012-09-17 08:45:39 --> Hooks Class Initialized
DEBUG - 2012-09-17 08:45:39 --> Utf8 Class Initialized
DEBUG - 2012-09-17 08:45:39 --> UTF-8 Support Enabled
DEBUG - 2012-09-17 08:45:39 --> URI Class Initialized
DEBUG - 2012-09-17 08:45:39 --> Router Class Initialized
DEBUG - 2012-09-17 08:45:39 --> No URI present. Default controller set.
DEBUG - 2012-09-17 08:45:39 --> Output Class Initialized
DEBUG - 2012-09-17 08:45:39 --> Security Class Initialized
DEBUG - 2012-09-17 08:45:39 --> Input Class Initialized
DEBUG - 2012-09-17 08:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-17 08:45:39 --> Language Class Initialized
DEBUG - 2012-09-17 08:45:39 --> Loader Class Initialized
DEBUG - 2012-09-17 08:45:39 --> Helper loaded: date_helper
DEBUG - 2012-09-17 08:45:39 --> Controller Class Initialized
DEBUG - 2012-09-17 08:45:39 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-09-17 08:45:39 --> Final output sent to browser
DEBUG - 2012-09-17 08:45:39 --> Total execution time: 0.2182
DEBUG - 2012-09-17 12:55:33 --> Config Class Initialized
DEBUG - 2012-09-17 12:55:33 --> Hooks Class Initialized
DEBUG - 2012-09-17 12:55:33 --> Utf8 Class Initialized
DEBUG - 2012-09-17 12:55:33 --> UTF-8 Support Enabled
DEBUG - 2012-09-17 12:55:33 --> URI Class Initialized
DEBUG - 2012-09-17 12:55:33 --> Router Class Initialized
ERROR - 2012-09-17 12:55:33 --> 404 Page Not Found --> manager
