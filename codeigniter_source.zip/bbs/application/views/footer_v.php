
	<footer id="footer">
		<blockquote>
			<p><a class="azubu" href="http://www.cikorea.net/" target="blank">CodeIgniter한국사용자포럼</a></p>
			<small>Copyright by <em class="black"><a href="mailto:advisor@cikorea.net">웅파</a></small>
		<blockquote>
	</footer>

</div>

</body>
</html>