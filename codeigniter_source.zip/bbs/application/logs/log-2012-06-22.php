<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-06-22 10:33:52 --> Config Class Initialized
DEBUG - 2012-06-22 10:33:52 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:33:52 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:33:52 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:33:52 --> URI Class Initialized
DEBUG - 2012-06-22 10:33:52 --> Router Class Initialized
DEBUG - 2012-06-22 10:33:52 --> Output Class Initialized
DEBUG - 2012-06-22 10:33:52 --> Security Class Initialized
DEBUG - 2012-06-22 10:33:52 --> Input Class Initialized
DEBUG - 2012-06-22 10:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:33:52 --> Language Class Initialized
DEBUG - 2012-06-22 10:33:52 --> Loader Class Initialized
DEBUG - 2012-06-22 10:33:52 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:33:52 --> Controller Class Initialized
DEBUG - 2012-06-22 10:33:52 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:33:53 --> Model Class Initialized
DEBUG - 2012-06-22 10:33:53 --> Model Class Initialized
ERROR - 2012-06-22 10:33:53 --> Severity: Notice  --> Undefined variable: list D:\ci_book\svn\trunk\copy\html\application\views\board\view_v.php 60
ERROR - 2012-06-22 10:33:53 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\ci_book\svn\trunk\copy\html\application\views\board\view_v.php 60
ERROR - 2012-06-22 10:33:53 --> Severity: Notice  --> Undefined variable: pagination D:\ci_book\svn\trunk\copy\html\application\views\board\view_v.php 79
DEBUG - 2012-06-22 10:33:53 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 10:33:53 --> Final output sent to browser
DEBUG - 2012-06-22 10:33:53 --> Total execution time: 1.0763
DEBUG - 2012-06-22 10:43:11 --> Config Class Initialized
DEBUG - 2012-06-22 10:43:11 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:43:11 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:43:11 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:43:11 --> URI Class Initialized
DEBUG - 2012-06-22 10:43:11 --> Router Class Initialized
DEBUG - 2012-06-22 10:43:11 --> Output Class Initialized
DEBUG - 2012-06-22 10:43:11 --> Security Class Initialized
DEBUG - 2012-06-22 10:43:11 --> Input Class Initialized
DEBUG - 2012-06-22 10:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:43:11 --> Language Class Initialized
DEBUG - 2012-06-22 10:43:11 --> Loader Class Initialized
DEBUG - 2012-06-22 10:43:11 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:43:11 --> Controller Class Initialized
DEBUG - 2012-06-22 10:43:11 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:43:11 --> Model Class Initialized
DEBUG - 2012-06-22 10:43:11 --> Model Class Initialized
DEBUG - 2012-06-22 10:43:11 --> Pagination Class Initialized
DEBUG - 2012-06-22 10:43:11 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-22 10:43:11 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-22 10:43:11 --> Helper loaded: text_helper
DEBUG - 2012-06-22 10:43:11 --> Final output sent to browser
DEBUG - 2012-06-22 10:43:11 --> Total execution time: 0.1212
DEBUG - 2012-06-22 10:44:03 --> Config Class Initialized
DEBUG - 2012-06-22 10:44:03 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:44:03 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:44:03 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:44:03 --> URI Class Initialized
DEBUG - 2012-06-22 10:44:03 --> Router Class Initialized
DEBUG - 2012-06-22 10:44:03 --> Output Class Initialized
DEBUG - 2012-06-22 10:44:03 --> Security Class Initialized
DEBUG - 2012-06-22 10:44:03 --> Input Class Initialized
DEBUG - 2012-06-22 10:44:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:44:03 --> Language Class Initialized
DEBUG - 2012-06-22 10:44:03 --> Loader Class Initialized
DEBUG - 2012-06-22 10:44:03 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:44:03 --> Controller Class Initialized
DEBUG - 2012-06-22 10:44:03 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:44:03 --> Model Class Initialized
DEBUG - 2012-06-22 10:44:03 --> Model Class Initialized
DEBUG - 2012-06-22 10:44:03 --> Pagination Class Initialized
DEBUG - 2012-06-22 10:44:03 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-22 10:44:03 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-22 10:44:03 --> Helper loaded: text_helper
DEBUG - 2012-06-22 10:44:03 --> Final output sent to browser
DEBUG - 2012-06-22 10:44:03 --> Total execution time: 0.0485
DEBUG - 2012-06-22 10:44:45 --> Config Class Initialized
DEBUG - 2012-06-22 10:44:45 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:44:45 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:44:45 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:44:45 --> URI Class Initialized
DEBUG - 2012-06-22 10:44:45 --> Router Class Initialized
DEBUG - 2012-06-22 10:44:45 --> Output Class Initialized
DEBUG - 2012-06-22 10:44:45 --> Security Class Initialized
DEBUG - 2012-06-22 10:44:45 --> Input Class Initialized
DEBUG - 2012-06-22 10:44:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:44:45 --> Language Class Initialized
DEBUG - 2012-06-22 10:44:45 --> Loader Class Initialized
DEBUG - 2012-06-22 10:44:45 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:44:45 --> Controller Class Initialized
DEBUG - 2012-06-22 10:44:45 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:44:45 --> Model Class Initialized
DEBUG - 2012-06-22 10:44:45 --> Model Class Initialized
DEBUG - 2012-06-22 10:44:45 --> Pagination Class Initialized
DEBUG - 2012-06-22 10:44:45 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-22 10:44:45 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-22 10:44:45 --> Helper loaded: text_helper
DEBUG - 2012-06-22 10:44:45 --> Final output sent to browser
DEBUG - 2012-06-22 10:44:45 --> Total execution time: 0.0577
DEBUG - 2012-06-22 10:45:16 --> Config Class Initialized
DEBUG - 2012-06-22 10:45:16 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:45:16 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:45:16 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:45:16 --> URI Class Initialized
DEBUG - 2012-06-22 10:45:16 --> Router Class Initialized
DEBUG - 2012-06-22 10:45:16 --> Output Class Initialized
DEBUG - 2012-06-22 10:45:16 --> Security Class Initialized
DEBUG - 2012-06-22 10:45:16 --> Input Class Initialized
DEBUG - 2012-06-22 10:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:45:16 --> Language Class Initialized
DEBUG - 2012-06-22 10:45:16 --> Loader Class Initialized
DEBUG - 2012-06-22 10:45:16 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:45:16 --> Controller Class Initialized
DEBUG - 2012-06-22 10:45:16 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:45:16 --> Model Class Initialized
DEBUG - 2012-06-22 10:45:16 --> Model Class Initialized
DEBUG - 2012-06-22 10:45:16 --> Pagination Class Initialized
DEBUG - 2012-06-22 10:45:16 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-22 10:45:16 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-22 10:45:16 --> Helper loaded: text_helper
DEBUG - 2012-06-22 10:45:16 --> Final output sent to browser
DEBUG - 2012-06-22 10:45:16 --> Total execution time: 0.0363
DEBUG - 2012-06-22 10:45:22 --> Config Class Initialized
DEBUG - 2012-06-22 10:45:22 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:45:22 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:45:22 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:45:22 --> URI Class Initialized
DEBUG - 2012-06-22 10:45:22 --> Router Class Initialized
DEBUG - 2012-06-22 10:45:22 --> Output Class Initialized
DEBUG - 2012-06-22 10:45:22 --> Security Class Initialized
DEBUG - 2012-06-22 10:45:22 --> Input Class Initialized
DEBUG - 2012-06-22 10:45:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:45:22 --> Language Class Initialized
DEBUG - 2012-06-22 10:45:22 --> Loader Class Initialized
DEBUG - 2012-06-22 10:45:22 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:45:22 --> Controller Class Initialized
DEBUG - 2012-06-22 10:45:22 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:45:22 --> Model Class Initialized
DEBUG - 2012-06-22 10:45:22 --> Model Class Initialized
ERROR - 2012-06-22 10:45:22 --> Severity: Notice  --> Undefined variable: lt D:\ci_book\svn\trunk\copy\html\application\views\board\view_v.php 35
ERROR - 2012-06-22 10:45:22 --> Severity: Notice  --> Trying to get property of non-object D:\ci_book\svn\trunk\copy\html\application\views\board\view_v.php 35
ERROR - 2012-06-22 10:45:22 --> Severity: Notice  --> Undefined property: stdClass::$su D:\ci_book\svn\trunk\copy\html\application\views\board\view_v.php 41
DEBUG - 2012-06-22 10:45:22 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 10:45:22 --> Final output sent to browser
DEBUG - 2012-06-22 10:45:22 --> Total execution time: 0.0492
DEBUG - 2012-06-22 10:45:41 --> Config Class Initialized
DEBUG - 2012-06-22 10:45:41 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:45:41 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:45:41 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:45:41 --> URI Class Initialized
DEBUG - 2012-06-22 10:45:41 --> Router Class Initialized
DEBUG - 2012-06-22 10:45:41 --> Output Class Initialized
DEBUG - 2012-06-22 10:45:41 --> Security Class Initialized
DEBUG - 2012-06-22 10:45:41 --> Input Class Initialized
DEBUG - 2012-06-22 10:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:45:41 --> Language Class Initialized
DEBUG - 2012-06-22 10:45:41 --> Loader Class Initialized
DEBUG - 2012-06-22 10:45:41 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:45:41 --> Controller Class Initialized
DEBUG - 2012-06-22 10:45:41 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:45:41 --> Model Class Initialized
DEBUG - 2012-06-22 10:45:41 --> Model Class Initialized
DEBUG - 2012-06-22 10:45:41 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 10:45:41 --> Final output sent to browser
DEBUG - 2012-06-22 10:45:41 --> Total execution time: 0.0475
DEBUG - 2012-06-22 10:46:48 --> Config Class Initialized
DEBUG - 2012-06-22 10:46:48 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:46:48 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:46:48 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:46:48 --> URI Class Initialized
DEBUG - 2012-06-22 10:46:48 --> Router Class Initialized
DEBUG - 2012-06-22 10:46:48 --> Output Class Initialized
DEBUG - 2012-06-22 10:46:48 --> Security Class Initialized
DEBUG - 2012-06-22 10:46:48 --> Input Class Initialized
DEBUG - 2012-06-22 10:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:46:48 --> Language Class Initialized
DEBUG - 2012-06-22 10:46:48 --> Loader Class Initialized
DEBUG - 2012-06-22 10:46:48 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:46:48 --> Controller Class Initialized
DEBUG - 2012-06-22 10:46:48 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:46:48 --> Model Class Initialized
DEBUG - 2012-06-22 10:46:48 --> Model Class Initialized
DEBUG - 2012-06-22 10:46:48 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 10:46:48 --> Final output sent to browser
DEBUG - 2012-06-22 10:46:48 --> Total execution time: 0.1117
DEBUG - 2012-06-22 10:46:49 --> Config Class Initialized
DEBUG - 2012-06-22 10:46:49 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:46:49 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:46:49 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:46:49 --> URI Class Initialized
DEBUG - 2012-06-22 10:46:49 --> Router Class Initialized
DEBUG - 2012-06-22 10:46:49 --> Output Class Initialized
DEBUG - 2012-06-22 10:46:49 --> Security Class Initialized
DEBUG - 2012-06-22 10:46:49 --> Input Class Initialized
DEBUG - 2012-06-22 10:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:46:49 --> Language Class Initialized
DEBUG - 2012-06-22 10:46:49 --> Loader Class Initialized
DEBUG - 2012-06-22 10:46:49 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:46:49 --> Controller Class Initialized
DEBUG - 2012-06-22 10:46:49 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:46:49 --> Model Class Initialized
DEBUG - 2012-06-22 10:46:49 --> Model Class Initialized
DEBUG - 2012-06-22 10:46:49 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 10:46:49 --> Final output sent to browser
DEBUG - 2012-06-22 10:46:49 --> Total execution time: 0.0543
DEBUG - 2012-06-22 10:46:50 --> Config Class Initialized
DEBUG - 2012-06-22 10:46:50 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:46:50 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:46:50 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:46:50 --> URI Class Initialized
DEBUG - 2012-06-22 10:46:50 --> Router Class Initialized
DEBUG - 2012-06-22 10:46:50 --> Output Class Initialized
DEBUG - 2012-06-22 10:46:50 --> Security Class Initialized
DEBUG - 2012-06-22 10:46:50 --> Input Class Initialized
DEBUG - 2012-06-22 10:46:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:46:50 --> Language Class Initialized
DEBUG - 2012-06-22 10:46:50 --> Loader Class Initialized
DEBUG - 2012-06-22 10:46:50 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:46:50 --> Controller Class Initialized
DEBUG - 2012-06-22 10:46:50 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:46:50 --> Model Class Initialized
DEBUG - 2012-06-22 10:46:50 --> Model Class Initialized
DEBUG - 2012-06-22 10:46:50 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 10:46:50 --> Final output sent to browser
DEBUG - 2012-06-22 10:46:50 --> Total execution time: 0.0456
DEBUG - 2012-06-22 10:46:51 --> Config Class Initialized
DEBUG - 2012-06-22 10:46:51 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:46:51 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:46:51 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:46:51 --> URI Class Initialized
DEBUG - 2012-06-22 10:46:51 --> Router Class Initialized
DEBUG - 2012-06-22 10:46:51 --> Output Class Initialized
DEBUG - 2012-06-22 10:46:51 --> Security Class Initialized
DEBUG - 2012-06-22 10:46:51 --> Input Class Initialized
DEBUG - 2012-06-22 10:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:46:51 --> Language Class Initialized
DEBUG - 2012-06-22 10:46:51 --> Loader Class Initialized
DEBUG - 2012-06-22 10:46:51 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:46:51 --> Controller Class Initialized
DEBUG - 2012-06-22 10:46:51 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:46:51 --> Model Class Initialized
DEBUG - 2012-06-22 10:46:51 --> Model Class Initialized
DEBUG - 2012-06-22 10:46:51 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 10:46:51 --> Final output sent to browser
DEBUG - 2012-06-22 10:46:51 --> Total execution time: 0.0468
DEBUG - 2012-06-22 10:46:52 --> Config Class Initialized
DEBUG - 2012-06-22 10:46:52 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:46:52 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:46:52 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:46:52 --> URI Class Initialized
DEBUG - 2012-06-22 10:46:52 --> Router Class Initialized
DEBUG - 2012-06-22 10:46:52 --> Output Class Initialized
DEBUG - 2012-06-22 10:46:52 --> Security Class Initialized
DEBUG - 2012-06-22 10:46:52 --> Input Class Initialized
DEBUG - 2012-06-22 10:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:46:52 --> Language Class Initialized
DEBUG - 2012-06-22 10:46:52 --> Loader Class Initialized
DEBUG - 2012-06-22 10:46:52 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:46:52 --> Controller Class Initialized
DEBUG - 2012-06-22 10:46:52 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:46:52 --> Model Class Initialized
DEBUG - 2012-06-22 10:46:52 --> Model Class Initialized
DEBUG - 2012-06-22 10:46:52 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 10:46:52 --> Final output sent to browser
DEBUG - 2012-06-22 10:46:52 --> Total execution time: 0.0268
DEBUG - 2012-06-22 10:48:39 --> Config Class Initialized
DEBUG - 2012-06-22 10:48:39 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:48:39 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:48:39 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:48:39 --> URI Class Initialized
DEBUG - 2012-06-22 10:48:39 --> Router Class Initialized
DEBUG - 2012-06-22 10:48:39 --> Output Class Initialized
DEBUG - 2012-06-22 10:48:39 --> Security Class Initialized
DEBUG - 2012-06-22 10:48:39 --> Input Class Initialized
DEBUG - 2012-06-22 10:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:48:39 --> Language Class Initialized
DEBUG - 2012-06-22 10:48:39 --> Loader Class Initialized
DEBUG - 2012-06-22 10:48:39 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:48:39 --> Controller Class Initialized
DEBUG - 2012-06-22 10:48:39 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:48:39 --> Model Class Initialized
DEBUG - 2012-06-22 10:48:39 --> Model Class Initialized
DEBUG - 2012-06-22 10:48:39 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 10:48:39 --> Final output sent to browser
DEBUG - 2012-06-22 10:48:39 --> Total execution time: 0.0352
DEBUG - 2012-06-22 10:49:06 --> Config Class Initialized
DEBUG - 2012-06-22 10:49:06 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:49:06 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:49:06 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:49:06 --> URI Class Initialized
DEBUG - 2012-06-22 10:49:06 --> Router Class Initialized
DEBUG - 2012-06-22 10:49:06 --> Output Class Initialized
DEBUG - 2012-06-22 10:49:06 --> Security Class Initialized
DEBUG - 2012-06-22 10:49:06 --> Input Class Initialized
DEBUG - 2012-06-22 10:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:49:06 --> Language Class Initialized
DEBUG - 2012-06-22 10:49:06 --> Loader Class Initialized
DEBUG - 2012-06-22 10:49:06 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:49:06 --> Controller Class Initialized
DEBUG - 2012-06-22 10:49:06 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:49:06 --> Model Class Initialized
DEBUG - 2012-06-22 10:49:06 --> Model Class Initialized
DEBUG - 2012-06-22 10:49:06 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 10:49:06 --> Final output sent to browser
DEBUG - 2012-06-22 10:49:06 --> Total execution time: 0.0367
DEBUG - 2012-06-22 10:49:36 --> Config Class Initialized
DEBUG - 2012-06-22 10:49:36 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:49:36 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:49:36 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:49:36 --> URI Class Initialized
DEBUG - 2012-06-22 10:49:36 --> Router Class Initialized
DEBUG - 2012-06-22 10:49:36 --> Output Class Initialized
DEBUG - 2012-06-22 10:49:36 --> Security Class Initialized
DEBUG - 2012-06-22 10:49:36 --> Input Class Initialized
DEBUG - 2012-06-22 10:49:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:49:36 --> Language Class Initialized
DEBUG - 2012-06-22 10:49:36 --> Loader Class Initialized
DEBUG - 2012-06-22 10:49:36 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:49:36 --> Controller Class Initialized
DEBUG - 2012-06-22 10:49:36 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:49:36 --> Model Class Initialized
DEBUG - 2012-06-22 10:49:36 --> Model Class Initialized
DEBUG - 2012-06-22 10:49:36 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 10:49:36 --> Final output sent to browser
DEBUG - 2012-06-22 10:49:36 --> Total execution time: 0.0317
DEBUG - 2012-06-22 10:49:49 --> Config Class Initialized
DEBUG - 2012-06-22 10:49:49 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:49:49 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:49:49 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:49:49 --> URI Class Initialized
DEBUG - 2012-06-22 10:49:49 --> Router Class Initialized
DEBUG - 2012-06-22 10:49:49 --> Output Class Initialized
DEBUG - 2012-06-22 10:49:49 --> Security Class Initialized
DEBUG - 2012-06-22 10:49:49 --> Input Class Initialized
DEBUG - 2012-06-22 10:49:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:49:49 --> Language Class Initialized
DEBUG - 2012-06-22 10:49:49 --> Loader Class Initialized
DEBUG - 2012-06-22 10:49:49 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:49:49 --> Controller Class Initialized
DEBUG - 2012-06-22 10:49:49 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:49:49 --> Model Class Initialized
DEBUG - 2012-06-22 10:49:49 --> Model Class Initialized
DEBUG - 2012-06-22 10:49:49 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 10:49:49 --> Final output sent to browser
DEBUG - 2012-06-22 10:49:49 --> Total execution time: 0.0489
DEBUG - 2012-06-22 10:49:53 --> Config Class Initialized
DEBUG - 2012-06-22 10:49:53 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:49:53 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:49:53 --> URI Class Initialized
DEBUG - 2012-06-22 10:49:53 --> Router Class Initialized
DEBUG - 2012-06-22 10:49:53 --> Output Class Initialized
DEBUG - 2012-06-22 10:49:53 --> Security Class Initialized
DEBUG - 2012-06-22 10:49:53 --> Input Class Initialized
DEBUG - 2012-06-22 10:49:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:49:53 --> Language Class Initialized
DEBUG - 2012-06-22 10:49:53 --> Loader Class Initialized
DEBUG - 2012-06-22 10:49:53 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:49:53 --> Controller Class Initialized
DEBUG - 2012-06-22 10:49:53 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:49:53 --> Model Class Initialized
DEBUG - 2012-06-22 10:49:53 --> Model Class Initialized
DEBUG - 2012-06-22 10:49:53 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 10:49:53 --> Final output sent to browser
DEBUG - 2012-06-22 10:49:53 --> Total execution time: 0.0510
DEBUG - 2012-06-22 10:49:54 --> Config Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:49:54 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:49:54 --> URI Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Router Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Output Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Security Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Input Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:49:54 --> Language Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Loader Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:49:54 --> Controller Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Model Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Model Class Initialized
DEBUG - 2012-06-22 10:49:54 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 10:49:54 --> Final output sent to browser
DEBUG - 2012-06-22 10:49:54 --> Total execution time: 0.0498
DEBUG - 2012-06-22 10:49:54 --> Config Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:49:54 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:49:54 --> URI Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Router Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Output Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Security Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Input Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:49:54 --> Language Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Loader Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:49:54 --> Controller Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Model Class Initialized
DEBUG - 2012-06-22 10:49:54 --> Model Class Initialized
DEBUG - 2012-06-22 10:49:54 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 10:49:54 --> Final output sent to browser
DEBUG - 2012-06-22 10:49:54 --> Total execution time: 0.0420
DEBUG - 2012-06-22 10:49:55 --> Config Class Initialized
DEBUG - 2012-06-22 10:49:55 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:49:55 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:49:55 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:49:55 --> URI Class Initialized
DEBUG - 2012-06-22 10:49:55 --> Router Class Initialized
DEBUG - 2012-06-22 10:49:55 --> Output Class Initialized
DEBUG - 2012-06-22 10:49:55 --> Security Class Initialized
DEBUG - 2012-06-22 10:49:55 --> Input Class Initialized
DEBUG - 2012-06-22 10:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:49:55 --> Language Class Initialized
DEBUG - 2012-06-22 10:49:55 --> Loader Class Initialized
DEBUG - 2012-06-22 10:49:55 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:49:55 --> Controller Class Initialized
DEBUG - 2012-06-22 10:49:55 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:49:55 --> Model Class Initialized
DEBUG - 2012-06-22 10:49:55 --> Model Class Initialized
DEBUG - 2012-06-22 10:49:55 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 10:49:55 --> Final output sent to browser
DEBUG - 2012-06-22 10:49:55 --> Total execution time: 0.0474
DEBUG - 2012-06-22 10:50:36 --> Config Class Initialized
DEBUG - 2012-06-22 10:50:36 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:50:36 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:50:36 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:50:36 --> URI Class Initialized
DEBUG - 2012-06-22 10:50:36 --> Router Class Initialized
DEBUG - 2012-06-22 10:50:36 --> Output Class Initialized
DEBUG - 2012-06-22 10:50:36 --> Security Class Initialized
DEBUG - 2012-06-22 10:50:36 --> Input Class Initialized
DEBUG - 2012-06-22 10:50:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:50:36 --> Language Class Initialized
DEBUG - 2012-06-22 10:50:36 --> Loader Class Initialized
DEBUG - 2012-06-22 10:50:36 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:50:36 --> Controller Class Initialized
DEBUG - 2012-06-22 10:50:36 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:50:36 --> Model Class Initialized
DEBUG - 2012-06-22 10:50:36 --> Model Class Initialized
DEBUG - 2012-06-22 10:50:36 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 10:50:36 --> Final output sent to browser
DEBUG - 2012-06-22 10:50:36 --> Total execution time: 0.0389
DEBUG - 2012-06-22 10:50:40 --> Config Class Initialized
DEBUG - 2012-06-22 10:50:40 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:50:40 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:50:40 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:50:40 --> URI Class Initialized
DEBUG - 2012-06-22 10:50:40 --> Router Class Initialized
DEBUG - 2012-06-22 10:50:40 --> Output Class Initialized
DEBUG - 2012-06-22 10:50:40 --> Security Class Initialized
DEBUG - 2012-06-22 10:50:40 --> Input Class Initialized
DEBUG - 2012-06-22 10:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:50:40 --> Language Class Initialized
DEBUG - 2012-06-22 10:50:40 --> Loader Class Initialized
DEBUG - 2012-06-22 10:50:40 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:50:40 --> Controller Class Initialized
DEBUG - 2012-06-22 10:50:40 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:50:40 --> Model Class Initialized
DEBUG - 2012-06-22 10:50:40 --> Model Class Initialized
DEBUG - 2012-06-22 10:50:40 --> Pagination Class Initialized
DEBUG - 2012-06-22 10:50:40 --> DB Transaction Failure
ERROR - 2012-06-22 10:50:40 --> Query error: Table 'ci_book.page' doesn't exist
DEBUG - 2012-06-22 10:50:40 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-06-22 10:51:01 --> Config Class Initialized
DEBUG - 2012-06-22 10:51:01 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:51:01 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:51:01 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:51:01 --> URI Class Initialized
DEBUG - 2012-06-22 10:51:01 --> Router Class Initialized
DEBUG - 2012-06-22 10:51:01 --> Output Class Initialized
DEBUG - 2012-06-22 10:51:01 --> Security Class Initialized
DEBUG - 2012-06-22 10:51:01 --> Input Class Initialized
DEBUG - 2012-06-22 10:51:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:51:01 --> Language Class Initialized
DEBUG - 2012-06-22 10:51:01 --> Loader Class Initialized
DEBUG - 2012-06-22 10:51:01 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:51:01 --> Controller Class Initialized
DEBUG - 2012-06-22 10:51:01 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:51:01 --> Model Class Initialized
DEBUG - 2012-06-22 10:51:01 --> Model Class Initialized
DEBUG - 2012-06-22 10:51:01 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 10:51:01 --> Final output sent to browser
DEBUG - 2012-06-22 10:51:01 --> Total execution time: 0.0330
DEBUG - 2012-06-22 10:51:02 --> Config Class Initialized
DEBUG - 2012-06-22 10:51:02 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:51:02 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:51:02 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:51:02 --> URI Class Initialized
DEBUG - 2012-06-22 10:51:02 --> Router Class Initialized
DEBUG - 2012-06-22 10:51:02 --> Output Class Initialized
DEBUG - 2012-06-22 10:51:02 --> Security Class Initialized
DEBUG - 2012-06-22 10:51:02 --> Input Class Initialized
DEBUG - 2012-06-22 10:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:51:02 --> Language Class Initialized
DEBUG - 2012-06-22 10:51:02 --> Loader Class Initialized
DEBUG - 2012-06-22 10:51:02 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:51:02 --> Controller Class Initialized
DEBUG - 2012-06-22 10:51:02 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:51:02 --> Model Class Initialized
DEBUG - 2012-06-22 10:51:02 --> Model Class Initialized
DEBUG - 2012-06-22 10:51:02 --> Pagination Class Initialized
DEBUG - 2012-06-22 10:51:02 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-22 10:51:02 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-22 10:51:02 --> Helper loaded: text_helper
DEBUG - 2012-06-22 10:51:02 --> Final output sent to browser
DEBUG - 2012-06-22 10:51:02 --> Total execution time: 0.0459
DEBUG - 2012-06-22 10:51:04 --> Config Class Initialized
DEBUG - 2012-06-22 10:51:04 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:51:04 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:51:04 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:51:04 --> URI Class Initialized
DEBUG - 2012-06-22 10:51:04 --> Router Class Initialized
DEBUG - 2012-06-22 10:51:04 --> Output Class Initialized
DEBUG - 2012-06-22 10:51:04 --> Security Class Initialized
DEBUG - 2012-06-22 10:51:04 --> Input Class Initialized
DEBUG - 2012-06-22 10:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:51:04 --> Language Class Initialized
DEBUG - 2012-06-22 10:51:04 --> Loader Class Initialized
DEBUG - 2012-06-22 10:51:04 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:51:04 --> Controller Class Initialized
DEBUG - 2012-06-22 10:51:04 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:51:04 --> Model Class Initialized
DEBUG - 2012-06-22 10:51:04 --> Model Class Initialized
DEBUG - 2012-06-22 10:51:04 --> Pagination Class Initialized
DEBUG - 2012-06-22 10:51:04 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-22 10:51:04 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-22 10:51:04 --> Helper loaded: text_helper
DEBUG - 2012-06-22 10:51:04 --> Final output sent to browser
DEBUG - 2012-06-22 10:51:04 --> Total execution time: 0.0463
DEBUG - 2012-06-22 10:51:05 --> Config Class Initialized
DEBUG - 2012-06-22 10:51:05 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:51:05 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:51:05 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:51:05 --> URI Class Initialized
DEBUG - 2012-06-22 10:51:05 --> Router Class Initialized
DEBUG - 2012-06-22 10:51:05 --> Output Class Initialized
DEBUG - 2012-06-22 10:51:05 --> Security Class Initialized
DEBUG - 2012-06-22 10:51:05 --> Input Class Initialized
DEBUG - 2012-06-22 10:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:51:05 --> Language Class Initialized
DEBUG - 2012-06-22 10:51:05 --> Loader Class Initialized
DEBUG - 2012-06-22 10:51:05 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:51:05 --> Controller Class Initialized
DEBUG - 2012-06-22 10:51:05 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:51:05 --> Model Class Initialized
DEBUG - 2012-06-22 10:51:05 --> Model Class Initialized
DEBUG - 2012-06-22 10:51:05 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 10:51:05 --> Final output sent to browser
DEBUG - 2012-06-22 10:51:05 --> Total execution time: 0.0419
DEBUG - 2012-06-22 10:51:07 --> Config Class Initialized
DEBUG - 2012-06-22 10:51:07 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:51:07 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:51:07 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:51:07 --> URI Class Initialized
DEBUG - 2012-06-22 10:51:07 --> Router Class Initialized
DEBUG - 2012-06-22 10:51:07 --> Output Class Initialized
DEBUG - 2012-06-22 10:51:07 --> Security Class Initialized
DEBUG - 2012-06-22 10:51:07 --> Input Class Initialized
DEBUG - 2012-06-22 10:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:51:07 --> Language Class Initialized
DEBUG - 2012-06-22 10:51:07 --> Loader Class Initialized
DEBUG - 2012-06-22 10:51:07 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:51:07 --> Controller Class Initialized
DEBUG - 2012-06-22 10:51:07 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:51:07 --> Model Class Initialized
DEBUG - 2012-06-22 10:51:07 --> Model Class Initialized
DEBUG - 2012-06-22 10:51:07 --> Pagination Class Initialized
DEBUG - 2012-06-22 10:51:07 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-22 10:51:07 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-22 10:51:07 --> Helper loaded: text_helper
DEBUG - 2012-06-22 10:51:07 --> Final output sent to browser
DEBUG - 2012-06-22 10:51:07 --> Total execution time: 0.0458
DEBUG - 2012-06-22 10:51:19 --> Config Class Initialized
DEBUG - 2012-06-22 10:51:19 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:51:19 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:51:19 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:51:19 --> URI Class Initialized
DEBUG - 2012-06-22 10:51:19 --> Router Class Initialized
DEBUG - 2012-06-22 10:51:19 --> Output Class Initialized
DEBUG - 2012-06-22 10:51:19 --> Security Class Initialized
DEBUG - 2012-06-22 10:51:19 --> Input Class Initialized
DEBUG - 2012-06-22 10:51:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:51:19 --> Language Class Initialized
DEBUG - 2012-06-22 10:51:19 --> Loader Class Initialized
DEBUG - 2012-06-22 10:51:19 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:51:19 --> Controller Class Initialized
DEBUG - 2012-06-22 10:51:19 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:51:19 --> Model Class Initialized
DEBUG - 2012-06-22 10:51:19 --> Model Class Initialized
DEBUG - 2012-06-22 10:51:19 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 10:51:19 --> Final output sent to browser
DEBUG - 2012-06-22 10:51:19 --> Total execution time: 0.0466
DEBUG - 2012-06-22 10:51:30 --> Config Class Initialized
DEBUG - 2012-06-22 10:51:30 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:51:30 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:51:30 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:51:30 --> URI Class Initialized
DEBUG - 2012-06-22 10:51:30 --> Router Class Initialized
DEBUG - 2012-06-22 10:51:30 --> Output Class Initialized
DEBUG - 2012-06-22 10:51:30 --> Security Class Initialized
DEBUG - 2012-06-22 10:51:30 --> Input Class Initialized
DEBUG - 2012-06-22 10:51:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:51:30 --> Language Class Initialized
DEBUG - 2012-06-22 10:51:30 --> Loader Class Initialized
DEBUG - 2012-06-22 10:51:30 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:51:30 --> Controller Class Initialized
DEBUG - 2012-06-22 10:51:30 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:51:30 --> Model Class Initialized
DEBUG - 2012-06-22 10:51:30 --> Model Class Initialized
DEBUG - 2012-06-22 10:51:30 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 10:51:30 --> Final output sent to browser
DEBUG - 2012-06-22 10:51:30 --> Total execution time: 0.0505
DEBUG - 2012-06-22 10:59:22 --> Config Class Initialized
DEBUG - 2012-06-22 10:59:22 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:59:22 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:59:22 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:59:22 --> URI Class Initialized
DEBUG - 2012-06-22 10:59:22 --> Router Class Initialized
DEBUG - 2012-06-22 10:59:22 --> Output Class Initialized
DEBUG - 2012-06-22 10:59:22 --> Security Class Initialized
DEBUG - 2012-06-22 10:59:22 --> Input Class Initialized
DEBUG - 2012-06-22 10:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:59:22 --> Language Class Initialized
DEBUG - 2012-06-22 10:59:22 --> Loader Class Initialized
DEBUG - 2012-06-22 10:59:22 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:59:22 --> Controller Class Initialized
DEBUG - 2012-06-22 10:59:22 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:59:22 --> Model Class Initialized
DEBUG - 2012-06-22 10:59:22 --> Model Class Initialized
DEBUG - 2012-06-22 10:59:22 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 10:59:22 --> Final output sent to browser
DEBUG - 2012-06-22 10:59:22 --> Total execution time: 0.0365
DEBUG - 2012-06-22 10:59:50 --> Config Class Initialized
DEBUG - 2012-06-22 10:59:50 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:59:50 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:59:50 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:59:50 --> URI Class Initialized
DEBUG - 2012-06-22 10:59:50 --> Router Class Initialized
DEBUG - 2012-06-22 10:59:50 --> Output Class Initialized
DEBUG - 2012-06-22 10:59:50 --> Security Class Initialized
DEBUG - 2012-06-22 10:59:50 --> Input Class Initialized
DEBUG - 2012-06-22 10:59:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:59:50 --> Language Class Initialized
DEBUG - 2012-06-22 10:59:50 --> Loader Class Initialized
DEBUG - 2012-06-22 10:59:50 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:59:50 --> Controller Class Initialized
DEBUG - 2012-06-22 10:59:50 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:59:50 --> Model Class Initialized
DEBUG - 2012-06-22 10:59:50 --> Model Class Initialized
DEBUG - 2012-06-22 10:59:50 --> Pagination Class Initialized
DEBUG - 2012-06-22 10:59:50 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-22 10:59:50 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-22 10:59:50 --> Helper loaded: text_helper
DEBUG - 2012-06-22 10:59:50 --> Final output sent to browser
DEBUG - 2012-06-22 10:59:50 --> Total execution time: 0.0535
DEBUG - 2012-06-22 10:59:51 --> Config Class Initialized
DEBUG - 2012-06-22 10:59:51 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:59:51 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:59:51 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:59:51 --> URI Class Initialized
DEBUG - 2012-06-22 10:59:51 --> Router Class Initialized
DEBUG - 2012-06-22 10:59:51 --> Output Class Initialized
DEBUG - 2012-06-22 10:59:51 --> Security Class Initialized
DEBUG - 2012-06-22 10:59:51 --> Input Class Initialized
DEBUG - 2012-06-22 10:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:59:51 --> Language Class Initialized
DEBUG - 2012-06-22 10:59:51 --> Loader Class Initialized
DEBUG - 2012-06-22 10:59:51 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:59:51 --> Controller Class Initialized
DEBUG - 2012-06-22 10:59:51 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:59:51 --> Model Class Initialized
DEBUG - 2012-06-22 10:59:51 --> Model Class Initialized
DEBUG - 2012-06-22 10:59:51 --> Pagination Class Initialized
DEBUG - 2012-06-22 10:59:51 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-22 10:59:51 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-22 10:59:51 --> Helper loaded: text_helper
DEBUG - 2012-06-22 10:59:51 --> Final output sent to browser
DEBUG - 2012-06-22 10:59:51 --> Total execution time: 0.0505
DEBUG - 2012-06-22 10:59:55 --> Config Class Initialized
DEBUG - 2012-06-22 10:59:55 --> Hooks Class Initialized
DEBUG - 2012-06-22 10:59:55 --> Utf8 Class Initialized
DEBUG - 2012-06-22 10:59:55 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 10:59:55 --> URI Class Initialized
DEBUG - 2012-06-22 10:59:55 --> Router Class Initialized
DEBUG - 2012-06-22 10:59:55 --> Output Class Initialized
DEBUG - 2012-06-22 10:59:55 --> Security Class Initialized
DEBUG - 2012-06-22 10:59:55 --> Input Class Initialized
DEBUG - 2012-06-22 10:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 10:59:55 --> Language Class Initialized
DEBUG - 2012-06-22 10:59:55 --> Loader Class Initialized
DEBUG - 2012-06-22 10:59:55 --> Helper loaded: date_helper
DEBUG - 2012-06-22 10:59:55 --> Controller Class Initialized
DEBUG - 2012-06-22 10:59:55 --> Database Driver Class Initialized
DEBUG - 2012-06-22 10:59:55 --> Model Class Initialized
DEBUG - 2012-06-22 10:59:55 --> Model Class Initialized
DEBUG - 2012-06-22 10:59:55 --> DB Transaction Failure
ERROR - 2012-06-22 10:59:55 --> Query error: Table 'ci_book.board_id' doesn't exist
DEBUG - 2012-06-22 10:59:55 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-06-22 11:00:17 --> Config Class Initialized
DEBUG - 2012-06-22 11:00:17 --> Hooks Class Initialized
DEBUG - 2012-06-22 11:00:17 --> Utf8 Class Initialized
DEBUG - 2012-06-22 11:00:17 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 11:00:17 --> URI Class Initialized
DEBUG - 2012-06-22 11:00:17 --> Router Class Initialized
DEBUG - 2012-06-22 11:00:17 --> Output Class Initialized
DEBUG - 2012-06-22 11:00:17 --> Security Class Initialized
DEBUG - 2012-06-22 11:00:17 --> Input Class Initialized
DEBUG - 2012-06-22 11:00:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 11:00:17 --> Language Class Initialized
DEBUG - 2012-06-22 11:00:17 --> Loader Class Initialized
DEBUG - 2012-06-22 11:00:17 --> Helper loaded: date_helper
DEBUG - 2012-06-22 11:00:17 --> Controller Class Initialized
DEBUG - 2012-06-22 11:00:17 --> Database Driver Class Initialized
DEBUG - 2012-06-22 11:00:17 --> Model Class Initialized
DEBUG - 2012-06-22 11:00:17 --> Model Class Initialized
DEBUG - 2012-06-22 11:00:17 --> DB Transaction Failure
ERROR - 2012-06-22 11:00:17 --> Query error: Table 'ci_book.board_id' doesn't exist
DEBUG - 2012-06-22 11:00:17 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-06-22 11:01:07 --> Config Class Initialized
DEBUG - 2012-06-22 11:01:07 --> Hooks Class Initialized
DEBUG - 2012-06-22 11:01:07 --> Utf8 Class Initialized
DEBUG - 2012-06-22 11:01:07 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 11:01:07 --> URI Class Initialized
DEBUG - 2012-06-22 11:01:07 --> Router Class Initialized
DEBUG - 2012-06-22 11:01:07 --> Output Class Initialized
DEBUG - 2012-06-22 11:01:07 --> Security Class Initialized
DEBUG - 2012-06-22 11:01:07 --> Input Class Initialized
DEBUG - 2012-06-22 11:01:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 11:01:07 --> Language Class Initialized
DEBUG - 2012-06-22 11:01:07 --> Loader Class Initialized
DEBUG - 2012-06-22 11:01:07 --> Helper loaded: date_helper
DEBUG - 2012-06-22 11:01:07 --> Controller Class Initialized
DEBUG - 2012-06-22 11:01:07 --> Database Driver Class Initialized
DEBUG - 2012-06-22 11:01:07 --> Model Class Initialized
DEBUG - 2012-06-22 11:01:07 --> Model Class Initialized
DEBUG - 2012-06-22 11:01:07 --> Pagination Class Initialized
DEBUG - 2012-06-22 11:01:07 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-22 11:01:07 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-22 11:01:07 --> Helper loaded: text_helper
DEBUG - 2012-06-22 11:01:07 --> Final output sent to browser
DEBUG - 2012-06-22 11:01:07 --> Total execution time: 0.0295
DEBUG - 2012-06-22 11:01:08 --> Config Class Initialized
DEBUG - 2012-06-22 11:01:08 --> Hooks Class Initialized
DEBUG - 2012-06-22 11:01:08 --> Utf8 Class Initialized
DEBUG - 2012-06-22 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 11:01:08 --> URI Class Initialized
DEBUG - 2012-06-22 11:01:08 --> Router Class Initialized
DEBUG - 2012-06-22 11:01:08 --> Output Class Initialized
DEBUG - 2012-06-22 11:01:08 --> Security Class Initialized
DEBUG - 2012-06-22 11:01:08 --> Input Class Initialized
DEBUG - 2012-06-22 11:01:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 11:01:08 --> Language Class Initialized
DEBUG - 2012-06-22 11:01:08 --> Loader Class Initialized
DEBUG - 2012-06-22 11:01:08 --> Helper loaded: date_helper
DEBUG - 2012-06-22 11:01:08 --> Controller Class Initialized
DEBUG - 2012-06-22 11:01:08 --> Database Driver Class Initialized
DEBUG - 2012-06-22 11:01:08 --> Model Class Initialized
DEBUG - 2012-06-22 11:01:08 --> Model Class Initialized
DEBUG - 2012-06-22 11:01:08 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 11:01:08 --> Final output sent to browser
DEBUG - 2012-06-22 11:01:08 --> Total execution time: 0.0447
DEBUG - 2012-06-22 11:01:29 --> Config Class Initialized
DEBUG - 2012-06-22 11:01:29 --> Hooks Class Initialized
DEBUG - 2012-06-22 11:01:29 --> Utf8 Class Initialized
DEBUG - 2012-06-22 11:01:29 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 11:01:29 --> URI Class Initialized
DEBUG - 2012-06-22 11:01:29 --> Router Class Initialized
DEBUG - 2012-06-22 11:01:29 --> Output Class Initialized
DEBUG - 2012-06-22 11:01:29 --> Security Class Initialized
DEBUG - 2012-06-22 11:01:29 --> Input Class Initialized
DEBUG - 2012-06-22 11:01:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 11:01:29 --> Language Class Initialized
DEBUG - 2012-06-22 11:01:29 --> Loader Class Initialized
DEBUG - 2012-06-22 11:01:29 --> Helper loaded: date_helper
DEBUG - 2012-06-22 11:01:29 --> Controller Class Initialized
DEBUG - 2012-06-22 11:01:29 --> Database Driver Class Initialized
DEBUG - 2012-06-22 11:01:29 --> Model Class Initialized
DEBUG - 2012-06-22 11:01:29 --> Model Class Initialized
DEBUG - 2012-06-22 11:01:30 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 11:01:30 --> Final output sent to browser
DEBUG - 2012-06-22 11:01:30 --> Total execution time: 0.0623
DEBUG - 2012-06-22 11:01:32 --> Config Class Initialized
DEBUG - 2012-06-22 11:01:32 --> Hooks Class Initialized
DEBUG - 2012-06-22 11:01:32 --> Utf8 Class Initialized
DEBUG - 2012-06-22 11:01:32 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 11:01:32 --> URI Class Initialized
DEBUG - 2012-06-22 11:01:32 --> Router Class Initialized
DEBUG - 2012-06-22 11:01:32 --> Output Class Initialized
DEBUG - 2012-06-22 11:01:32 --> Security Class Initialized
DEBUG - 2012-06-22 11:01:32 --> Input Class Initialized
DEBUG - 2012-06-22 11:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 11:01:32 --> Language Class Initialized
DEBUG - 2012-06-22 11:01:32 --> Loader Class Initialized
DEBUG - 2012-06-22 11:01:32 --> Helper loaded: date_helper
DEBUG - 2012-06-22 11:01:32 --> Controller Class Initialized
DEBUG - 2012-06-22 11:01:32 --> Database Driver Class Initialized
DEBUG - 2012-06-22 11:01:32 --> Model Class Initialized
DEBUG - 2012-06-22 11:01:32 --> Model Class Initialized
DEBUG - 2012-06-22 11:01:32 --> Pagination Class Initialized
DEBUG - 2012-06-22 11:01:32 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-22 11:01:32 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-22 11:01:32 --> Helper loaded: text_helper
DEBUG - 2012-06-22 11:01:32 --> Final output sent to browser
DEBUG - 2012-06-22 11:01:32 --> Total execution time: 0.0491
DEBUG - 2012-06-22 11:01:36 --> Config Class Initialized
DEBUG - 2012-06-22 11:01:36 --> Hooks Class Initialized
DEBUG - 2012-06-22 11:01:36 --> Utf8 Class Initialized
DEBUG - 2012-06-22 11:01:36 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 11:01:36 --> URI Class Initialized
DEBUG - 2012-06-22 11:01:36 --> Router Class Initialized
DEBUG - 2012-06-22 11:01:36 --> Output Class Initialized
DEBUG - 2012-06-22 11:01:36 --> Security Class Initialized
DEBUG - 2012-06-22 11:01:36 --> Input Class Initialized
DEBUG - 2012-06-22 11:01:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 11:01:36 --> Language Class Initialized
DEBUG - 2012-06-22 11:01:36 --> Loader Class Initialized
DEBUG - 2012-06-22 11:01:36 --> Helper loaded: date_helper
DEBUG - 2012-06-22 11:01:36 --> Controller Class Initialized
DEBUG - 2012-06-22 11:01:36 --> Database Driver Class Initialized
DEBUG - 2012-06-22 11:01:36 --> Model Class Initialized
DEBUG - 2012-06-22 11:01:36 --> Model Class Initialized
DEBUG - 2012-06-22 11:01:36 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 11:01:36 --> Final output sent to browser
DEBUG - 2012-06-22 11:01:36 --> Total execution time: 0.0454
DEBUG - 2012-06-22 11:01:39 --> Config Class Initialized
DEBUG - 2012-06-22 11:01:39 --> Hooks Class Initialized
DEBUG - 2012-06-22 11:01:39 --> Utf8 Class Initialized
DEBUG - 2012-06-22 11:01:39 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 11:01:39 --> URI Class Initialized
DEBUG - 2012-06-22 11:01:39 --> Router Class Initialized
DEBUG - 2012-06-22 11:01:39 --> Output Class Initialized
DEBUG - 2012-06-22 11:01:39 --> Security Class Initialized
DEBUG - 2012-06-22 11:01:39 --> Input Class Initialized
DEBUG - 2012-06-22 11:01:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 11:01:39 --> Language Class Initialized
DEBUG - 2012-06-22 11:01:39 --> Loader Class Initialized
DEBUG - 2012-06-22 11:01:39 --> Helper loaded: date_helper
DEBUG - 2012-06-22 11:01:39 --> Controller Class Initialized
DEBUG - 2012-06-22 11:01:39 --> Database Driver Class Initialized
DEBUG - 2012-06-22 11:01:39 --> Model Class Initialized
DEBUG - 2012-06-22 11:01:39 --> Model Class Initialized
DEBUG - 2012-06-22 11:01:39 --> Pagination Class Initialized
DEBUG - 2012-06-22 11:01:39 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-22 11:01:39 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-22 11:01:39 --> Helper loaded: text_helper
DEBUG - 2012-06-22 11:01:39 --> Final output sent to browser
DEBUG - 2012-06-22 11:01:39 --> Total execution time: 0.0452
DEBUG - 2012-06-22 11:01:48 --> Config Class Initialized
DEBUG - 2012-06-22 11:01:48 --> Hooks Class Initialized
DEBUG - 2012-06-22 11:01:48 --> Utf8 Class Initialized
DEBUG - 2012-06-22 11:01:48 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 11:01:48 --> URI Class Initialized
DEBUG - 2012-06-22 11:01:48 --> Router Class Initialized
DEBUG - 2012-06-22 11:01:48 --> Output Class Initialized
DEBUG - 2012-06-22 11:01:48 --> Security Class Initialized
DEBUG - 2012-06-22 11:01:48 --> Input Class Initialized
DEBUG - 2012-06-22 11:01:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 11:01:48 --> Language Class Initialized
DEBUG - 2012-06-22 11:01:48 --> Loader Class Initialized
DEBUG - 2012-06-22 11:01:48 --> Helper loaded: date_helper
DEBUG - 2012-06-22 11:01:48 --> Controller Class Initialized
DEBUG - 2012-06-22 11:01:48 --> Database Driver Class Initialized
DEBUG - 2012-06-22 11:01:48 --> Model Class Initialized
DEBUG - 2012-06-22 11:01:48 --> Model Class Initialized
DEBUG - 2012-06-22 11:01:48 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 11:01:48 --> Final output sent to browser
DEBUG - 2012-06-22 11:01:48 --> Total execution time: 0.0506
DEBUG - 2012-06-22 11:02:39 --> Config Class Initialized
DEBUG - 2012-06-22 11:02:39 --> Hooks Class Initialized
DEBUG - 2012-06-22 11:02:39 --> Utf8 Class Initialized
DEBUG - 2012-06-22 11:02:39 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 11:02:39 --> URI Class Initialized
DEBUG - 2012-06-22 11:02:39 --> Router Class Initialized
DEBUG - 2012-06-22 11:02:39 --> Output Class Initialized
DEBUG - 2012-06-22 11:02:39 --> Security Class Initialized
DEBUG - 2012-06-22 11:02:39 --> Input Class Initialized
DEBUG - 2012-06-22 11:02:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 11:02:39 --> Language Class Initialized
DEBUG - 2012-06-22 11:02:40 --> Loader Class Initialized
DEBUG - 2012-06-22 11:02:40 --> Helper loaded: date_helper
DEBUG - 2012-06-22 11:02:40 --> Controller Class Initialized
DEBUG - 2012-06-22 11:02:40 --> Database Driver Class Initialized
DEBUG - 2012-06-22 11:02:40 --> Model Class Initialized
DEBUG - 2012-06-22 11:02:40 --> Model Class Initialized
DEBUG - 2012-06-22 11:02:40 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 11:02:40 --> Final output sent to browser
DEBUG - 2012-06-22 11:02:40 --> Total execution time: 0.0486
DEBUG - 2012-06-22 11:02:52 --> Config Class Initialized
DEBUG - 2012-06-22 11:02:52 --> Hooks Class Initialized
DEBUG - 2012-06-22 11:02:52 --> Utf8 Class Initialized
DEBUG - 2012-06-22 11:02:52 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 11:02:52 --> URI Class Initialized
DEBUG - 2012-06-22 11:02:52 --> Router Class Initialized
DEBUG - 2012-06-22 11:02:52 --> Output Class Initialized
DEBUG - 2012-06-22 11:02:52 --> Security Class Initialized
DEBUG - 2012-06-22 11:02:52 --> Input Class Initialized
DEBUG - 2012-06-22 11:02:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 11:02:52 --> Language Class Initialized
DEBUG - 2012-06-22 11:02:52 --> Loader Class Initialized
DEBUG - 2012-06-22 11:02:52 --> Helper loaded: date_helper
DEBUG - 2012-06-22 11:02:52 --> Controller Class Initialized
DEBUG - 2012-06-22 11:02:52 --> Database Driver Class Initialized
DEBUG - 2012-06-22 11:02:52 --> Model Class Initialized
DEBUG - 2012-06-22 11:02:52 --> Model Class Initialized
DEBUG - 2012-06-22 11:02:52 --> Pagination Class Initialized
DEBUG - 2012-06-22 11:02:52 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-22 11:02:52 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-22 11:02:52 --> Helper loaded: text_helper
DEBUG - 2012-06-22 11:02:52 --> Final output sent to browser
DEBUG - 2012-06-22 11:02:52 --> Total execution time: 0.0504
DEBUG - 2012-06-22 11:04:39 --> Config Class Initialized
DEBUG - 2012-06-22 11:04:39 --> Hooks Class Initialized
DEBUG - 2012-06-22 11:04:39 --> Utf8 Class Initialized
DEBUG - 2012-06-22 11:04:39 --> UTF-8 Support Enabled
DEBUG - 2012-06-22 11:04:39 --> URI Class Initialized
DEBUG - 2012-06-22 11:04:39 --> Router Class Initialized
DEBUG - 2012-06-22 11:04:39 --> Output Class Initialized
DEBUG - 2012-06-22 11:04:39 --> Security Class Initialized
DEBUG - 2012-06-22 11:04:39 --> Input Class Initialized
DEBUG - 2012-06-22 11:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-22 11:04:39 --> Language Class Initialized
DEBUG - 2012-06-22 11:04:39 --> Loader Class Initialized
DEBUG - 2012-06-22 11:04:39 --> Helper loaded: date_helper
DEBUG - 2012-06-22 11:04:39 --> Controller Class Initialized
DEBUG - 2012-06-22 11:04:39 --> Database Driver Class Initialized
DEBUG - 2012-06-22 11:04:39 --> Model Class Initialized
DEBUG - 2012-06-22 11:04:39 --> Model Class Initialized
DEBUG - 2012-06-22 11:04:39 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-22 11:04:39 --> Final output sent to browser
DEBUG - 2012-06-22 11:04:39 --> Total execution time: 0.0461
