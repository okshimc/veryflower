<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-06-20 03:33:12 --> Config Class Initialized
DEBUG - 2012-06-20 03:33:12 --> Hooks Class Initialized
DEBUG - 2012-06-20 03:33:12 --> Utf8 Class Initialized
DEBUG - 2012-06-20 03:33:12 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 03:33:12 --> URI Class Initialized
DEBUG - 2012-06-20 03:33:12 --> Router Class Initialized
DEBUG - 2012-06-20 03:33:12 --> No URI present. Default controller set.
DEBUG - 2012-06-20 03:33:12 --> Output Class Initialized
DEBUG - 2012-06-20 03:33:12 --> Security Class Initialized
DEBUG - 2012-06-20 03:33:12 --> Input Class Initialized
DEBUG - 2012-06-20 03:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 03:33:12 --> Language Class Initialized
DEBUG - 2012-06-20 03:33:12 --> Loader Class Initialized
DEBUG - 2012-06-20 03:33:12 --> Helper loaded: date_helper
DEBUG - 2012-06-20 03:33:12 --> Controller Class Initialized
DEBUG - 2012-06-20 03:33:12 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-06-20 03:33:12 --> Final output sent to browser
DEBUG - 2012-06-20 03:33:12 --> Total execution time: 0.0752
DEBUG - 2012-06-20 03:33:36 --> Config Class Initialized
DEBUG - 2012-06-20 03:33:36 --> Hooks Class Initialized
DEBUG - 2012-06-20 03:33:36 --> Utf8 Class Initialized
DEBUG - 2012-06-20 03:33:36 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 03:33:36 --> URI Class Initialized
DEBUG - 2012-06-20 03:33:36 --> Router Class Initialized
DEBUG - 2012-06-20 03:33:36 --> Output Class Initialized
DEBUG - 2012-06-20 03:33:36 --> Security Class Initialized
DEBUG - 2012-06-20 03:33:36 --> Input Class Initialized
DEBUG - 2012-06-20 03:33:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 03:33:36 --> Language Class Initialized
DEBUG - 2012-06-20 03:33:36 --> Loader Class Initialized
DEBUG - 2012-06-20 03:33:36 --> Helper loaded: date_helper
DEBUG - 2012-06-20 03:33:36 --> Controller Class Initialized
DEBUG - 2012-06-20 03:33:36 --> Database Driver Class Initialized
DEBUG - 2012-06-20 03:33:36 --> Model Class Initialized
DEBUG - 2012-06-20 03:33:36 --> Model Class Initialized
DEBUG - 2012-06-20 03:33:36 --> Pagination Class Initialized
DEBUG - 2012-06-20 03:33:37 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 03:33:37 --> Final output sent to browser
DEBUG - 2012-06-20 03:33:37 --> Total execution time: 0.2858
DEBUG - 2012-06-20 03:34:57 --> Config Class Initialized
DEBUG - 2012-06-20 03:34:57 --> Hooks Class Initialized
DEBUG - 2012-06-20 03:34:57 --> Utf8 Class Initialized
DEBUG - 2012-06-20 03:34:57 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 03:34:57 --> URI Class Initialized
DEBUG - 2012-06-20 03:34:57 --> Router Class Initialized
DEBUG - 2012-06-20 03:34:57 --> Output Class Initialized
DEBUG - 2012-06-20 03:34:57 --> Security Class Initialized
DEBUG - 2012-06-20 03:34:57 --> Input Class Initialized
DEBUG - 2012-06-20 03:34:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 03:34:57 --> Language Class Initialized
DEBUG - 2012-06-20 03:34:57 --> Loader Class Initialized
DEBUG - 2012-06-20 03:34:57 --> Helper loaded: date_helper
DEBUG - 2012-06-20 03:34:57 --> Controller Class Initialized
DEBUG - 2012-06-20 03:34:57 --> Database Driver Class Initialized
DEBUG - 2012-06-20 03:34:57 --> Model Class Initialized
DEBUG - 2012-06-20 03:34:57 --> Model Class Initialized
DEBUG - 2012-06-20 03:34:57 --> Pagination Class Initialized
DEBUG - 2012-06-20 03:34:57 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 03:34:57 --> Final output sent to browser
DEBUG - 2012-06-20 03:34:57 --> Total execution time: 0.0477
DEBUG - 2012-06-20 03:36:03 --> Config Class Initialized
DEBUG - 2012-06-20 03:36:03 --> Hooks Class Initialized
DEBUG - 2012-06-20 03:36:03 --> Utf8 Class Initialized
DEBUG - 2012-06-20 03:36:03 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 03:36:03 --> URI Class Initialized
DEBUG - 2012-06-20 03:36:03 --> Router Class Initialized
DEBUG - 2012-06-20 03:36:03 --> Output Class Initialized
DEBUG - 2012-06-20 03:36:03 --> Security Class Initialized
DEBUG - 2012-06-20 03:36:03 --> Input Class Initialized
DEBUG - 2012-06-20 03:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 03:36:03 --> Language Class Initialized
DEBUG - 2012-06-20 03:36:03 --> Loader Class Initialized
DEBUG - 2012-06-20 03:36:03 --> Helper loaded: date_helper
DEBUG - 2012-06-20 03:36:03 --> Controller Class Initialized
DEBUG - 2012-06-20 03:36:03 --> Database Driver Class Initialized
DEBUG - 2012-06-20 03:36:03 --> Model Class Initialized
DEBUG - 2012-06-20 03:36:03 --> Model Class Initialized
DEBUG - 2012-06-20 03:36:03 --> Pagination Class Initialized
DEBUG - 2012-06-20 03:36:03 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 03:36:03 --> Final output sent to browser
DEBUG - 2012-06-20 03:36:03 --> Total execution time: 0.0422
DEBUG - 2012-06-20 03:36:37 --> Config Class Initialized
DEBUG - 2012-06-20 03:36:37 --> Hooks Class Initialized
DEBUG - 2012-06-20 03:36:37 --> Utf8 Class Initialized
DEBUG - 2012-06-20 03:36:37 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 03:36:37 --> URI Class Initialized
DEBUG - 2012-06-20 03:36:37 --> Router Class Initialized
DEBUG - 2012-06-20 03:36:37 --> Output Class Initialized
DEBUG - 2012-06-20 03:36:37 --> Security Class Initialized
DEBUG - 2012-06-20 03:36:37 --> Input Class Initialized
DEBUG - 2012-06-20 03:36:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 03:36:37 --> Language Class Initialized
DEBUG - 2012-06-20 03:36:37 --> Loader Class Initialized
DEBUG - 2012-06-20 03:36:37 --> Helper loaded: date_helper
DEBUG - 2012-06-20 03:36:37 --> Controller Class Initialized
DEBUG - 2012-06-20 03:36:37 --> Database Driver Class Initialized
DEBUG - 2012-06-20 03:36:37 --> Model Class Initialized
DEBUG - 2012-06-20 03:36:37 --> Model Class Initialized
DEBUG - 2012-06-20 03:36:37 --> Pagination Class Initialized
DEBUG - 2012-06-20 03:36:37 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 03:36:37 --> Final output sent to browser
DEBUG - 2012-06-20 03:36:37 --> Total execution time: 0.0430
DEBUG - 2012-06-20 03:36:39 --> Config Class Initialized
DEBUG - 2012-06-20 03:36:39 --> Hooks Class Initialized
DEBUG - 2012-06-20 03:36:39 --> Utf8 Class Initialized
DEBUG - 2012-06-20 03:36:39 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 03:36:39 --> URI Class Initialized
DEBUG - 2012-06-20 03:36:39 --> Router Class Initialized
DEBUG - 2012-06-20 03:36:39 --> Output Class Initialized
DEBUG - 2012-06-20 03:36:39 --> Security Class Initialized
DEBUG - 2012-06-20 03:36:39 --> Input Class Initialized
DEBUG - 2012-06-20 03:36:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 03:36:39 --> Language Class Initialized
DEBUG - 2012-06-20 03:36:39 --> Loader Class Initialized
DEBUG - 2012-06-20 03:36:39 --> Helper loaded: date_helper
DEBUG - 2012-06-20 03:36:39 --> Controller Class Initialized
DEBUG - 2012-06-20 03:36:39 --> Database Driver Class Initialized
DEBUG - 2012-06-20 03:36:39 --> Model Class Initialized
DEBUG - 2012-06-20 03:36:39 --> Model Class Initialized
DEBUG - 2012-06-20 03:36:39 --> Final output sent to browser
DEBUG - 2012-06-20 03:36:39 --> Total execution time: 0.0401
DEBUG - 2012-06-20 03:57:05 --> Config Class Initialized
DEBUG - 2012-06-20 03:57:05 --> Hooks Class Initialized
DEBUG - 2012-06-20 03:57:05 --> Utf8 Class Initialized
DEBUG - 2012-06-20 03:57:05 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 03:57:05 --> URI Class Initialized
DEBUG - 2012-06-20 03:57:05 --> Router Class Initialized
DEBUG - 2012-06-20 03:57:05 --> Output Class Initialized
DEBUG - 2012-06-20 03:57:05 --> Security Class Initialized
DEBUG - 2012-06-20 03:57:05 --> Input Class Initialized
DEBUG - 2012-06-20 03:57:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 03:57:05 --> Language Class Initialized
DEBUG - 2012-06-20 03:57:05 --> Loader Class Initialized
DEBUG - 2012-06-20 03:57:05 --> Helper loaded: date_helper
DEBUG - 2012-06-20 03:57:05 --> Controller Class Initialized
DEBUG - 2012-06-20 03:57:05 --> Database Driver Class Initialized
DEBUG - 2012-06-20 03:57:05 --> Model Class Initialized
DEBUG - 2012-06-20 03:57:05 --> Model Class Initialized
DEBUG - 2012-06-20 03:57:05 --> Pagination Class Initialized
DEBUG - 2012-06-20 03:57:20 --> Config Class Initialized
DEBUG - 2012-06-20 03:57:20 --> Hooks Class Initialized
DEBUG - 2012-06-20 03:57:20 --> Utf8 Class Initialized
DEBUG - 2012-06-20 03:57:20 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 03:57:20 --> URI Class Initialized
DEBUG - 2012-06-20 03:57:20 --> Router Class Initialized
DEBUG - 2012-06-20 03:57:20 --> Output Class Initialized
DEBUG - 2012-06-20 03:57:20 --> Security Class Initialized
DEBUG - 2012-06-20 03:57:20 --> Input Class Initialized
DEBUG - 2012-06-20 03:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 03:57:20 --> Language Class Initialized
DEBUG - 2012-06-20 03:57:20 --> Loader Class Initialized
DEBUG - 2012-06-20 03:57:20 --> Helper loaded: date_helper
DEBUG - 2012-06-20 03:57:20 --> Controller Class Initialized
DEBUG - 2012-06-20 03:57:20 --> Database Driver Class Initialized
DEBUG - 2012-06-20 03:57:20 --> Model Class Initialized
DEBUG - 2012-06-20 03:57:20 --> Model Class Initialized
DEBUG - 2012-06-20 03:57:20 --> Pagination Class Initialized
DEBUG - 2012-06-20 03:57:20 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 03:57:20 --> Final output sent to browser
DEBUG - 2012-06-20 03:57:20 --> Total execution time: 0.0471
DEBUG - 2012-06-20 03:57:26 --> Config Class Initialized
DEBUG - 2012-06-20 03:57:26 --> Hooks Class Initialized
DEBUG - 2012-06-20 03:57:26 --> Utf8 Class Initialized
DEBUG - 2012-06-20 03:57:26 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 03:57:26 --> URI Class Initialized
DEBUG - 2012-06-20 03:57:26 --> Router Class Initialized
DEBUG - 2012-06-20 03:57:26 --> Output Class Initialized
DEBUG - 2012-06-20 03:57:26 --> Security Class Initialized
DEBUG - 2012-06-20 03:57:26 --> Input Class Initialized
DEBUG - 2012-06-20 03:57:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 03:57:26 --> Language Class Initialized
DEBUG - 2012-06-20 03:57:26 --> Loader Class Initialized
DEBUG - 2012-06-20 03:57:26 --> Helper loaded: date_helper
DEBUG - 2012-06-20 03:57:26 --> Controller Class Initialized
DEBUG - 2012-06-20 03:57:26 --> Database Driver Class Initialized
DEBUG - 2012-06-20 03:57:26 --> Model Class Initialized
DEBUG - 2012-06-20 03:57:26 --> Model Class Initialized
DEBUG - 2012-06-20 03:57:26 --> XSS Filtering completed
DEBUG - 2012-06-20 03:57:26 --> Pagination Class Initialized
DEBUG - 2012-06-20 03:57:26 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 03:57:26 --> Final output sent to browser
DEBUG - 2012-06-20 03:57:26 --> Total execution time: 0.0466
DEBUG - 2012-06-20 03:57:41 --> Config Class Initialized
DEBUG - 2012-06-20 03:57:41 --> Hooks Class Initialized
DEBUG - 2012-06-20 03:57:41 --> Utf8 Class Initialized
DEBUG - 2012-06-20 03:57:41 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 03:57:41 --> URI Class Initialized
DEBUG - 2012-06-20 03:57:41 --> Router Class Initialized
DEBUG - 2012-06-20 03:57:41 --> Output Class Initialized
DEBUG - 2012-06-20 03:57:41 --> Security Class Initialized
DEBUG - 2012-06-20 03:57:41 --> Input Class Initialized
DEBUG - 2012-06-20 03:57:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 03:57:41 --> Language Class Initialized
DEBUG - 2012-06-20 03:57:41 --> Loader Class Initialized
DEBUG - 2012-06-20 03:57:41 --> Helper loaded: date_helper
DEBUG - 2012-06-20 03:57:41 --> Controller Class Initialized
DEBUG - 2012-06-20 03:57:41 --> Database Driver Class Initialized
DEBUG - 2012-06-20 03:57:41 --> Model Class Initialized
DEBUG - 2012-06-20 03:57:41 --> Model Class Initialized
DEBUG - 2012-06-20 03:57:41 --> XSS Filtering completed
DEBUG - 2012-06-20 03:57:41 --> Pagination Class Initialized
DEBUG - 2012-06-20 03:57:41 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 03:57:41 --> Final output sent to browser
DEBUG - 2012-06-20 03:57:41 --> Total execution time: 0.0461
DEBUG - 2012-06-20 03:57:49 --> Config Class Initialized
DEBUG - 2012-06-20 03:57:49 --> Hooks Class Initialized
DEBUG - 2012-06-20 03:57:49 --> Utf8 Class Initialized
DEBUG - 2012-06-20 03:57:49 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 03:57:49 --> URI Class Initialized
DEBUG - 2012-06-20 03:57:49 --> Router Class Initialized
DEBUG - 2012-06-20 03:57:49 --> Output Class Initialized
DEBUG - 2012-06-20 03:57:49 --> Security Class Initialized
DEBUG - 2012-06-20 03:57:49 --> Input Class Initialized
DEBUG - 2012-06-20 03:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 03:57:49 --> Language Class Initialized
DEBUG - 2012-06-20 03:57:49 --> Loader Class Initialized
DEBUG - 2012-06-20 03:57:49 --> Helper loaded: date_helper
DEBUG - 2012-06-20 03:57:49 --> Controller Class Initialized
DEBUG - 2012-06-20 03:57:49 --> Database Driver Class Initialized
DEBUG - 2012-06-20 03:57:49 --> Model Class Initialized
DEBUG - 2012-06-20 03:57:49 --> Model Class Initialized
DEBUG - 2012-06-20 03:57:49 --> Pagination Class Initialized
DEBUG - 2012-06-20 03:57:49 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 03:57:49 --> Final output sent to browser
DEBUG - 2012-06-20 03:57:49 --> Total execution time: 0.0468
DEBUG - 2012-06-20 03:58:02 --> Config Class Initialized
DEBUG - 2012-06-20 03:58:02 --> Hooks Class Initialized
DEBUG - 2012-06-20 03:58:02 --> Utf8 Class Initialized
DEBUG - 2012-06-20 03:58:02 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 03:58:02 --> URI Class Initialized
DEBUG - 2012-06-20 03:58:02 --> Router Class Initialized
DEBUG - 2012-06-20 03:58:02 --> Output Class Initialized
DEBUG - 2012-06-20 03:58:02 --> Security Class Initialized
DEBUG - 2012-06-20 03:58:02 --> Input Class Initialized
DEBUG - 2012-06-20 03:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 03:58:02 --> Language Class Initialized
DEBUG - 2012-06-20 03:58:02 --> Loader Class Initialized
DEBUG - 2012-06-20 03:58:02 --> Helper loaded: date_helper
DEBUG - 2012-06-20 03:58:02 --> Controller Class Initialized
DEBUG - 2012-06-20 03:58:02 --> Database Driver Class Initialized
DEBUG - 2012-06-20 03:58:02 --> Model Class Initialized
DEBUG - 2012-06-20 03:58:02 --> Model Class Initialized
DEBUG - 2012-06-20 03:58:02 --> XSS Filtering completed
DEBUG - 2012-06-20 03:58:02 --> Pagination Class Initialized
DEBUG - 2012-06-20 03:58:02 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 03:58:02 --> Final output sent to browser
DEBUG - 2012-06-20 03:58:02 --> Total execution time: 0.0441
DEBUG - 2012-06-20 03:58:43 --> Config Class Initialized
DEBUG - 2012-06-20 03:58:43 --> Hooks Class Initialized
DEBUG - 2012-06-20 03:58:43 --> Utf8 Class Initialized
DEBUG - 2012-06-20 03:58:43 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 03:58:43 --> URI Class Initialized
DEBUG - 2012-06-20 03:58:43 --> Router Class Initialized
DEBUG - 2012-06-20 03:58:43 --> Output Class Initialized
DEBUG - 2012-06-20 03:58:43 --> Security Class Initialized
DEBUG - 2012-06-20 03:58:43 --> Input Class Initialized
DEBUG - 2012-06-20 03:58:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 03:58:43 --> Language Class Initialized
DEBUG - 2012-06-20 03:58:43 --> Loader Class Initialized
DEBUG - 2012-06-20 03:58:43 --> Helper loaded: date_helper
DEBUG - 2012-06-20 03:58:43 --> Controller Class Initialized
DEBUG - 2012-06-20 03:58:43 --> Database Driver Class Initialized
DEBUG - 2012-06-20 03:58:43 --> Model Class Initialized
DEBUG - 2012-06-20 03:58:43 --> Model Class Initialized
DEBUG - 2012-06-20 03:58:43 --> XSS Filtering completed
DEBUG - 2012-06-20 03:58:43 --> Pagination Class Initialized
DEBUG - 2012-06-20 03:58:43 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 03:58:43 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 03:58:43 --> Helper loaded: text_helper
DEBUG - 2012-06-20 03:58:43 --> Final output sent to browser
DEBUG - 2012-06-20 03:58:43 --> Total execution time: 0.0470
DEBUG - 2012-06-20 03:59:24 --> Config Class Initialized
DEBUG - 2012-06-20 03:59:24 --> Hooks Class Initialized
DEBUG - 2012-06-20 03:59:24 --> Utf8 Class Initialized
DEBUG - 2012-06-20 03:59:24 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 03:59:24 --> URI Class Initialized
DEBUG - 2012-06-20 03:59:24 --> Router Class Initialized
DEBUG - 2012-06-20 03:59:24 --> Output Class Initialized
DEBUG - 2012-06-20 03:59:24 --> Security Class Initialized
DEBUG - 2012-06-20 03:59:24 --> Input Class Initialized
DEBUG - 2012-06-20 03:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 03:59:24 --> Language Class Initialized
DEBUG - 2012-06-20 03:59:24 --> Loader Class Initialized
DEBUG - 2012-06-20 03:59:24 --> Helper loaded: date_helper
DEBUG - 2012-06-20 03:59:24 --> Controller Class Initialized
DEBUG - 2012-06-20 03:59:24 --> Database Driver Class Initialized
DEBUG - 2012-06-20 03:59:24 --> Model Class Initialized
DEBUG - 2012-06-20 03:59:24 --> Model Class Initialized
DEBUG - 2012-06-20 03:59:24 --> XSS Filtering completed
DEBUG - 2012-06-20 03:59:24 --> Pagination Class Initialized
DEBUG - 2012-06-20 03:59:24 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 03:59:24 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 03:59:24 --> Helper loaded: text_helper
DEBUG - 2012-06-20 03:59:24 --> Final output sent to browser
DEBUG - 2012-06-20 03:59:24 --> Total execution time: 0.0445
DEBUG - 2012-06-20 03:59:52 --> Config Class Initialized
DEBUG - 2012-06-20 03:59:52 --> Hooks Class Initialized
DEBUG - 2012-06-20 03:59:52 --> Utf8 Class Initialized
DEBUG - 2012-06-20 03:59:52 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 03:59:52 --> URI Class Initialized
DEBUG - 2012-06-20 03:59:52 --> Router Class Initialized
DEBUG - 2012-06-20 03:59:52 --> Output Class Initialized
DEBUG - 2012-06-20 03:59:52 --> Security Class Initialized
DEBUG - 2012-06-20 03:59:52 --> Input Class Initialized
DEBUG - 2012-06-20 03:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 03:59:52 --> Language Class Initialized
DEBUG - 2012-06-20 03:59:52 --> Loader Class Initialized
DEBUG - 2012-06-20 03:59:52 --> Helper loaded: date_helper
DEBUG - 2012-06-20 03:59:52 --> Controller Class Initialized
DEBUG - 2012-06-20 03:59:52 --> Database Driver Class Initialized
DEBUG - 2012-06-20 03:59:52 --> Model Class Initialized
DEBUG - 2012-06-20 03:59:52 --> Model Class Initialized
DEBUG - 2012-06-20 03:59:52 --> Pagination Class Initialized
DEBUG - 2012-06-20 03:59:52 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 03:59:52 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 03:59:52 --> Helper loaded: text_helper
DEBUG - 2012-06-20 03:59:52 --> Final output sent to browser
DEBUG - 2012-06-20 03:59:52 --> Total execution time: 0.0512
DEBUG - 2012-06-20 03:59:58 --> Config Class Initialized
DEBUG - 2012-06-20 03:59:58 --> Hooks Class Initialized
DEBUG - 2012-06-20 03:59:58 --> Utf8 Class Initialized
DEBUG - 2012-06-20 03:59:58 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 03:59:58 --> URI Class Initialized
DEBUG - 2012-06-20 03:59:58 --> Router Class Initialized
DEBUG - 2012-06-20 03:59:58 --> Output Class Initialized
DEBUG - 2012-06-20 03:59:58 --> Security Class Initialized
DEBUG - 2012-06-20 03:59:58 --> Input Class Initialized
DEBUG - 2012-06-20 03:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 03:59:58 --> Language Class Initialized
DEBUG - 2012-06-20 03:59:58 --> Loader Class Initialized
DEBUG - 2012-06-20 03:59:58 --> Helper loaded: date_helper
DEBUG - 2012-06-20 03:59:58 --> Controller Class Initialized
DEBUG - 2012-06-20 03:59:58 --> Database Driver Class Initialized
DEBUG - 2012-06-20 03:59:58 --> Model Class Initialized
DEBUG - 2012-06-20 03:59:58 --> Model Class Initialized
DEBUG - 2012-06-20 03:59:58 --> XSS Filtering completed
DEBUG - 2012-06-20 03:59:58 --> Pagination Class Initialized
DEBUG - 2012-06-20 03:59:58 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 03:59:58 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 03:59:58 --> Helper loaded: text_helper
DEBUG - 2012-06-20 03:59:58 --> Final output sent to browser
DEBUG - 2012-06-20 03:59:58 --> Total execution time: 0.0560
DEBUG - 2012-06-20 04:00:39 --> Config Class Initialized
DEBUG - 2012-06-20 04:00:39 --> Hooks Class Initialized
DEBUG - 2012-06-20 04:00:39 --> Utf8 Class Initialized
DEBUG - 2012-06-20 04:00:39 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 04:00:39 --> URI Class Initialized
DEBUG - 2012-06-20 04:00:39 --> Router Class Initialized
DEBUG - 2012-06-20 04:00:39 --> Output Class Initialized
DEBUG - 2012-06-20 04:00:39 --> Security Class Initialized
DEBUG - 2012-06-20 04:00:39 --> Input Class Initialized
DEBUG - 2012-06-20 04:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 04:00:39 --> Language Class Initialized
DEBUG - 2012-06-20 04:00:39 --> Loader Class Initialized
DEBUG - 2012-06-20 04:00:39 --> Helper loaded: date_helper
DEBUG - 2012-06-20 04:00:39 --> Controller Class Initialized
DEBUG - 2012-06-20 04:00:39 --> Database Driver Class Initialized
DEBUG - 2012-06-20 04:00:39 --> Model Class Initialized
DEBUG - 2012-06-20 04:00:39 --> Model Class Initialized
DEBUG - 2012-06-20 04:00:39 --> Pagination Class Initialized
DEBUG - 2012-06-20 04:00:39 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 04:00:39 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 04:00:39 --> Helper loaded: text_helper
DEBUG - 2012-06-20 04:00:39 --> Final output sent to browser
DEBUG - 2012-06-20 04:00:39 --> Total execution time: 0.0399
DEBUG - 2012-06-20 04:01:24 --> Config Class Initialized
DEBUG - 2012-06-20 04:01:24 --> Hooks Class Initialized
DEBUG - 2012-06-20 04:01:24 --> Utf8 Class Initialized
DEBUG - 2012-06-20 04:01:24 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 04:01:24 --> URI Class Initialized
DEBUG - 2012-06-20 04:01:24 --> Router Class Initialized
DEBUG - 2012-06-20 04:01:24 --> Output Class Initialized
DEBUG - 2012-06-20 04:01:24 --> Security Class Initialized
DEBUG - 2012-06-20 04:01:24 --> Input Class Initialized
DEBUG - 2012-06-20 04:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 04:01:24 --> Language Class Initialized
DEBUG - 2012-06-20 04:01:24 --> Loader Class Initialized
DEBUG - 2012-06-20 04:01:24 --> Helper loaded: date_helper
DEBUG - 2012-06-20 04:01:24 --> Controller Class Initialized
DEBUG - 2012-06-20 04:01:24 --> Database Driver Class Initialized
DEBUG - 2012-06-20 04:01:24 --> Model Class Initialized
DEBUG - 2012-06-20 04:01:24 --> Model Class Initialized
DEBUG - 2012-06-20 04:01:24 --> Pagination Class Initialized
DEBUG - 2012-06-20 04:01:24 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 04:01:24 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 04:01:24 --> Helper loaded: text_helper
DEBUG - 2012-06-20 04:01:24 --> Final output sent to browser
DEBUG - 2012-06-20 04:01:24 --> Total execution time: 0.0487
DEBUG - 2012-06-20 04:01:33 --> Config Class Initialized
DEBUG - 2012-06-20 04:01:33 --> Hooks Class Initialized
DEBUG - 2012-06-20 04:01:33 --> Utf8 Class Initialized
DEBUG - 2012-06-20 04:01:33 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 04:01:33 --> URI Class Initialized
DEBUG - 2012-06-20 04:01:33 --> Router Class Initialized
DEBUG - 2012-06-20 04:01:33 --> Output Class Initialized
DEBUG - 2012-06-20 04:01:33 --> Security Class Initialized
DEBUG - 2012-06-20 04:01:33 --> Input Class Initialized
DEBUG - 2012-06-20 04:01:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 04:01:33 --> Language Class Initialized
DEBUG - 2012-06-20 04:01:33 --> Loader Class Initialized
DEBUG - 2012-06-20 04:01:33 --> Helper loaded: date_helper
DEBUG - 2012-06-20 04:01:33 --> Controller Class Initialized
DEBUG - 2012-06-20 04:01:33 --> Database Driver Class Initialized
DEBUG - 2012-06-20 04:01:33 --> Model Class Initialized
DEBUG - 2012-06-20 04:01:33 --> Model Class Initialized
DEBUG - 2012-06-20 04:01:33 --> Pagination Class Initialized
DEBUG - 2012-06-20 04:01:33 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 04:01:33 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 04:01:33 --> Helper loaded: text_helper
DEBUG - 2012-06-20 04:01:33 --> Final output sent to browser
DEBUG - 2012-06-20 04:01:33 --> Total execution time: 0.0327
DEBUG - 2012-06-20 04:01:37 --> Config Class Initialized
DEBUG - 2012-06-20 04:01:37 --> Hooks Class Initialized
DEBUG - 2012-06-20 04:01:37 --> Utf8 Class Initialized
DEBUG - 2012-06-20 04:01:37 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 04:01:37 --> URI Class Initialized
DEBUG - 2012-06-20 04:01:37 --> Router Class Initialized
DEBUG - 2012-06-20 04:01:37 --> Output Class Initialized
DEBUG - 2012-06-20 04:01:37 --> Security Class Initialized
DEBUG - 2012-06-20 04:01:37 --> Input Class Initialized
DEBUG - 2012-06-20 04:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 04:01:37 --> Language Class Initialized
DEBUG - 2012-06-20 04:01:37 --> Loader Class Initialized
DEBUG - 2012-06-20 04:01:37 --> Helper loaded: date_helper
DEBUG - 2012-06-20 04:01:37 --> Controller Class Initialized
DEBUG - 2012-06-20 04:01:37 --> Database Driver Class Initialized
DEBUG - 2012-06-20 04:01:37 --> Model Class Initialized
DEBUG - 2012-06-20 04:01:37 --> Model Class Initialized
DEBUG - 2012-06-20 04:01:37 --> Pagination Class Initialized
DEBUG - 2012-06-20 04:01:37 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 04:01:37 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 04:01:37 --> Helper loaded: text_helper
DEBUG - 2012-06-20 04:01:37 --> Final output sent to browser
DEBUG - 2012-06-20 04:01:37 --> Total execution time: 0.0495
DEBUG - 2012-06-20 04:01:38 --> Config Class Initialized
DEBUG - 2012-06-20 04:01:38 --> Hooks Class Initialized
DEBUG - 2012-06-20 04:01:38 --> Utf8 Class Initialized
DEBUG - 2012-06-20 04:01:38 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 04:01:38 --> URI Class Initialized
DEBUG - 2012-06-20 04:01:38 --> Router Class Initialized
DEBUG - 2012-06-20 04:01:38 --> Output Class Initialized
DEBUG - 2012-06-20 04:01:38 --> Security Class Initialized
DEBUG - 2012-06-20 04:01:38 --> Input Class Initialized
DEBUG - 2012-06-20 04:01:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 04:01:38 --> Language Class Initialized
DEBUG - 2012-06-20 04:01:38 --> Loader Class Initialized
DEBUG - 2012-06-20 04:01:38 --> Helper loaded: date_helper
DEBUG - 2012-06-20 04:01:38 --> Controller Class Initialized
DEBUG - 2012-06-20 04:01:38 --> Database Driver Class Initialized
DEBUG - 2012-06-20 04:01:38 --> Model Class Initialized
DEBUG - 2012-06-20 04:01:38 --> Model Class Initialized
DEBUG - 2012-06-20 04:01:38 --> Pagination Class Initialized
DEBUG - 2012-06-20 04:01:38 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 04:01:38 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 04:01:38 --> Helper loaded: text_helper
DEBUG - 2012-06-20 04:01:38 --> Final output sent to browser
DEBUG - 2012-06-20 04:01:38 --> Total execution time: 0.0506
DEBUG - 2012-06-20 04:01:47 --> Config Class Initialized
DEBUG - 2012-06-20 04:01:47 --> Hooks Class Initialized
DEBUG - 2012-06-20 04:01:47 --> Utf8 Class Initialized
DEBUG - 2012-06-20 04:01:47 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 04:01:47 --> URI Class Initialized
DEBUG - 2012-06-20 04:01:47 --> Router Class Initialized
DEBUG - 2012-06-20 04:01:47 --> Output Class Initialized
DEBUG - 2012-06-20 04:01:47 --> Security Class Initialized
DEBUG - 2012-06-20 04:01:47 --> Input Class Initialized
DEBUG - 2012-06-20 04:01:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 04:01:47 --> Language Class Initialized
DEBUG - 2012-06-20 04:01:47 --> Loader Class Initialized
DEBUG - 2012-06-20 04:01:47 --> Helper loaded: date_helper
DEBUG - 2012-06-20 04:01:47 --> Controller Class Initialized
DEBUG - 2012-06-20 04:01:47 --> Database Driver Class Initialized
DEBUG - 2012-06-20 04:01:47 --> Model Class Initialized
DEBUG - 2012-06-20 04:01:47 --> Model Class Initialized
DEBUG - 2012-06-20 04:01:47 --> Pagination Class Initialized
DEBUG - 2012-06-20 04:01:47 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 04:01:47 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 04:01:47 --> Helper loaded: text_helper
DEBUG - 2012-06-20 04:01:47 --> Final output sent to browser
DEBUG - 2012-06-20 04:01:47 --> Total execution time: 0.0278
DEBUG - 2012-06-20 04:01:55 --> Config Class Initialized
DEBUG - 2012-06-20 04:01:55 --> Hooks Class Initialized
DEBUG - 2012-06-20 04:01:55 --> Utf8 Class Initialized
DEBUG - 2012-06-20 04:01:55 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 04:01:55 --> URI Class Initialized
DEBUG - 2012-06-20 04:01:55 --> Router Class Initialized
DEBUG - 2012-06-20 04:01:55 --> Output Class Initialized
DEBUG - 2012-06-20 04:01:55 --> Security Class Initialized
DEBUG - 2012-06-20 04:01:55 --> Input Class Initialized
DEBUG - 2012-06-20 04:01:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 04:01:55 --> Language Class Initialized
DEBUG - 2012-06-20 04:01:55 --> Loader Class Initialized
DEBUG - 2012-06-20 04:01:55 --> Helper loaded: date_helper
DEBUG - 2012-06-20 04:01:55 --> Controller Class Initialized
DEBUG - 2012-06-20 04:01:55 --> Database Driver Class Initialized
DEBUG - 2012-06-20 04:01:55 --> Model Class Initialized
DEBUG - 2012-06-20 04:01:55 --> Model Class Initialized
DEBUG - 2012-06-20 04:01:55 --> Pagination Class Initialized
DEBUG - 2012-06-20 04:01:55 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 04:01:55 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 04:01:55 --> Helper loaded: text_helper
DEBUG - 2012-06-20 04:01:55 --> Final output sent to browser
DEBUG - 2012-06-20 04:01:55 --> Total execution time: 0.0374
DEBUG - 2012-06-20 04:02:07 --> Config Class Initialized
DEBUG - 2012-06-20 04:02:07 --> Hooks Class Initialized
DEBUG - 2012-06-20 04:02:07 --> Utf8 Class Initialized
DEBUG - 2012-06-20 04:02:07 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 04:02:07 --> URI Class Initialized
DEBUG - 2012-06-20 04:02:07 --> Router Class Initialized
DEBUG - 2012-06-20 04:02:07 --> Output Class Initialized
DEBUG - 2012-06-20 04:02:07 --> Security Class Initialized
DEBUG - 2012-06-20 04:02:07 --> Input Class Initialized
DEBUG - 2012-06-20 04:02:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 04:02:07 --> Language Class Initialized
DEBUG - 2012-06-20 04:02:07 --> Loader Class Initialized
DEBUG - 2012-06-20 04:02:07 --> Helper loaded: date_helper
DEBUG - 2012-06-20 04:02:07 --> Controller Class Initialized
DEBUG - 2012-06-20 04:02:07 --> Database Driver Class Initialized
DEBUG - 2012-06-20 04:02:07 --> Model Class Initialized
DEBUG - 2012-06-20 04:02:07 --> Model Class Initialized
DEBUG - 2012-06-20 04:02:07 --> Pagination Class Initialized
DEBUG - 2012-06-20 04:02:07 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 04:02:07 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 04:02:07 --> Helper loaded: text_helper
DEBUG - 2012-06-20 04:02:07 --> Final output sent to browser
DEBUG - 2012-06-20 04:02:07 --> Total execution time: 0.0457
DEBUG - 2012-06-20 04:02:53 --> Config Class Initialized
DEBUG - 2012-06-20 04:02:53 --> Hooks Class Initialized
DEBUG - 2012-06-20 04:02:53 --> Utf8 Class Initialized
DEBUG - 2012-06-20 04:02:53 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 04:02:53 --> URI Class Initialized
DEBUG - 2012-06-20 04:02:53 --> Router Class Initialized
DEBUG - 2012-06-20 04:02:53 --> Output Class Initialized
DEBUG - 2012-06-20 04:02:53 --> Security Class Initialized
DEBUG - 2012-06-20 04:02:53 --> Input Class Initialized
DEBUG - 2012-06-20 04:02:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 04:02:53 --> Language Class Initialized
DEBUG - 2012-06-20 04:02:53 --> Loader Class Initialized
DEBUG - 2012-06-20 04:02:53 --> Helper loaded: date_helper
DEBUG - 2012-06-20 04:02:53 --> Controller Class Initialized
DEBUG - 2012-06-20 04:02:53 --> Database Driver Class Initialized
DEBUG - 2012-06-20 04:02:53 --> Model Class Initialized
DEBUG - 2012-06-20 04:02:53 --> Model Class Initialized
DEBUG - 2012-06-20 04:02:53 --> Pagination Class Initialized
DEBUG - 2012-06-20 04:02:53 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 04:02:53 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 04:02:53 --> Helper loaded: text_helper
DEBUG - 2012-06-20 04:02:53 --> Final output sent to browser
DEBUG - 2012-06-20 04:02:53 --> Total execution time: 0.0710
DEBUG - 2012-06-20 04:03:03 --> Config Class Initialized
DEBUG - 2012-06-20 04:03:03 --> Hooks Class Initialized
DEBUG - 2012-06-20 04:03:03 --> Utf8 Class Initialized
DEBUG - 2012-06-20 04:03:03 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 04:03:03 --> URI Class Initialized
DEBUG - 2012-06-20 04:03:03 --> Router Class Initialized
DEBUG - 2012-06-20 04:03:03 --> Output Class Initialized
DEBUG - 2012-06-20 04:03:03 --> Security Class Initialized
DEBUG - 2012-06-20 04:03:03 --> Input Class Initialized
DEBUG - 2012-06-20 04:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 04:03:03 --> Language Class Initialized
DEBUG - 2012-06-20 04:03:03 --> Loader Class Initialized
DEBUG - 2012-06-20 04:03:03 --> Helper loaded: date_helper
DEBUG - 2012-06-20 04:03:03 --> Controller Class Initialized
DEBUG - 2012-06-20 04:03:03 --> Database Driver Class Initialized
DEBUG - 2012-06-20 04:03:03 --> Model Class Initialized
DEBUG - 2012-06-20 04:03:03 --> Model Class Initialized
DEBUG - 2012-06-20 04:03:03 --> Pagination Class Initialized
DEBUG - 2012-06-20 04:03:03 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 04:03:03 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 04:03:03 --> Helper loaded: text_helper
DEBUG - 2012-06-20 04:03:03 --> Final output sent to browser
DEBUG - 2012-06-20 04:03:03 --> Total execution time: 0.0526
DEBUG - 2012-06-20 04:04:36 --> Config Class Initialized
DEBUG - 2012-06-20 04:04:36 --> Hooks Class Initialized
DEBUG - 2012-06-20 04:04:36 --> Utf8 Class Initialized
DEBUG - 2012-06-20 04:04:36 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 04:04:36 --> URI Class Initialized
DEBUG - 2012-06-20 04:04:36 --> Router Class Initialized
DEBUG - 2012-06-20 04:04:36 --> Output Class Initialized
DEBUG - 2012-06-20 04:04:36 --> Security Class Initialized
DEBUG - 2012-06-20 04:04:36 --> Input Class Initialized
DEBUG - 2012-06-20 04:04:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 04:04:36 --> Language Class Initialized
DEBUG - 2012-06-20 04:04:36 --> Loader Class Initialized
DEBUG - 2012-06-20 04:04:36 --> Helper loaded: date_helper
DEBUG - 2012-06-20 04:04:36 --> Controller Class Initialized
DEBUG - 2012-06-20 04:04:36 --> Database Driver Class Initialized
DEBUG - 2012-06-20 04:04:36 --> Model Class Initialized
DEBUG - 2012-06-20 04:04:36 --> Model Class Initialized
DEBUG - 2012-06-20 04:04:36 --> Pagination Class Initialized
DEBUG - 2012-06-20 04:04:36 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 04:04:36 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 04:04:36 --> Helper loaded: text_helper
DEBUG - 2012-06-20 04:04:36 --> Final output sent to browser
DEBUG - 2012-06-20 04:04:36 --> Total execution time: 0.0439
DEBUG - 2012-06-20 04:04:42 --> Config Class Initialized
DEBUG - 2012-06-20 04:04:42 --> Hooks Class Initialized
DEBUG - 2012-06-20 04:04:42 --> Utf8 Class Initialized
DEBUG - 2012-06-20 04:04:42 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 04:04:42 --> URI Class Initialized
DEBUG - 2012-06-20 04:04:42 --> Router Class Initialized
DEBUG - 2012-06-20 04:04:42 --> Output Class Initialized
DEBUG - 2012-06-20 04:04:42 --> Security Class Initialized
DEBUG - 2012-06-20 04:04:42 --> Input Class Initialized
DEBUG - 2012-06-20 04:04:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 04:04:42 --> Language Class Initialized
DEBUG - 2012-06-20 04:04:42 --> Loader Class Initialized
DEBUG - 2012-06-20 04:04:42 --> Helper loaded: date_helper
DEBUG - 2012-06-20 04:04:42 --> Controller Class Initialized
DEBUG - 2012-06-20 04:04:42 --> Database Driver Class Initialized
DEBUG - 2012-06-20 04:04:42 --> Model Class Initialized
DEBUG - 2012-06-20 04:04:42 --> Model Class Initialized
DEBUG - 2012-06-20 04:04:42 --> Pagination Class Initialized
DEBUG - 2012-06-20 04:04:42 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 04:04:42 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 04:04:42 --> Helper loaded: text_helper
DEBUG - 2012-06-20 04:04:42 --> Final output sent to browser
DEBUG - 2012-06-20 04:04:42 --> Total execution time: 0.0477
DEBUG - 2012-06-20 04:04:47 --> Config Class Initialized
DEBUG - 2012-06-20 04:04:47 --> Hooks Class Initialized
DEBUG - 2012-06-20 04:04:47 --> Utf8 Class Initialized
DEBUG - 2012-06-20 04:04:47 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 04:04:47 --> URI Class Initialized
DEBUG - 2012-06-20 04:04:47 --> Router Class Initialized
DEBUG - 2012-06-20 04:04:47 --> Output Class Initialized
DEBUG - 2012-06-20 04:04:47 --> Security Class Initialized
DEBUG - 2012-06-20 04:04:47 --> Input Class Initialized
DEBUG - 2012-06-20 04:04:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 04:04:47 --> Language Class Initialized
DEBUG - 2012-06-20 04:04:47 --> Loader Class Initialized
DEBUG - 2012-06-20 04:04:47 --> Helper loaded: date_helper
DEBUG - 2012-06-20 04:04:47 --> Controller Class Initialized
DEBUG - 2012-06-20 04:04:47 --> Database Driver Class Initialized
DEBUG - 2012-06-20 04:04:47 --> Model Class Initialized
DEBUG - 2012-06-20 04:04:47 --> Model Class Initialized
DEBUG - 2012-06-20 04:04:47 --> Pagination Class Initialized
DEBUG - 2012-06-20 04:04:47 --> DB Transaction Failure
ERROR - 2012-06-20 04:04:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-5, 5' at line 1
DEBUG - 2012-06-20 04:04:47 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-06-20 04:05:08 --> Config Class Initialized
DEBUG - 2012-06-20 04:05:08 --> Hooks Class Initialized
DEBUG - 2012-06-20 04:05:08 --> Utf8 Class Initialized
DEBUG - 2012-06-20 04:05:08 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 04:05:08 --> URI Class Initialized
DEBUG - 2012-06-20 04:05:08 --> Router Class Initialized
DEBUG - 2012-06-20 04:05:08 --> Output Class Initialized
DEBUG - 2012-06-20 04:05:08 --> Security Class Initialized
DEBUG - 2012-06-20 04:05:08 --> Input Class Initialized
DEBUG - 2012-06-20 04:05:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 04:05:08 --> Language Class Initialized
DEBUG - 2012-06-20 04:05:08 --> Loader Class Initialized
DEBUG - 2012-06-20 04:05:08 --> Helper loaded: date_helper
DEBUG - 2012-06-20 04:05:08 --> Controller Class Initialized
DEBUG - 2012-06-20 04:05:08 --> Database Driver Class Initialized
DEBUG - 2012-06-20 04:05:08 --> Model Class Initialized
DEBUG - 2012-06-20 04:05:08 --> Model Class Initialized
DEBUG - 2012-06-20 04:05:08 --> Pagination Class Initialized
DEBUG - 2012-06-20 04:05:08 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 04:05:08 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 04:05:08 --> Helper loaded: text_helper
DEBUG - 2012-06-20 04:05:08 --> Final output sent to browser
DEBUG - 2012-06-20 04:05:08 --> Total execution time: 0.0689
DEBUG - 2012-06-20 04:05:11 --> Config Class Initialized
DEBUG - 2012-06-20 04:05:11 --> Hooks Class Initialized
DEBUG - 2012-06-20 04:05:11 --> Utf8 Class Initialized
DEBUG - 2012-06-20 04:05:11 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 04:05:11 --> URI Class Initialized
DEBUG - 2012-06-20 04:05:11 --> Router Class Initialized
DEBUG - 2012-06-20 04:05:11 --> Output Class Initialized
DEBUG - 2012-06-20 04:05:11 --> Security Class Initialized
DEBUG - 2012-06-20 04:05:11 --> Input Class Initialized
DEBUG - 2012-06-20 04:05:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 04:05:11 --> Language Class Initialized
DEBUG - 2012-06-20 04:05:11 --> Loader Class Initialized
DEBUG - 2012-06-20 04:05:11 --> Helper loaded: date_helper
DEBUG - 2012-06-20 04:05:11 --> Controller Class Initialized
DEBUG - 2012-06-20 04:05:11 --> Database Driver Class Initialized
DEBUG - 2012-06-20 04:05:11 --> Model Class Initialized
DEBUG - 2012-06-20 04:05:11 --> Model Class Initialized
DEBUG - 2012-06-20 04:05:11 --> Pagination Class Initialized
DEBUG - 2012-06-20 04:05:11 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 04:05:11 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 04:05:11 --> Helper loaded: text_helper
DEBUG - 2012-06-20 04:05:11 --> Final output sent to browser
DEBUG - 2012-06-20 04:05:11 --> Total execution time: 0.0491
DEBUG - 2012-06-20 04:05:18 --> Config Class Initialized
DEBUG - 2012-06-20 04:05:18 --> Hooks Class Initialized
DEBUG - 2012-06-20 04:05:18 --> Utf8 Class Initialized
DEBUG - 2012-06-20 04:05:18 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 04:05:18 --> URI Class Initialized
DEBUG - 2012-06-20 04:05:18 --> Router Class Initialized
DEBUG - 2012-06-20 04:05:18 --> Output Class Initialized
DEBUG - 2012-06-20 04:05:18 --> Security Class Initialized
DEBUG - 2012-06-20 04:05:18 --> Input Class Initialized
DEBUG - 2012-06-20 04:05:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 04:05:18 --> Language Class Initialized
DEBUG - 2012-06-20 04:05:18 --> Loader Class Initialized
DEBUG - 2012-06-20 04:05:18 --> Helper loaded: date_helper
DEBUG - 2012-06-20 04:05:18 --> Controller Class Initialized
DEBUG - 2012-06-20 04:05:18 --> Database Driver Class Initialized
DEBUG - 2012-06-20 04:05:18 --> Model Class Initialized
DEBUG - 2012-06-20 04:05:18 --> Model Class Initialized
DEBUG - 2012-06-20 04:05:18 --> XSS Filtering completed
DEBUG - 2012-06-20 04:05:18 --> Pagination Class Initialized
DEBUG - 2012-06-20 04:05:18 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 04:05:18 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 04:05:18 --> Helper loaded: text_helper
DEBUG - 2012-06-20 04:05:18 --> Final output sent to browser
DEBUG - 2012-06-20 04:05:18 --> Total execution time: 0.0436
DEBUG - 2012-06-20 04:05:22 --> Config Class Initialized
DEBUG - 2012-06-20 04:05:22 --> Hooks Class Initialized
DEBUG - 2012-06-20 04:05:22 --> Utf8 Class Initialized
DEBUG - 2012-06-20 04:05:22 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 04:05:22 --> URI Class Initialized
DEBUG - 2012-06-20 04:05:22 --> Router Class Initialized
DEBUG - 2012-06-20 04:05:22 --> Output Class Initialized
DEBUG - 2012-06-20 04:05:22 --> Security Class Initialized
DEBUG - 2012-06-20 04:05:22 --> Input Class Initialized
DEBUG - 2012-06-20 04:05:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 04:05:22 --> Language Class Initialized
DEBUG - 2012-06-20 04:05:22 --> Loader Class Initialized
DEBUG - 2012-06-20 04:05:22 --> Helper loaded: date_helper
DEBUG - 2012-06-20 04:05:22 --> Controller Class Initialized
DEBUG - 2012-06-20 04:05:22 --> Database Driver Class Initialized
DEBUG - 2012-06-20 04:05:22 --> Model Class Initialized
DEBUG - 2012-06-20 04:05:22 --> Model Class Initialized
DEBUG - 2012-06-20 04:05:22 --> Pagination Class Initialized
DEBUG - 2012-06-20 04:05:22 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 04:05:22 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 04:05:22 --> Helper loaded: text_helper
DEBUG - 2012-06-20 04:05:22 --> Final output sent to browser
DEBUG - 2012-06-20 04:05:22 --> Total execution time: 0.0483
DEBUG - 2012-06-20 04:05:36 --> Config Class Initialized
DEBUG - 2012-06-20 04:05:36 --> Hooks Class Initialized
DEBUG - 2012-06-20 04:05:36 --> Utf8 Class Initialized
DEBUG - 2012-06-20 04:05:36 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 04:05:36 --> URI Class Initialized
DEBUG - 2012-06-20 04:05:36 --> Router Class Initialized
DEBUG - 2012-06-20 04:05:36 --> Output Class Initialized
DEBUG - 2012-06-20 04:05:36 --> Security Class Initialized
DEBUG - 2012-06-20 04:05:36 --> Input Class Initialized
DEBUG - 2012-06-20 04:05:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 04:05:36 --> Language Class Initialized
DEBUG - 2012-06-20 04:05:36 --> Loader Class Initialized
DEBUG - 2012-06-20 04:05:36 --> Helper loaded: date_helper
DEBUG - 2012-06-20 04:05:36 --> Controller Class Initialized
DEBUG - 2012-06-20 04:05:36 --> Database Driver Class Initialized
DEBUG - 2012-06-20 04:05:36 --> Model Class Initialized
DEBUG - 2012-06-20 04:05:36 --> Model Class Initialized
DEBUG - 2012-06-20 04:05:36 --> XSS Filtering completed
DEBUG - 2012-06-20 04:05:36 --> Pagination Class Initialized
DEBUG - 2012-06-20 04:05:36 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 04:05:36 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 04:05:36 --> Helper loaded: text_helper
DEBUG - 2012-06-20 04:05:36 --> Final output sent to browser
DEBUG - 2012-06-20 04:05:36 --> Total execution time: 0.0457
DEBUG - 2012-06-20 04:05:43 --> Config Class Initialized
DEBUG - 2012-06-20 04:05:43 --> Hooks Class Initialized
DEBUG - 2012-06-20 04:05:43 --> Utf8 Class Initialized
DEBUG - 2012-06-20 04:05:43 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 04:05:43 --> URI Class Initialized
DEBUG - 2012-06-20 04:05:43 --> Router Class Initialized
DEBUG - 2012-06-20 04:05:43 --> Output Class Initialized
DEBUG - 2012-06-20 04:05:43 --> Security Class Initialized
DEBUG - 2012-06-20 04:05:43 --> Input Class Initialized
DEBUG - 2012-06-20 04:05:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 04:05:43 --> Language Class Initialized
DEBUG - 2012-06-20 04:05:43 --> Loader Class Initialized
DEBUG - 2012-06-20 04:05:43 --> Helper loaded: date_helper
DEBUG - 2012-06-20 04:05:43 --> Controller Class Initialized
DEBUG - 2012-06-20 04:05:43 --> Database Driver Class Initialized
DEBUG - 2012-06-20 04:05:43 --> Model Class Initialized
DEBUG - 2012-06-20 04:05:43 --> Model Class Initialized
DEBUG - 2012-06-20 04:05:43 --> Pagination Class Initialized
DEBUG - 2012-06-20 04:05:43 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 04:05:43 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 04:05:43 --> Helper loaded: text_helper
DEBUG - 2012-06-20 04:05:43 --> Final output sent to browser
DEBUG - 2012-06-20 04:05:43 --> Total execution time: 0.0572
DEBUG - 2012-06-20 04:05:45 --> Config Class Initialized
DEBUG - 2012-06-20 04:05:45 --> Hooks Class Initialized
DEBUG - 2012-06-20 04:05:45 --> Utf8 Class Initialized
DEBUG - 2012-06-20 04:05:45 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 04:05:45 --> URI Class Initialized
DEBUG - 2012-06-20 04:05:45 --> Router Class Initialized
DEBUG - 2012-06-20 04:05:45 --> Output Class Initialized
DEBUG - 2012-06-20 04:05:45 --> Security Class Initialized
DEBUG - 2012-06-20 04:05:45 --> Input Class Initialized
DEBUG - 2012-06-20 04:05:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 04:05:45 --> Language Class Initialized
DEBUG - 2012-06-20 04:05:45 --> Loader Class Initialized
DEBUG - 2012-06-20 04:05:45 --> Helper loaded: date_helper
DEBUG - 2012-06-20 04:05:45 --> Controller Class Initialized
DEBUG - 2012-06-20 04:05:45 --> Database Driver Class Initialized
DEBUG - 2012-06-20 04:05:45 --> Model Class Initialized
DEBUG - 2012-06-20 04:05:45 --> Model Class Initialized
DEBUG - 2012-06-20 04:05:45 --> Pagination Class Initialized
DEBUG - 2012-06-20 04:05:45 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 04:05:45 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 04:05:45 --> Helper loaded: text_helper
DEBUG - 2012-06-20 04:05:45 --> Final output sent to browser
DEBUG - 2012-06-20 04:05:45 --> Total execution time: 0.0438
DEBUG - 2012-06-20 04:05:48 --> Config Class Initialized
DEBUG - 2012-06-20 04:05:48 --> Hooks Class Initialized
DEBUG - 2012-06-20 04:05:48 --> Utf8 Class Initialized
DEBUG - 2012-06-20 04:05:48 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 04:05:48 --> URI Class Initialized
DEBUG - 2012-06-20 04:05:48 --> Router Class Initialized
DEBUG - 2012-06-20 04:05:48 --> Output Class Initialized
DEBUG - 2012-06-20 04:05:48 --> Security Class Initialized
DEBUG - 2012-06-20 04:05:48 --> Input Class Initialized
DEBUG - 2012-06-20 04:05:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 04:05:48 --> Language Class Initialized
DEBUG - 2012-06-20 04:05:48 --> Loader Class Initialized
DEBUG - 2012-06-20 04:05:48 --> Helper loaded: date_helper
DEBUG - 2012-06-20 04:05:48 --> Controller Class Initialized
DEBUG - 2012-06-20 04:05:48 --> Database Driver Class Initialized
DEBUG - 2012-06-20 04:05:48 --> Model Class Initialized
DEBUG - 2012-06-20 04:05:48 --> Model Class Initialized
DEBUG - 2012-06-20 04:05:48 --> Pagination Class Initialized
DEBUG - 2012-06-20 04:05:48 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 04:05:48 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 04:05:48 --> Helper loaded: text_helper
DEBUG - 2012-06-20 04:05:48 --> Final output sent to browser
DEBUG - 2012-06-20 04:05:48 --> Total execution time: 0.0434
DEBUG - 2012-06-20 04:05:50 --> Config Class Initialized
DEBUG - 2012-06-20 04:05:50 --> Hooks Class Initialized
DEBUG - 2012-06-20 04:05:50 --> Utf8 Class Initialized
DEBUG - 2012-06-20 04:05:50 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 04:05:50 --> URI Class Initialized
DEBUG - 2012-06-20 04:05:50 --> Router Class Initialized
DEBUG - 2012-06-20 04:05:50 --> Output Class Initialized
DEBUG - 2012-06-20 04:05:50 --> Security Class Initialized
DEBUG - 2012-06-20 04:05:50 --> Input Class Initialized
DEBUG - 2012-06-20 04:05:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 04:05:50 --> Language Class Initialized
DEBUG - 2012-06-20 04:05:50 --> Loader Class Initialized
DEBUG - 2012-06-20 04:05:50 --> Helper loaded: date_helper
DEBUG - 2012-06-20 04:05:50 --> Controller Class Initialized
DEBUG - 2012-06-20 04:05:50 --> Database Driver Class Initialized
DEBUG - 2012-06-20 04:05:50 --> Model Class Initialized
DEBUG - 2012-06-20 04:05:50 --> Model Class Initialized
DEBUG - 2012-06-20 04:05:50 --> Pagination Class Initialized
DEBUG - 2012-06-20 04:05:50 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 04:05:50 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 04:05:50 --> Helper loaded: text_helper
DEBUG - 2012-06-20 04:05:50 --> Final output sent to browser
DEBUG - 2012-06-20 04:05:50 --> Total execution time: 0.0411
DEBUG - 2012-06-20 07:42:20 --> Config Class Initialized
DEBUG - 2012-06-20 07:42:20 --> Hooks Class Initialized
DEBUG - 2012-06-20 07:42:20 --> Utf8 Class Initialized
DEBUG - 2012-06-20 07:42:20 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 07:42:20 --> URI Class Initialized
DEBUG - 2012-06-20 07:42:20 --> Router Class Initialized
DEBUG - 2012-06-20 07:42:20 --> Output Class Initialized
DEBUG - 2012-06-20 07:42:20 --> Security Class Initialized
DEBUG - 2012-06-20 07:42:20 --> Input Class Initialized
DEBUG - 2012-06-20 07:42:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 07:42:20 --> Language Class Initialized
DEBUG - 2012-06-20 07:42:20 --> Loader Class Initialized
DEBUG - 2012-06-20 07:42:20 --> Helper loaded: date_helper
DEBUG - 2012-06-20 07:42:20 --> Controller Class Initialized
DEBUG - 2012-06-20 07:42:20 --> Database Driver Class Initialized
DEBUG - 2012-06-20 07:42:20 --> Model Class Initialized
DEBUG - 2012-06-20 07:42:20 --> Model Class Initialized
DEBUG - 2012-06-20 07:42:20 --> Pagination Class Initialized
DEBUG - 2012-06-20 07:42:20 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 07:42:21 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 07:42:21 --> Helper loaded: text_helper
DEBUG - 2012-06-20 07:42:21 --> Final output sent to browser
DEBUG - 2012-06-20 07:42:21 --> Total execution time: 0.2669
DEBUG - 2012-06-20 07:42:28 --> Config Class Initialized
DEBUG - 2012-06-20 07:42:28 --> Hooks Class Initialized
DEBUG - 2012-06-20 07:42:28 --> Utf8 Class Initialized
DEBUG - 2012-06-20 07:42:28 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 07:42:28 --> URI Class Initialized
DEBUG - 2012-06-20 07:42:28 --> Router Class Initialized
DEBUG - 2012-06-20 07:42:28 --> Output Class Initialized
DEBUG - 2012-06-20 07:42:28 --> Security Class Initialized
DEBUG - 2012-06-20 07:42:28 --> Input Class Initialized
DEBUG - 2012-06-20 07:42:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 07:42:28 --> Language Class Initialized
DEBUG - 2012-06-20 07:42:28 --> Loader Class Initialized
DEBUG - 2012-06-20 07:42:28 --> Helper loaded: date_helper
DEBUG - 2012-06-20 07:42:28 --> Controller Class Initialized
DEBUG - 2012-06-20 07:42:28 --> Database Driver Class Initialized
DEBUG - 2012-06-20 07:42:28 --> Model Class Initialized
DEBUG - 2012-06-20 07:42:28 --> Model Class Initialized
DEBUG - 2012-06-20 07:42:28 --> Pagination Class Initialized
DEBUG - 2012-06-20 07:42:28 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 07:42:28 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 07:42:28 --> Helper loaded: text_helper
DEBUG - 2012-06-20 07:42:28 --> Final output sent to browser
DEBUG - 2012-06-20 07:42:28 --> Total execution time: 0.0480
DEBUG - 2012-06-20 08:01:07 --> Config Class Initialized
DEBUG - 2012-06-20 08:01:07 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:01:07 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:01:07 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:01:07 --> URI Class Initialized
DEBUG - 2012-06-20 08:01:07 --> Router Class Initialized
DEBUG - 2012-06-20 08:01:07 --> Output Class Initialized
DEBUG - 2012-06-20 08:01:07 --> Security Class Initialized
DEBUG - 2012-06-20 08:01:07 --> Input Class Initialized
DEBUG - 2012-06-20 08:01:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:01:07 --> Language Class Initialized
DEBUG - 2012-06-20 08:01:07 --> Loader Class Initialized
DEBUG - 2012-06-20 08:01:07 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:01:07 --> Controller Class Initialized
DEBUG - 2012-06-20 08:01:07 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:01:07 --> Model Class Initialized
DEBUG - 2012-06-20 08:01:07 --> Model Class Initialized
DEBUG - 2012-06-20 08:01:07 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:01:07 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 08:01:07 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 08:01:07 --> Helper loaded: text_helper
DEBUG - 2012-06-20 08:01:07 --> Final output sent to browser
DEBUG - 2012-06-20 08:01:07 --> Total execution time: 0.0385
DEBUG - 2012-06-20 08:01:13 --> Config Class Initialized
DEBUG - 2012-06-20 08:01:13 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:01:13 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:01:13 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:01:13 --> URI Class Initialized
DEBUG - 2012-06-20 08:01:13 --> Router Class Initialized
DEBUG - 2012-06-20 08:01:13 --> Output Class Initialized
DEBUG - 2012-06-20 08:01:13 --> Security Class Initialized
DEBUG - 2012-06-20 08:01:13 --> Input Class Initialized
DEBUG - 2012-06-20 08:01:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:01:13 --> Language Class Initialized
DEBUG - 2012-06-20 08:01:13 --> Loader Class Initialized
DEBUG - 2012-06-20 08:01:13 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:01:13 --> Controller Class Initialized
DEBUG - 2012-06-20 08:01:13 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:01:13 --> Model Class Initialized
DEBUG - 2012-06-20 08:01:13 --> Model Class Initialized
DEBUG - 2012-06-20 08:01:13 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:01:13 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 08:01:13 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 08:01:13 --> Helper loaded: text_helper
DEBUG - 2012-06-20 08:01:13 --> Final output sent to browser
DEBUG - 2012-06-20 08:01:13 --> Total execution time: 0.0521
DEBUG - 2012-06-20 08:02:09 --> Config Class Initialized
DEBUG - 2012-06-20 08:02:09 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:02:09 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:02:09 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:02:09 --> URI Class Initialized
DEBUG - 2012-06-20 08:02:09 --> Router Class Initialized
DEBUG - 2012-06-20 08:02:09 --> Output Class Initialized
DEBUG - 2012-06-20 08:02:09 --> Security Class Initialized
DEBUG - 2012-06-20 08:02:09 --> Input Class Initialized
DEBUG - 2012-06-20 08:02:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:02:09 --> Language Class Initialized
DEBUG - 2012-06-20 08:02:09 --> Loader Class Initialized
DEBUG - 2012-06-20 08:02:09 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:02:09 --> Controller Class Initialized
DEBUG - 2012-06-20 08:02:09 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:02:09 --> Model Class Initialized
DEBUG - 2012-06-20 08:02:09 --> Model Class Initialized
DEBUG - 2012-06-20 08:02:09 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:02:09 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 08:02:09 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 08:02:09 --> Helper loaded: text_helper
DEBUG - 2012-06-20 08:02:09 --> Final output sent to browser
DEBUG - 2012-06-20 08:02:09 --> Total execution time: 0.0478
DEBUG - 2012-06-20 08:02:17 --> Config Class Initialized
DEBUG - 2012-06-20 08:02:17 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:02:17 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:02:17 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:02:17 --> URI Class Initialized
DEBUG - 2012-06-20 08:02:17 --> Router Class Initialized
DEBUG - 2012-06-20 08:02:17 --> Output Class Initialized
DEBUG - 2012-06-20 08:02:17 --> Security Class Initialized
DEBUG - 2012-06-20 08:02:17 --> Input Class Initialized
DEBUG - 2012-06-20 08:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:02:17 --> Language Class Initialized
DEBUG - 2012-06-20 08:02:17 --> Loader Class Initialized
DEBUG - 2012-06-20 08:02:17 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:02:17 --> Controller Class Initialized
DEBUG - 2012-06-20 08:02:17 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:02:17 --> Model Class Initialized
DEBUG - 2012-06-20 08:02:17 --> Model Class Initialized
DEBUG - 2012-06-20 08:03:02 --> Config Class Initialized
DEBUG - 2012-06-20 08:03:02 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:03:02 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:03:02 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:03:02 --> URI Class Initialized
DEBUG - 2012-06-20 08:03:02 --> Router Class Initialized
DEBUG - 2012-06-20 08:03:02 --> Output Class Initialized
DEBUG - 2012-06-20 08:03:02 --> Security Class Initialized
DEBUG - 2012-06-20 08:03:02 --> Input Class Initialized
DEBUG - 2012-06-20 08:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:03:02 --> Language Class Initialized
DEBUG - 2012-06-20 08:03:02 --> Loader Class Initialized
DEBUG - 2012-06-20 08:03:02 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:03:02 --> Controller Class Initialized
DEBUG - 2012-06-20 08:03:02 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:03:02 --> Model Class Initialized
DEBUG - 2012-06-20 08:03:02 --> Model Class Initialized
ERROR - 2012-06-20 08:03:02 --> Severity: Notice  --> Undefined offset: 0 D:\ci_book\svn\trunk\copy\html\application\controllers\board.php 89
ERROR - 2012-06-20 08:03:02 --> Severity: Notice  --> Undefined offset: 2 D:\ci_book\svn\trunk\copy\html\application\controllers\board.php 89
DEBUG - 2012-06-20 08:03:02 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:03:02 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 08:03:02 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 08:03:02 --> Helper loaded: text_helper
DEBUG - 2012-06-20 08:03:02 --> Final output sent to browser
DEBUG - 2012-06-20 08:03:02 --> Total execution time: 0.0883
DEBUG - 2012-06-20 08:03:57 --> Config Class Initialized
DEBUG - 2012-06-20 08:03:57 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:03:57 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:03:57 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:03:57 --> URI Class Initialized
DEBUG - 2012-06-20 08:03:57 --> Router Class Initialized
DEBUG - 2012-06-20 08:03:57 --> Output Class Initialized
DEBUG - 2012-06-20 08:03:57 --> Security Class Initialized
DEBUG - 2012-06-20 08:03:57 --> Input Class Initialized
DEBUG - 2012-06-20 08:03:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:03:57 --> Language Class Initialized
DEBUG - 2012-06-20 08:03:57 --> Loader Class Initialized
DEBUG - 2012-06-20 08:03:57 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:03:57 --> Controller Class Initialized
DEBUG - 2012-06-20 08:03:57 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:03:57 --> Model Class Initialized
DEBUG - 2012-06-20 08:03:57 --> Model Class Initialized
ERROR - 2012-06-20 08:03:57 --> Severity: Notice  --> Undefined offset: 0 D:\ci_book\svn\trunk\copy\html\application\controllers\board.php 89
ERROR - 2012-06-20 08:03:57 --> Severity: Notice  --> Undefined offset: 2 D:\ci_book\svn\trunk\copy\html\application\controllers\board.php 89
DEBUG - 2012-06-20 08:03:57 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:03:57 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 08:03:57 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 08:03:57 --> Helper loaded: text_helper
DEBUG - 2012-06-20 08:03:57 --> Final output sent to browser
DEBUG - 2012-06-20 08:03:57 --> Total execution time: 0.0488
DEBUG - 2012-06-20 08:04:44 --> Config Class Initialized
DEBUG - 2012-06-20 08:04:44 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:04:44 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:04:44 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:04:44 --> URI Class Initialized
DEBUG - 2012-06-20 08:04:44 --> Router Class Initialized
DEBUG - 2012-06-20 08:04:44 --> Output Class Initialized
DEBUG - 2012-06-20 08:04:44 --> Security Class Initialized
DEBUG - 2012-06-20 08:04:44 --> Input Class Initialized
DEBUG - 2012-06-20 08:04:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:04:44 --> Language Class Initialized
DEBUG - 2012-06-20 08:04:44 --> Loader Class Initialized
DEBUG - 2012-06-20 08:04:44 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:04:44 --> Controller Class Initialized
DEBUG - 2012-06-20 08:04:44 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:04:44 --> Model Class Initialized
DEBUG - 2012-06-20 08:04:44 --> Model Class Initialized
ERROR - 2012-06-20 08:04:44 --> Severity: Notice  --> Undefined offset: 0 D:\ci_book\svn\trunk\copy\html\application\controllers\board.php 89
ERROR - 2012-06-20 08:04:44 --> Severity: Notice  --> Undefined offset: 2 D:\ci_book\svn\trunk\copy\html\application\controllers\board.php 89
DEBUG - 2012-06-20 08:04:44 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:04:44 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 08:04:44 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 08:04:44 --> Helper loaded: text_helper
DEBUG - 2012-06-20 08:04:44 --> Final output sent to browser
DEBUG - 2012-06-20 08:04:44 --> Total execution time: 0.0709
DEBUG - 2012-06-20 08:06:25 --> Config Class Initialized
DEBUG - 2012-06-20 08:06:25 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:06:25 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:06:25 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:06:25 --> URI Class Initialized
DEBUG - 2012-06-20 08:06:25 --> Router Class Initialized
DEBUG - 2012-06-20 08:06:25 --> Output Class Initialized
DEBUG - 2012-06-20 08:06:25 --> Security Class Initialized
DEBUG - 2012-06-20 08:06:25 --> Input Class Initialized
DEBUG - 2012-06-20 08:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:06:25 --> Language Class Initialized
DEBUG - 2012-06-20 08:06:25 --> Loader Class Initialized
DEBUG - 2012-06-20 08:06:25 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:06:25 --> Controller Class Initialized
DEBUG - 2012-06-20 08:06:25 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:06:25 --> Model Class Initialized
DEBUG - 2012-06-20 08:06:25 --> Model Class Initialized
DEBUG - 2012-06-20 08:06:25 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:06:25 --> DB Transaction Failure
ERROR - 2012-06-20 08:06:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-5, 5' at line 1
DEBUG - 2012-06-20 08:06:25 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-06-20 08:07:04 --> Config Class Initialized
DEBUG - 2012-06-20 08:07:04 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:07:04 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:07:04 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:07:04 --> URI Class Initialized
DEBUG - 2012-06-20 08:07:04 --> Router Class Initialized
DEBUG - 2012-06-20 08:07:04 --> Output Class Initialized
DEBUG - 2012-06-20 08:07:04 --> Security Class Initialized
DEBUG - 2012-06-20 08:07:04 --> Input Class Initialized
DEBUG - 2012-06-20 08:07:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:07:04 --> Language Class Initialized
DEBUG - 2012-06-20 08:07:04 --> Loader Class Initialized
DEBUG - 2012-06-20 08:07:04 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:07:04 --> Controller Class Initialized
DEBUG - 2012-06-20 08:07:04 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:07:04 --> Model Class Initialized
DEBUG - 2012-06-20 08:07:04 --> Model Class Initialized
DEBUG - 2012-06-20 08:07:04 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:07:04 --> DB Transaction Failure
ERROR - 2012-06-20 08:07:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-5, 5' at line 1
DEBUG - 2012-06-20 08:07:04 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-06-20 08:07:46 --> Config Class Initialized
DEBUG - 2012-06-20 08:07:46 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:07:46 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:07:46 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:07:46 --> URI Class Initialized
DEBUG - 2012-06-20 08:07:46 --> Router Class Initialized
DEBUG - 2012-06-20 08:07:46 --> Output Class Initialized
DEBUG - 2012-06-20 08:07:46 --> Security Class Initialized
DEBUG - 2012-06-20 08:07:46 --> Input Class Initialized
DEBUG - 2012-06-20 08:07:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:07:46 --> Language Class Initialized
DEBUG - 2012-06-20 08:07:46 --> Loader Class Initialized
DEBUG - 2012-06-20 08:07:46 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:07:46 --> Controller Class Initialized
DEBUG - 2012-06-20 08:07:46 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:07:46 --> Model Class Initialized
DEBUG - 2012-06-20 08:07:46 --> Model Class Initialized
DEBUG - 2012-06-20 08:07:46 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:07:46 --> DB Transaction Failure
ERROR - 2012-06-20 08:07:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-5, 5' at line 1
DEBUG - 2012-06-20 08:07:46 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-06-20 08:09:54 --> Config Class Initialized
DEBUG - 2012-06-20 08:09:54 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:09:54 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:09:54 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:09:54 --> URI Class Initialized
DEBUG - 2012-06-20 08:09:54 --> Router Class Initialized
DEBUG - 2012-06-20 08:09:54 --> Output Class Initialized
DEBUG - 2012-06-20 08:09:54 --> Security Class Initialized
DEBUG - 2012-06-20 08:09:54 --> Input Class Initialized
DEBUG - 2012-06-20 08:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:09:54 --> Language Class Initialized
DEBUG - 2012-06-20 08:09:54 --> Loader Class Initialized
DEBUG - 2012-06-20 08:09:54 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:09:54 --> Controller Class Initialized
DEBUG - 2012-06-20 08:09:54 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:09:54 --> Model Class Initialized
DEBUG - 2012-06-20 08:09:54 --> Model Class Initialized
DEBUG - 2012-06-20 08:09:54 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:09:54 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 08:09:54 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 08:09:54 --> Helper loaded: text_helper
DEBUG - 2012-06-20 08:09:54 --> Final output sent to browser
DEBUG - 2012-06-20 08:09:54 --> Total execution time: 0.0601
DEBUG - 2012-06-20 08:10:46 --> Config Class Initialized
DEBUG - 2012-06-20 08:10:46 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:10:46 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:10:46 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:10:46 --> URI Class Initialized
DEBUG - 2012-06-20 08:10:46 --> Router Class Initialized
DEBUG - 2012-06-20 08:10:46 --> Output Class Initialized
DEBUG - 2012-06-20 08:10:46 --> Security Class Initialized
DEBUG - 2012-06-20 08:10:46 --> Input Class Initialized
DEBUG - 2012-06-20 08:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:10:46 --> Language Class Initialized
DEBUG - 2012-06-20 08:10:46 --> Loader Class Initialized
DEBUG - 2012-06-20 08:10:46 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:10:46 --> Controller Class Initialized
DEBUG - 2012-06-20 08:10:46 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:10:46 --> Model Class Initialized
DEBUG - 2012-06-20 08:10:46 --> Model Class Initialized
DEBUG - 2012-06-20 08:10:46 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:10:46 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 08:10:46 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 08:10:46 --> Helper loaded: text_helper
DEBUG - 2012-06-20 08:10:46 --> Final output sent to browser
DEBUG - 2012-06-20 08:10:46 --> Total execution time: 0.0362
DEBUG - 2012-06-20 08:10:52 --> Config Class Initialized
DEBUG - 2012-06-20 08:10:52 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:10:52 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:10:52 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:10:52 --> URI Class Initialized
DEBUG - 2012-06-20 08:10:52 --> Router Class Initialized
DEBUG - 2012-06-20 08:10:52 --> Output Class Initialized
DEBUG - 2012-06-20 08:10:52 --> Security Class Initialized
DEBUG - 2012-06-20 08:10:52 --> Input Class Initialized
DEBUG - 2012-06-20 08:10:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:10:52 --> Language Class Initialized
DEBUG - 2012-06-20 08:10:52 --> Loader Class Initialized
DEBUG - 2012-06-20 08:10:52 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:10:52 --> Controller Class Initialized
DEBUG - 2012-06-20 08:10:52 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:10:52 --> Model Class Initialized
DEBUG - 2012-06-20 08:10:52 --> Model Class Initialized
DEBUG - 2012-06-20 08:10:52 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:10:52 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 08:10:52 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 08:10:52 --> Helper loaded: text_helper
DEBUG - 2012-06-20 08:10:52 --> Final output sent to browser
DEBUG - 2012-06-20 08:10:52 --> Total execution time: 0.0550
DEBUG - 2012-06-20 08:10:57 --> Config Class Initialized
DEBUG - 2012-06-20 08:10:57 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:10:57 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:10:57 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:10:57 --> URI Class Initialized
DEBUG - 2012-06-20 08:10:57 --> Router Class Initialized
DEBUG - 2012-06-20 08:10:57 --> Output Class Initialized
DEBUG - 2012-06-20 08:10:57 --> Security Class Initialized
DEBUG - 2012-06-20 08:10:57 --> Input Class Initialized
DEBUG - 2012-06-20 08:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:10:57 --> Language Class Initialized
DEBUG - 2012-06-20 08:10:57 --> Loader Class Initialized
DEBUG - 2012-06-20 08:10:57 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:10:57 --> Controller Class Initialized
DEBUG - 2012-06-20 08:10:57 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:10:57 --> Model Class Initialized
DEBUG - 2012-06-20 08:10:57 --> Model Class Initialized
DEBUG - 2012-06-20 08:10:57 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:10:57 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 08:10:57 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 08:10:57 --> Helper loaded: text_helper
DEBUG - 2012-06-20 08:10:57 --> Final output sent to browser
DEBUG - 2012-06-20 08:10:57 --> Total execution time: 0.0490
DEBUG - 2012-06-20 08:11:00 --> Config Class Initialized
DEBUG - 2012-06-20 08:11:00 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:11:00 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:11:00 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:11:00 --> URI Class Initialized
DEBUG - 2012-06-20 08:11:00 --> Router Class Initialized
DEBUG - 2012-06-20 08:11:00 --> Output Class Initialized
DEBUG - 2012-06-20 08:11:00 --> Security Class Initialized
DEBUG - 2012-06-20 08:11:00 --> Input Class Initialized
DEBUG - 2012-06-20 08:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:11:00 --> Language Class Initialized
DEBUG - 2012-06-20 08:11:00 --> Loader Class Initialized
DEBUG - 2012-06-20 08:11:00 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:11:00 --> Controller Class Initialized
DEBUG - 2012-06-20 08:11:00 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:11:00 --> Model Class Initialized
DEBUG - 2012-06-20 08:11:00 --> Model Class Initialized
DEBUG - 2012-06-20 08:11:00 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:11:00 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 08:11:00 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 08:11:00 --> Helper loaded: text_helper
DEBUG - 2012-06-20 08:11:00 --> Final output sent to browser
DEBUG - 2012-06-20 08:11:00 --> Total execution time: 0.0342
DEBUG - 2012-06-20 08:11:03 --> Config Class Initialized
DEBUG - 2012-06-20 08:11:03 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:11:03 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:11:03 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:11:03 --> URI Class Initialized
DEBUG - 2012-06-20 08:11:03 --> Router Class Initialized
DEBUG - 2012-06-20 08:11:03 --> Output Class Initialized
DEBUG - 2012-06-20 08:11:03 --> Security Class Initialized
DEBUG - 2012-06-20 08:11:03 --> Input Class Initialized
DEBUG - 2012-06-20 08:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:11:03 --> Language Class Initialized
DEBUG - 2012-06-20 08:11:03 --> Loader Class Initialized
DEBUG - 2012-06-20 08:11:03 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:11:03 --> Controller Class Initialized
DEBUG - 2012-06-20 08:11:03 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:11:03 --> Model Class Initialized
DEBUG - 2012-06-20 08:11:03 --> Model Class Initialized
DEBUG - 2012-06-20 08:11:03 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:11:03 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 08:11:03 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 08:11:03 --> Helper loaded: text_helper
DEBUG - 2012-06-20 08:11:03 --> Final output sent to browser
DEBUG - 2012-06-20 08:11:03 --> Total execution time: 0.0365
DEBUG - 2012-06-20 08:12:13 --> Config Class Initialized
DEBUG - 2012-06-20 08:12:13 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:12:13 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:12:13 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:12:13 --> URI Class Initialized
DEBUG - 2012-06-20 08:12:13 --> Router Class Initialized
DEBUG - 2012-06-20 08:12:13 --> Output Class Initialized
DEBUG - 2012-06-20 08:12:13 --> Security Class Initialized
DEBUG - 2012-06-20 08:12:13 --> Input Class Initialized
DEBUG - 2012-06-20 08:12:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:12:13 --> Language Class Initialized
DEBUG - 2012-06-20 08:12:13 --> Loader Class Initialized
DEBUG - 2012-06-20 08:12:13 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:12:13 --> Controller Class Initialized
DEBUG - 2012-06-20 08:12:13 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:12:13 --> Model Class Initialized
DEBUG - 2012-06-20 08:12:13 --> Model Class Initialized
DEBUG - 2012-06-20 08:12:13 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:12:13 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 08:12:13 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 08:12:13 --> Helper loaded: text_helper
DEBUG - 2012-06-20 08:12:13 --> Final output sent to browser
DEBUG - 2012-06-20 08:12:13 --> Total execution time: 0.0381
DEBUG - 2012-06-20 08:12:17 --> Config Class Initialized
DEBUG - 2012-06-20 08:12:17 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:12:17 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:12:17 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:12:17 --> URI Class Initialized
DEBUG - 2012-06-20 08:12:17 --> Router Class Initialized
DEBUG - 2012-06-20 08:12:17 --> Output Class Initialized
DEBUG - 2012-06-20 08:12:17 --> Security Class Initialized
DEBUG - 2012-06-20 08:12:17 --> Input Class Initialized
DEBUG - 2012-06-20 08:12:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:12:17 --> Language Class Initialized
DEBUG - 2012-06-20 08:12:17 --> Loader Class Initialized
DEBUG - 2012-06-20 08:12:17 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:12:17 --> Controller Class Initialized
DEBUG - 2012-06-20 08:12:17 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:12:17 --> Model Class Initialized
DEBUG - 2012-06-20 08:12:17 --> Model Class Initialized
DEBUG - 2012-06-20 08:12:17 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:12:17 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 08:12:17 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 08:12:17 --> Helper loaded: text_helper
DEBUG - 2012-06-20 08:12:17 --> Final output sent to browser
DEBUG - 2012-06-20 08:12:17 --> Total execution time: 0.0422
DEBUG - 2012-06-20 08:12:23 --> Config Class Initialized
DEBUG - 2012-06-20 08:12:23 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:12:23 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:12:23 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:12:23 --> URI Class Initialized
DEBUG - 2012-06-20 08:12:23 --> Router Class Initialized
DEBUG - 2012-06-20 08:12:23 --> Output Class Initialized
DEBUG - 2012-06-20 08:12:23 --> Security Class Initialized
DEBUG - 2012-06-20 08:12:23 --> Input Class Initialized
DEBUG - 2012-06-20 08:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:12:23 --> Language Class Initialized
DEBUG - 2012-06-20 08:12:23 --> Loader Class Initialized
DEBUG - 2012-06-20 08:12:23 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:12:23 --> Controller Class Initialized
DEBUG - 2012-06-20 08:12:23 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:12:23 --> Model Class Initialized
DEBUG - 2012-06-20 08:12:23 --> Model Class Initialized
DEBUG - 2012-06-20 08:12:23 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:12:23 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 08:12:23 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 08:12:23 --> Helper loaded: text_helper
DEBUG - 2012-06-20 08:12:23 --> Final output sent to browser
DEBUG - 2012-06-20 08:12:23 --> Total execution time: 0.0478
DEBUG - 2012-06-20 08:12:43 --> Config Class Initialized
DEBUG - 2012-06-20 08:12:43 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:12:43 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:12:43 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:12:43 --> URI Class Initialized
DEBUG - 2012-06-20 08:12:43 --> Router Class Initialized
DEBUG - 2012-06-20 08:12:43 --> Output Class Initialized
DEBUG - 2012-06-20 08:12:43 --> Security Class Initialized
DEBUG - 2012-06-20 08:12:43 --> Input Class Initialized
DEBUG - 2012-06-20 08:12:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:12:43 --> Language Class Initialized
DEBUG - 2012-06-20 08:12:43 --> Loader Class Initialized
DEBUG - 2012-06-20 08:12:43 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:12:43 --> Controller Class Initialized
DEBUG - 2012-06-20 08:12:43 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:12:43 --> Model Class Initialized
DEBUG - 2012-06-20 08:12:43 --> Model Class Initialized
DEBUG - 2012-06-20 08:12:43 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:12:43 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 08:12:43 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 08:12:43 --> Helper loaded: text_helper
DEBUG - 2012-06-20 08:12:43 --> Final output sent to browser
DEBUG - 2012-06-20 08:12:43 --> Total execution time: 0.0414
DEBUG - 2012-06-20 08:12:50 --> Config Class Initialized
DEBUG - 2012-06-20 08:12:50 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:12:50 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:12:50 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:12:50 --> URI Class Initialized
DEBUG - 2012-06-20 08:12:50 --> Router Class Initialized
DEBUG - 2012-06-20 08:12:50 --> Output Class Initialized
DEBUG - 2012-06-20 08:12:50 --> Security Class Initialized
DEBUG - 2012-06-20 08:12:50 --> Input Class Initialized
DEBUG - 2012-06-20 08:12:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:12:50 --> Language Class Initialized
DEBUG - 2012-06-20 08:12:50 --> Loader Class Initialized
DEBUG - 2012-06-20 08:12:50 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:12:50 --> Controller Class Initialized
DEBUG - 2012-06-20 08:12:50 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:12:50 --> Model Class Initialized
DEBUG - 2012-06-20 08:12:50 --> Model Class Initialized
DEBUG - 2012-06-20 08:12:50 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:12:50 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 08:12:50 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 08:12:50 --> Helper loaded: text_helper
DEBUG - 2012-06-20 08:12:50 --> Final output sent to browser
DEBUG - 2012-06-20 08:12:50 --> Total execution time: 0.0385
DEBUG - 2012-06-20 08:14:57 --> Config Class Initialized
DEBUG - 2012-06-20 08:14:57 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:14:57 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:14:57 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:14:57 --> URI Class Initialized
DEBUG - 2012-06-20 08:14:57 --> Router Class Initialized
DEBUG - 2012-06-20 08:14:57 --> Output Class Initialized
DEBUG - 2012-06-20 08:14:57 --> Security Class Initialized
DEBUG - 2012-06-20 08:14:57 --> Input Class Initialized
DEBUG - 2012-06-20 08:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:14:57 --> Language Class Initialized
DEBUG - 2012-06-20 08:14:57 --> Loader Class Initialized
DEBUG - 2012-06-20 08:14:57 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:14:57 --> Controller Class Initialized
DEBUG - 2012-06-20 08:14:57 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:14:57 --> Model Class Initialized
DEBUG - 2012-06-20 08:14:57 --> Model Class Initialized
DEBUG - 2012-06-20 08:14:57 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:14:57 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 08:14:57 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 08:14:57 --> Helper loaded: text_helper
DEBUG - 2012-06-20 08:14:57 --> Final output sent to browser
DEBUG - 2012-06-20 08:14:57 --> Total execution time: 0.0390
DEBUG - 2012-06-20 08:15:18 --> Config Class Initialized
DEBUG - 2012-06-20 08:15:18 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:15:18 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:15:18 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:15:18 --> URI Class Initialized
DEBUG - 2012-06-20 08:15:18 --> Router Class Initialized
DEBUG - 2012-06-20 08:15:18 --> Output Class Initialized
DEBUG - 2012-06-20 08:15:18 --> Security Class Initialized
DEBUG - 2012-06-20 08:15:18 --> Input Class Initialized
DEBUG - 2012-06-20 08:15:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:15:18 --> Language Class Initialized
DEBUG - 2012-06-20 08:15:18 --> Loader Class Initialized
DEBUG - 2012-06-20 08:15:18 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:15:18 --> Controller Class Initialized
DEBUG - 2012-06-20 08:15:18 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:15:18 --> Model Class Initialized
DEBUG - 2012-06-20 08:15:18 --> Model Class Initialized
DEBUG - 2012-06-20 08:15:18 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:15:18 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 08:15:18 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 08:15:18 --> Helper loaded: text_helper
DEBUG - 2012-06-20 08:15:18 --> Final output sent to browser
DEBUG - 2012-06-20 08:15:18 --> Total execution time: 0.0486
DEBUG - 2012-06-20 08:15:23 --> Config Class Initialized
DEBUG - 2012-06-20 08:15:23 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:15:23 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:15:23 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:15:23 --> URI Class Initialized
DEBUG - 2012-06-20 08:15:23 --> Router Class Initialized
DEBUG - 2012-06-20 08:15:23 --> Output Class Initialized
DEBUG - 2012-06-20 08:15:23 --> Security Class Initialized
DEBUG - 2012-06-20 08:15:23 --> Input Class Initialized
DEBUG - 2012-06-20 08:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:15:23 --> Language Class Initialized
DEBUG - 2012-06-20 08:15:23 --> Loader Class Initialized
DEBUG - 2012-06-20 08:15:23 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:15:23 --> Controller Class Initialized
DEBUG - 2012-06-20 08:15:23 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:15:23 --> Model Class Initialized
DEBUG - 2012-06-20 08:15:23 --> Model Class Initialized
DEBUG - 2012-06-20 08:15:23 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:15:23 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 08:15:23 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 08:15:23 --> Helper loaded: text_helper
DEBUG - 2012-06-20 08:15:23 --> Final output sent to browser
DEBUG - 2012-06-20 08:15:23 --> Total execution time: 0.0510
DEBUG - 2012-06-20 08:59:36 --> Config Class Initialized
DEBUG - 2012-06-20 08:59:36 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:59:36 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:59:36 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:59:36 --> URI Class Initialized
DEBUG - 2012-06-20 08:59:36 --> Router Class Initialized
DEBUG - 2012-06-20 08:59:36 --> Output Class Initialized
DEBUG - 2012-06-20 08:59:36 --> Security Class Initialized
DEBUG - 2012-06-20 08:59:36 --> Input Class Initialized
DEBUG - 2012-06-20 08:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:59:36 --> Language Class Initialized
DEBUG - 2012-06-20 08:59:36 --> Loader Class Initialized
DEBUG - 2012-06-20 08:59:36 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:59:36 --> Controller Class Initialized
DEBUG - 2012-06-20 08:59:36 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:59:36 --> Model Class Initialized
DEBUG - 2012-06-20 08:59:36 --> Model Class Initialized
DEBUG - 2012-06-20 08:59:36 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:59:36 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 08:59:36 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 08:59:36 --> Helper loaded: text_helper
DEBUG - 2012-06-20 08:59:36 --> Final output sent to browser
DEBUG - 2012-06-20 08:59:36 --> Total execution time: 0.0365
DEBUG - 2012-06-20 08:59:40 --> Config Class Initialized
DEBUG - 2012-06-20 08:59:40 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:59:40 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:59:40 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:59:40 --> URI Class Initialized
DEBUG - 2012-06-20 08:59:40 --> Router Class Initialized
DEBUG - 2012-06-20 08:59:40 --> Output Class Initialized
DEBUG - 2012-06-20 08:59:40 --> Security Class Initialized
DEBUG - 2012-06-20 08:59:40 --> Input Class Initialized
DEBUG - 2012-06-20 08:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:59:40 --> Language Class Initialized
DEBUG - 2012-06-20 08:59:40 --> Loader Class Initialized
DEBUG - 2012-06-20 08:59:40 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:59:40 --> Controller Class Initialized
DEBUG - 2012-06-20 08:59:40 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:59:40 --> Model Class Initialized
DEBUG - 2012-06-20 08:59:40 --> Model Class Initialized
DEBUG - 2012-06-20 08:59:40 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:59:40 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 08:59:40 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 08:59:40 --> Helper loaded: text_helper
DEBUG - 2012-06-20 08:59:40 --> Final output sent to browser
DEBUG - 2012-06-20 08:59:40 --> Total execution time: 0.0517
DEBUG - 2012-06-20 08:59:43 --> Config Class Initialized
DEBUG - 2012-06-20 08:59:43 --> Hooks Class Initialized
DEBUG - 2012-06-20 08:59:43 --> Utf8 Class Initialized
DEBUG - 2012-06-20 08:59:43 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 08:59:43 --> URI Class Initialized
DEBUG - 2012-06-20 08:59:43 --> Router Class Initialized
DEBUG - 2012-06-20 08:59:43 --> Output Class Initialized
DEBUG - 2012-06-20 08:59:43 --> Security Class Initialized
DEBUG - 2012-06-20 08:59:43 --> Input Class Initialized
DEBUG - 2012-06-20 08:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 08:59:43 --> Language Class Initialized
DEBUG - 2012-06-20 08:59:43 --> Loader Class Initialized
DEBUG - 2012-06-20 08:59:43 --> Helper loaded: date_helper
DEBUG - 2012-06-20 08:59:43 --> Controller Class Initialized
DEBUG - 2012-06-20 08:59:43 --> Database Driver Class Initialized
DEBUG - 2012-06-20 08:59:43 --> Model Class Initialized
DEBUG - 2012-06-20 08:59:43 --> Model Class Initialized
DEBUG - 2012-06-20 08:59:43 --> Pagination Class Initialized
DEBUG - 2012-06-20 08:59:43 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 08:59:43 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 08:59:43 --> Helper loaded: text_helper
DEBUG - 2012-06-20 08:59:43 --> Final output sent to browser
DEBUG - 2012-06-20 08:59:43 --> Total execution time: 0.0537
DEBUG - 2012-06-20 16:14:57 --> Config Class Initialized
DEBUG - 2012-06-20 16:14:57 --> Hooks Class Initialized
DEBUG - 2012-06-20 16:14:57 --> Utf8 Class Initialized
DEBUG - 2012-06-20 16:14:57 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 16:14:57 --> URI Class Initialized
DEBUG - 2012-06-20 16:14:57 --> Router Class Initialized
DEBUG - 2012-06-20 16:14:57 --> Output Class Initialized
DEBUG - 2012-06-20 16:14:57 --> Security Class Initialized
DEBUG - 2012-06-20 16:14:57 --> Input Class Initialized
DEBUG - 2012-06-20 16:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 16:14:57 --> Language Class Initialized
DEBUG - 2012-06-20 16:14:57 --> Loader Class Initialized
DEBUG - 2012-06-20 16:14:57 --> Helper loaded: date_helper
DEBUG - 2012-06-20 16:14:57 --> Controller Class Initialized
DEBUG - 2012-06-20 16:14:57 --> Database Driver Class Initialized
DEBUG - 2012-06-20 16:14:57 --> Model Class Initialized
DEBUG - 2012-06-20 16:14:57 --> Model Class Initialized
DEBUG - 2012-06-20 16:14:57 --> Pagination Class Initialized
DEBUG - 2012-06-20 16:14:58 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 16:14:58 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 16:14:58 --> Helper loaded: text_helper
DEBUG - 2012-06-20 16:14:58 --> Final output sent to browser
DEBUG - 2012-06-20 16:14:58 --> Total execution time: 0.1762
DEBUG - 2012-06-20 16:15:45 --> Config Class Initialized
DEBUG - 2012-06-20 16:15:45 --> Hooks Class Initialized
DEBUG - 2012-06-20 16:15:45 --> Utf8 Class Initialized
DEBUG - 2012-06-20 16:15:45 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 16:15:45 --> URI Class Initialized
DEBUG - 2012-06-20 16:15:45 --> Router Class Initialized
DEBUG - 2012-06-20 16:15:45 --> Output Class Initialized
DEBUG - 2012-06-20 16:15:45 --> Security Class Initialized
DEBUG - 2012-06-20 16:15:45 --> Input Class Initialized
DEBUG - 2012-06-20 16:15:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 16:15:45 --> Language Class Initialized
DEBUG - 2012-06-20 16:15:45 --> Loader Class Initialized
DEBUG - 2012-06-20 16:15:45 --> Helper loaded: date_helper
DEBUG - 2012-06-20 16:15:45 --> Controller Class Initialized
DEBUG - 2012-06-20 16:15:45 --> Database Driver Class Initialized
DEBUG - 2012-06-20 16:15:45 --> Model Class Initialized
DEBUG - 2012-06-20 16:15:45 --> Model Class Initialized
DEBUG - 2012-06-20 16:15:45 --> Pagination Class Initialized
DEBUG - 2012-06-20 16:15:45 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 16:15:45 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 16:15:45 --> Helper loaded: text_helper
DEBUG - 2012-06-20 16:15:45 --> Final output sent to browser
DEBUG - 2012-06-20 16:15:45 --> Total execution time: 0.0882
DEBUG - 2012-06-20 16:15:53 --> Config Class Initialized
DEBUG - 2012-06-20 16:15:53 --> Hooks Class Initialized
DEBUG - 2012-06-20 16:15:53 --> Utf8 Class Initialized
DEBUG - 2012-06-20 16:15:53 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 16:15:53 --> URI Class Initialized
DEBUG - 2012-06-20 16:15:53 --> Router Class Initialized
DEBUG - 2012-06-20 16:15:53 --> Output Class Initialized
DEBUG - 2012-06-20 16:15:53 --> Security Class Initialized
DEBUG - 2012-06-20 16:15:53 --> Input Class Initialized
DEBUG - 2012-06-20 16:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 16:15:53 --> Language Class Initialized
DEBUG - 2012-06-20 16:15:53 --> Loader Class Initialized
DEBUG - 2012-06-20 16:15:53 --> Helper loaded: date_helper
DEBUG - 2012-06-20 16:15:53 --> Controller Class Initialized
DEBUG - 2012-06-20 16:15:53 --> Database Driver Class Initialized
DEBUG - 2012-06-20 16:15:53 --> Model Class Initialized
DEBUG - 2012-06-20 16:15:53 --> Model Class Initialized
DEBUG - 2012-06-20 16:15:53 --> Pagination Class Initialized
DEBUG - 2012-06-20 16:15:53 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 16:15:53 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 16:15:53 --> Helper loaded: text_helper
DEBUG - 2012-06-20 16:15:53 --> Final output sent to browser
DEBUG - 2012-06-20 16:15:53 --> Total execution time: 0.0505
DEBUG - 2012-06-20 16:40:52 --> Config Class Initialized
DEBUG - 2012-06-20 16:40:52 --> Hooks Class Initialized
DEBUG - 2012-06-20 16:40:52 --> Utf8 Class Initialized
DEBUG - 2012-06-20 16:40:52 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 16:40:52 --> URI Class Initialized
DEBUG - 2012-06-20 16:40:52 --> Router Class Initialized
DEBUG - 2012-06-20 16:40:52 --> Output Class Initialized
DEBUG - 2012-06-20 16:40:52 --> Security Class Initialized
DEBUG - 2012-06-20 16:40:52 --> Input Class Initialized
DEBUG - 2012-06-20 16:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 16:40:52 --> Language Class Initialized
DEBUG - 2012-06-20 16:40:52 --> Loader Class Initialized
DEBUG - 2012-06-20 16:40:52 --> Helper loaded: date_helper
DEBUG - 2012-06-20 16:40:52 --> Controller Class Initialized
DEBUG - 2012-06-20 16:40:52 --> Database Driver Class Initialized
DEBUG - 2012-06-20 16:40:52 --> Model Class Initialized
DEBUG - 2012-06-20 16:40:52 --> Model Class Initialized
DEBUG - 2012-06-20 16:40:52 --> Pagination Class Initialized
DEBUG - 2012-06-20 16:40:52 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 16:40:52 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 16:40:52 --> Helper loaded: text_helper
DEBUG - 2012-06-20 16:40:52 --> Final output sent to browser
DEBUG - 2012-06-20 16:40:52 --> Total execution time: 0.0351
DEBUG - 2012-06-20 16:41:07 --> Config Class Initialized
DEBUG - 2012-06-20 16:41:07 --> Hooks Class Initialized
DEBUG - 2012-06-20 16:41:07 --> Utf8 Class Initialized
DEBUG - 2012-06-20 16:41:07 --> UTF-8 Support Enabled
DEBUG - 2012-06-20 16:41:07 --> URI Class Initialized
DEBUG - 2012-06-20 16:41:07 --> Router Class Initialized
DEBUG - 2012-06-20 16:41:07 --> Output Class Initialized
DEBUG - 2012-06-20 16:41:07 --> Security Class Initialized
DEBUG - 2012-06-20 16:41:07 --> Input Class Initialized
DEBUG - 2012-06-20 16:41:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-20 16:41:07 --> Language Class Initialized
DEBUG - 2012-06-20 16:41:07 --> Loader Class Initialized
DEBUG - 2012-06-20 16:41:07 --> Helper loaded: date_helper
DEBUG - 2012-06-20 16:41:07 --> Controller Class Initialized
DEBUG - 2012-06-20 16:41:07 --> Database Driver Class Initialized
DEBUG - 2012-06-20 16:41:07 --> Model Class Initialized
DEBUG - 2012-06-20 16:41:07 --> Model Class Initialized
DEBUG - 2012-06-20 16:41:07 --> Pagination Class Initialized
DEBUG - 2012-06-20 16:41:07 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-20 16:41:07 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-20 16:41:07 --> Helper loaded: text_helper
DEBUG - 2012-06-20 16:41:07 --> Final output sent to browser
DEBUG - 2012-06-20 16:41:07 --> Total execution time: 0.0539
