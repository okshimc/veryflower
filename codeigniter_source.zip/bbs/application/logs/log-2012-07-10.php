<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-07-10 04:02:09 --> Config Class Initialized
DEBUG - 2012-07-10 04:02:09 --> Hooks Class Initialized
DEBUG - 2012-07-10 04:02:09 --> Utf8 Class Initialized
DEBUG - 2012-07-10 04:02:09 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 04:02:09 --> URI Class Initialized
DEBUG - 2012-07-10 04:02:09 --> Router Class Initialized
DEBUG - 2012-07-10 04:02:09 --> No URI present. Default controller set.
DEBUG - 2012-07-10 04:02:09 --> Output Class Initialized
DEBUG - 2012-07-10 04:02:09 --> Security Class Initialized
DEBUG - 2012-07-10 04:02:09 --> Input Class Initialized
DEBUG - 2012-07-10 04:02:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 04:02:09 --> Language Class Initialized
DEBUG - 2012-07-10 04:02:09 --> Loader Class Initialized
DEBUG - 2012-07-10 04:02:09 --> Helper loaded: date_helper
DEBUG - 2012-07-10 04:02:09 --> Controller Class Initialized
DEBUG - 2012-07-10 04:02:09 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-07-10 04:02:09 --> Final output sent to browser
DEBUG - 2012-07-10 04:02:09 --> Total execution time: 0.2799
DEBUG - 2012-07-10 04:02:19 --> Config Class Initialized
DEBUG - 2012-07-10 04:02:19 --> Hooks Class Initialized
DEBUG - 2012-07-10 04:02:19 --> Utf8 Class Initialized
DEBUG - 2012-07-10 04:02:19 --> UTF-8 Support Enabled
DEBUG - 2012-07-10 04:02:19 --> URI Class Initialized
DEBUG - 2012-07-10 04:02:19 --> Router Class Initialized
DEBUG - 2012-07-10 04:02:19 --> Output Class Initialized
DEBUG - 2012-07-10 04:02:19 --> Security Class Initialized
DEBUG - 2012-07-10 04:02:19 --> Input Class Initialized
DEBUG - 2012-07-10 04:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-10 04:02:19 --> Language Class Initialized
DEBUG - 2012-07-10 04:02:19 --> Loader Class Initialized
DEBUG - 2012-07-10 04:02:19 --> Helper loaded: date_helper
DEBUG - 2012-07-10 04:02:19 --> Controller Class Initialized
DEBUG - 2012-07-10 04:02:19 --> Database Driver Class Initialized
DEBUG - 2012-07-10 04:02:20 --> Model Class Initialized
DEBUG - 2012-07-10 04:02:20 --> Model Class Initialized
DEBUG - 2012-07-10 04:02:20 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-10 04:02:20 --> Pagination Class Initialized
DEBUG - 2012-07-10 04:02:20 --> DB Transaction Failure
ERROR - 2012-07-10 04:02:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY board_id DESC' at line 1
DEBUG - 2012-07-10 04:02:20 --> Language file loaded: language/english/db_lang.php
