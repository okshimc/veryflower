<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-09-18 18:08:47 --> Config Class Initialized
DEBUG - 2012-09-18 18:08:47 --> Hooks Class Initialized
DEBUG - 2012-09-18 18:08:47 --> Utf8 Class Initialized
DEBUG - 2012-09-18 18:08:47 --> UTF-8 Support Enabled
DEBUG - 2012-09-18 18:08:47 --> URI Class Initialized
DEBUG - 2012-09-18 18:08:47 --> Router Class Initialized
ERROR - 2012-09-18 18:08:47 --> 404 Page Not Found --> tc.js
