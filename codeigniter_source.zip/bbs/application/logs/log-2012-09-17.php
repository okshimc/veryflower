<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-09-17 15:12:40 --> Config Class Initialized
DEBUG - 2012-09-17 15:12:40 --> Hooks Class Initialized
DEBUG - 2012-09-17 15:12:40 --> Utf8 Class Initialized
DEBUG - 2012-09-17 15:12:40 --> UTF-8 Support Enabled
DEBUG - 2012-09-17 15:12:40 --> URI Class Initialized
DEBUG - 2012-09-17 15:12:40 --> Router Class Initialized
ERROR - 2012-09-17 15:12:40 --> 404 Page Not Found --> scrape
DEBUG - 2012-09-17 15:14:29 --> Config Class Initialized
DEBUG - 2012-09-17 15:14:29 --> Hooks Class Initialized
DEBUG - 2012-09-17 15:14:29 --> Utf8 Class Initialized
DEBUG - 2012-09-17 15:14:29 --> UTF-8 Support Enabled
DEBUG - 2012-09-17 15:14:29 --> URI Class Initialized
DEBUG - 2012-09-17 15:14:29 --> Router Class Initialized
ERROR - 2012-09-17 15:14:29 --> 404 Page Not Found --> announce
DEBUG - 2012-09-17 15:44:33 --> Config Class Initialized
DEBUG - 2012-09-17 15:44:33 --> Hooks Class Initialized
DEBUG - 2012-09-17 15:44:33 --> Utf8 Class Initialized
DEBUG - 2012-09-17 15:44:33 --> UTF-8 Support Enabled
DEBUG - 2012-09-17 15:44:33 --> URI Class Initialized
DEBUG - 2012-09-17 15:44:33 --> Router Class Initialized
ERROR - 2012-09-17 15:44:33 --> 404 Page Not Found --> announce
DEBUG - 2012-09-17 16:14:38 --> Config Class Initialized
DEBUG - 2012-09-17 16:14:38 --> Hooks Class Initialized
DEBUG - 2012-09-17 16:14:38 --> Utf8 Class Initialized
DEBUG - 2012-09-17 16:14:38 --> UTF-8 Support Enabled
DEBUG - 2012-09-17 16:14:38 --> URI Class Initialized
DEBUG - 2012-09-17 16:14:38 --> Router Class Initialized
ERROR - 2012-09-17 16:14:38 --> 404 Page Not Found --> announce
