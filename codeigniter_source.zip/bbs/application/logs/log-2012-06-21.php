<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-06-21 02:35:45 --> Config Class Initialized
DEBUG - 2012-06-21 02:35:45 --> Hooks Class Initialized
DEBUG - 2012-06-21 02:35:45 --> Utf8 Class Initialized
DEBUG - 2012-06-21 02:35:45 --> UTF-8 Support Enabled
DEBUG - 2012-06-21 02:35:45 --> URI Class Initialized
DEBUG - 2012-06-21 02:35:45 --> Router Class Initialized
DEBUG - 2012-06-21 02:35:45 --> No URI present. Default controller set.
DEBUG - 2012-06-21 02:35:45 --> Output Class Initialized
DEBUG - 2012-06-21 02:35:45 --> Security Class Initialized
DEBUG - 2012-06-21 02:35:45 --> Input Class Initialized
DEBUG - 2012-06-21 02:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-21 02:35:45 --> Language Class Initialized
DEBUG - 2012-06-21 02:35:45 --> Loader Class Initialized
DEBUG - 2012-06-21 02:35:45 --> Helper loaded: date_helper
DEBUG - 2012-06-21 02:35:45 --> Controller Class Initialized
DEBUG - 2012-06-21 02:35:45 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-06-21 02:35:45 --> Final output sent to browser
DEBUG - 2012-06-21 02:35:45 --> Total execution time: 0.0168
