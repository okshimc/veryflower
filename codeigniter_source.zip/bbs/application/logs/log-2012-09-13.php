<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-09-13 18:32:02 --> Config Class Initialized
DEBUG - 2012-09-13 18:32:02 --> Hooks Class Initialized
DEBUG - 2012-09-13 18:32:02 --> Utf8 Class Initialized
DEBUG - 2012-09-13 18:32:02 --> UTF-8 Support Enabled
DEBUG - 2012-09-13 18:32:03 --> URI Class Initialized
DEBUG - 2012-09-13 18:32:03 --> Router Class Initialized
DEBUG - 2012-09-13 18:32:03 --> No URI present. Default controller set.
DEBUG - 2012-09-13 18:32:03 --> Output Class Initialized
DEBUG - 2012-09-13 18:32:03 --> Security Class Initialized
DEBUG - 2012-09-13 18:32:03 --> Input Class Initialized
DEBUG - 2012-09-13 18:32:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-13 18:32:03 --> Language Class Initialized
DEBUG - 2012-09-13 18:32:03 --> Loader Class Initialized
DEBUG - 2012-09-13 18:32:03 --> Helper loaded: date_helper
DEBUG - 2012-09-13 18:32:03 --> Controller Class Initialized
DEBUG - 2012-09-13 18:32:03 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-09-13 18:32:03 --> Final output sent to browser
DEBUG - 2012-09-13 18:32:03 --> Total execution time: 0.1579
DEBUG - 2012-09-13 18:32:03 --> Config Class Initialized
DEBUG - 2012-09-13 18:32:03 --> Hooks Class Initialized
DEBUG - 2012-09-13 18:32:03 --> Utf8 Class Initialized
DEBUG - 2012-09-13 18:32:03 --> UTF-8 Support Enabled
DEBUG - 2012-09-13 18:32:03 --> URI Class Initialized
DEBUG - 2012-09-13 18:32:03 --> Router Class Initialized
ERROR - 2012-09-13 18:32:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-09-13 18:36:30 --> Config Class Initialized
DEBUG - 2012-09-13 18:36:30 --> Hooks Class Initialized
DEBUG - 2012-09-13 18:36:30 --> Utf8 Class Initialized
DEBUG - 2012-09-13 18:36:30 --> UTF-8 Support Enabled
DEBUG - 2012-09-13 18:36:30 --> URI Class Initialized
DEBUG - 2012-09-13 18:36:30 --> Router Class Initialized
DEBUG - 2012-09-13 18:36:30 --> No URI present. Default controller set.
DEBUG - 2012-09-13 18:36:30 --> Output Class Initialized
DEBUG - 2012-09-13 18:36:30 --> Security Class Initialized
DEBUG - 2012-09-13 18:36:30 --> Input Class Initialized
DEBUG - 2012-09-13 18:36:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-09-13 18:36:30 --> Language Class Initialized
DEBUG - 2012-09-13 18:36:30 --> Loader Class Initialized
DEBUG - 2012-09-13 18:36:31 --> Helper loaded: date_helper
DEBUG - 2012-09-13 18:36:31 --> Controller Class Initialized
DEBUG - 2012-09-13 18:36:31 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-09-13 18:36:31 --> Final output sent to browser
DEBUG - 2012-09-13 18:36:31 --> Total execution time: 0.0468
DEBUG - 2012-09-13 18:36:31 --> Config Class Initialized
DEBUG - 2012-09-13 18:36:31 --> Hooks Class Initialized
DEBUG - 2012-09-13 18:36:31 --> Utf8 Class Initialized
DEBUG - 2012-09-13 18:36:31 --> UTF-8 Support Enabled
DEBUG - 2012-09-13 18:36:31 --> URI Class Initialized
DEBUG - 2012-09-13 18:36:31 --> Router Class Initialized
ERROR - 2012-09-13 18:36:31 --> 404 Page Not Found --> favicon.ico
