<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-09-21 15:26:26 --> Config Class Initialized
DEBUG - 2012-09-21 15:26:26 --> Hooks Class Initialized
DEBUG - 2012-09-21 15:26:26 --> Utf8 Class Initialized
DEBUG - 2012-09-21 15:26:26 --> UTF-8 Support Enabled
DEBUG - 2012-09-21 15:26:26 --> URI Class Initialized
DEBUG - 2012-09-21 15:26:26 --> Router Class Initialized
ERROR - 2012-09-21 15:26:26 --> 404 Page Not Found --> tc.js
DEBUG - 2012-09-21 15:29:05 --> Config Class Initialized
DEBUG - 2012-09-21 15:29:05 --> Hooks Class Initialized
DEBUG - 2012-09-21 15:29:05 --> Utf8 Class Initialized
DEBUG - 2012-09-21 15:29:05 --> UTF-8 Support Enabled
DEBUG - 2012-09-21 15:29:05 --> URI Class Initialized
DEBUG - 2012-09-21 15:29:05 --> Router Class Initialized
ERROR - 2012-09-21 15:29:05 --> 404 Page Not Found --> tc.js
DEBUG - 2012-09-21 15:30:52 --> Config Class Initialized
DEBUG - 2012-09-21 15:30:52 --> Hooks Class Initialized
DEBUG - 2012-09-21 15:30:52 --> Utf8 Class Initialized
DEBUG - 2012-09-21 15:30:52 --> UTF-8 Support Enabled
DEBUG - 2012-09-21 15:30:52 --> URI Class Initialized
DEBUG - 2012-09-21 15:30:52 --> Router Class Initialized
ERROR - 2012-09-21 15:30:52 --> 404 Page Not Found --> tc.js
DEBUG - 2012-09-21 15:31:13 --> Config Class Initialized
DEBUG - 2012-09-21 15:31:13 --> Hooks Class Initialized
DEBUG - 2012-09-21 15:31:13 --> Utf8 Class Initialized
DEBUG - 2012-09-21 15:31:13 --> UTF-8 Support Enabled
DEBUG - 2012-09-21 15:31:13 --> URI Class Initialized
DEBUG - 2012-09-21 15:31:13 --> Router Class Initialized
ERROR - 2012-09-21 15:31:13 --> 404 Page Not Found --> tc.js
DEBUG - 2012-09-21 15:32:21 --> Config Class Initialized
DEBUG - 2012-09-21 15:32:21 --> Hooks Class Initialized
DEBUG - 2012-09-21 15:32:21 --> Utf8 Class Initialized
DEBUG - 2012-09-21 15:32:21 --> UTF-8 Support Enabled
DEBUG - 2012-09-21 15:32:21 --> URI Class Initialized
DEBUG - 2012-09-21 15:32:21 --> Router Class Initialized
ERROR - 2012-09-21 15:32:21 --> 404 Page Not Found --> tc.js
DEBUG - 2012-09-21 15:52:36 --> Config Class Initialized
DEBUG - 2012-09-21 15:52:36 --> Hooks Class Initialized
DEBUG - 2012-09-21 15:52:36 --> Utf8 Class Initialized
DEBUG - 2012-09-21 15:52:36 --> UTF-8 Support Enabled
DEBUG - 2012-09-21 15:52:37 --> URI Class Initialized
DEBUG - 2012-09-21 15:52:37 --> Router Class Initialized
ERROR - 2012-09-21 15:52:37 --> 404 Page Not Found --> tc.js
