<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-06-27 04:21:17 --> Config Class Initialized
DEBUG - 2012-06-27 04:21:17 --> Hooks Class Initialized
DEBUG - 2012-06-27 04:21:17 --> Utf8 Class Initialized
DEBUG - 2012-06-27 04:21:17 --> UTF-8 Support Enabled
DEBUG - 2012-06-27 04:21:17 --> URI Class Initialized
DEBUG - 2012-06-27 04:21:17 --> Router Class Initialized
DEBUG - 2012-06-27 04:21:17 --> Output Class Initialized
DEBUG - 2012-06-27 04:21:18 --> Security Class Initialized
DEBUG - 2012-06-27 04:21:18 --> Input Class Initialized
DEBUG - 2012-06-27 04:21:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-27 04:21:18 --> Language Class Initialized
DEBUG - 2012-06-27 04:21:18 --> Loader Class Initialized
DEBUG - 2012-06-27 04:21:18 --> Helper loaded: date_helper
DEBUG - 2012-06-27 04:21:18 --> Controller Class Initialized
DEBUG - 2012-06-27 04:21:18 --> Database Driver Class Initialized
DEBUG - 2012-06-27 04:21:21 --> Model Class Initialized
DEBUG - 2012-06-27 04:21:21 --> Model Class Initialized
DEBUG - 2012-06-27 04:21:21 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-27 04:21:21 --> Pagination Class Initialized
DEBUG - 2012-06-27 04:21:22 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-27 04:21:22 --> File loaded: application/views/footer_v.php
DEBUG - 2012-06-27 04:21:23 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-27 04:21:23 --> Helper loaded: text_helper
DEBUG - 2012-06-27 04:21:23 --> Final output sent to browser
DEBUG - 2012-06-27 04:21:23 --> Total execution time: 5.9115
