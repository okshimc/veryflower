<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-08-06 09:17:43 --> Config Class Initialized
DEBUG - 2012-08-06 09:17:43 --> Hooks Class Initialized
DEBUG - 2012-08-06 09:17:43 --> Utf8 Class Initialized
DEBUG - 2012-08-06 09:17:43 --> UTF-8 Support Enabled
DEBUG - 2012-08-06 09:17:43 --> URI Class Initialized
DEBUG - 2012-08-06 09:17:43 --> Router Class Initialized
DEBUG - 2012-08-06 09:17:43 --> No URI present. Default controller set.
DEBUG - 2012-08-06 09:17:43 --> Output Class Initialized
DEBUG - 2012-08-06 09:17:43 --> Security Class Initialized
DEBUG - 2012-08-06 09:17:43 --> Input Class Initialized
DEBUG - 2012-08-06 09:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-08-06 09:17:43 --> Language Class Initialized
DEBUG - 2012-08-06 09:17:43 --> Loader Class Initialized
DEBUG - 2012-08-06 09:17:44 --> Helper loaded: date_helper
DEBUG - 2012-08-06 09:17:44 --> Controller Class Initialized
DEBUG - 2012-08-06 09:17:44 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-08-06 09:17:44 --> Final output sent to browser
DEBUG - 2012-08-06 09:17:44 --> Total execution time: 0.6055
DEBUG - 2012-08-06 09:17:44 --> Config Class Initialized
DEBUG - 2012-08-06 09:17:44 --> Hooks Class Initialized
DEBUG - 2012-08-06 09:17:44 --> Utf8 Class Initialized
DEBUG - 2012-08-06 09:17:44 --> UTF-8 Support Enabled
DEBUG - 2012-08-06 09:17:44 --> URI Class Initialized
DEBUG - 2012-08-06 09:17:44 --> Router Class Initialized
ERROR - 2012-08-06 09:17:44 --> 404 Page Not Found --> favicon.ico
