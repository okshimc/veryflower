<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-07-24 07:23:56 --> Config Class Initialized
DEBUG - 2012-07-24 07:23:56 --> Hooks Class Initialized
DEBUG - 2012-07-24 07:23:56 --> Utf8 Class Initialized
DEBUG - 2012-07-24 07:23:56 --> UTF-8 Support Enabled
DEBUG - 2012-07-24 07:23:57 --> URI Class Initialized
DEBUG - 2012-07-24 07:23:57 --> Router Class Initialized
DEBUG - 2012-07-24 07:23:57 --> Output Class Initialized
DEBUG - 2012-07-24 07:23:57 --> Security Class Initialized
DEBUG - 2012-07-24 07:23:57 --> Input Class Initialized
DEBUG - 2012-07-24 07:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-24 07:23:57 --> Language Class Initialized
DEBUG - 2012-07-24 07:23:57 --> Loader Class Initialized
DEBUG - 2012-07-24 07:23:57 --> Helper loaded: date_helper
DEBUG - 2012-07-24 07:23:57 --> Controller Class Initialized
DEBUG - 2012-07-24 07:23:57 --> Database Driver Class Initialized
DEBUG - 2012-07-24 07:23:57 --> Model Class Initialized
DEBUG - 2012-07-24 07:23:57 --> Model Class Initialized
DEBUG - 2012-07-24 07:23:57 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-24 07:23:57 --> Pagination Class Initialized
DEBUG - 2012-07-24 07:23:57 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-24 07:23:57 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-24 07:23:57 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-24 07:23:57 --> Helper loaded: text_helper
DEBUG - 2012-07-24 07:23:57 --> Final output sent to browser
DEBUG - 2012-07-24 07:23:57 --> Total execution time: 0.2399
DEBUG - 2012-07-24 07:23:57 --> Config Class Initialized
DEBUG - 2012-07-24 07:23:57 --> Hooks Class Initialized
DEBUG - 2012-07-24 07:23:57 --> Utf8 Class Initialized
DEBUG - 2012-07-24 07:23:57 --> UTF-8 Support Enabled
DEBUG - 2012-07-24 07:23:57 --> URI Class Initialized
DEBUG - 2012-07-24 07:23:57 --> Router Class Initialized
ERROR - 2012-07-24 07:23:57 --> 404 Page Not Found --> favicon.ico
