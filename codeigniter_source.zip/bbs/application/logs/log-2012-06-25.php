<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-06-25 09:45:20 --> Config Class Initialized
DEBUG - 2012-06-25 09:45:20 --> Hooks Class Initialized
DEBUG - 2012-06-25 09:45:20 --> Utf8 Class Initialized
DEBUG - 2012-06-25 09:45:20 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 09:45:20 --> URI Class Initialized
DEBUG - 2012-06-25 09:45:20 --> Router Class Initialized
DEBUG - 2012-06-25 09:45:20 --> No URI present. Default controller set.
DEBUG - 2012-06-25 09:45:20 --> Output Class Initialized
DEBUG - 2012-06-25 09:45:20 --> Security Class Initialized
DEBUG - 2012-06-25 09:45:20 --> Input Class Initialized
DEBUG - 2012-06-25 09:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 09:45:20 --> Language Class Initialized
DEBUG - 2012-06-25 09:45:20 --> Loader Class Initialized
DEBUG - 2012-06-25 09:45:20 --> Helper loaded: date_helper
DEBUG - 2012-06-25 09:45:20 --> Controller Class Initialized
DEBUG - 2012-06-25 09:45:20 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-06-25 09:45:20 --> Final output sent to browser
DEBUG - 2012-06-25 09:45:20 --> Total execution time: 0.1773
DEBUG - 2012-06-25 09:45:36 --> Config Class Initialized
DEBUG - 2012-06-25 09:45:36 --> Hooks Class Initialized
DEBUG - 2012-06-25 09:45:36 --> Utf8 Class Initialized
DEBUG - 2012-06-25 09:45:36 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 09:45:36 --> URI Class Initialized
DEBUG - 2012-06-25 09:45:36 --> Router Class Initialized
DEBUG - 2012-06-25 09:45:36 --> Output Class Initialized
DEBUG - 2012-06-25 09:45:36 --> Security Class Initialized
DEBUG - 2012-06-25 09:45:36 --> Input Class Initialized
DEBUG - 2012-06-25 09:45:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 09:45:36 --> Language Class Initialized
DEBUG - 2012-06-25 09:45:36 --> Loader Class Initialized
DEBUG - 2012-06-25 09:45:36 --> Helper loaded: date_helper
DEBUG - 2012-06-25 09:45:36 --> Controller Class Initialized
DEBUG - 2012-06-25 09:45:36 --> Database Driver Class Initialized
DEBUG - 2012-06-25 09:45:37 --> Model Class Initialized
DEBUG - 2012-06-25 09:45:37 --> Model Class Initialized
DEBUG - 2012-06-25 09:45:37 --> Pagination Class Initialized
DEBUG - 2012-06-25 09:45:37 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-25 09:45:37 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-25 09:45:37 --> Helper loaded: text_helper
DEBUG - 2012-06-25 09:45:37 --> Final output sent to browser
DEBUG - 2012-06-25 09:45:37 --> Total execution time: 0.6251
DEBUG - 2012-06-25 09:45:56 --> Config Class Initialized
DEBUG - 2012-06-25 09:45:56 --> Hooks Class Initialized
DEBUG - 2012-06-25 09:45:56 --> Utf8 Class Initialized
DEBUG - 2012-06-25 09:45:56 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 09:45:56 --> URI Class Initialized
DEBUG - 2012-06-25 09:45:56 --> Router Class Initialized
DEBUG - 2012-06-25 09:45:56 --> Output Class Initialized
DEBUG - 2012-06-25 09:45:56 --> Security Class Initialized
DEBUG - 2012-06-25 09:45:56 --> Input Class Initialized
DEBUG - 2012-06-25 09:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 09:45:56 --> Language Class Initialized
DEBUG - 2012-06-25 09:45:56 --> Loader Class Initialized
DEBUG - 2012-06-25 09:45:56 --> Helper loaded: date_helper
DEBUG - 2012-06-25 09:45:56 --> Controller Class Initialized
DEBUG - 2012-06-25 09:45:56 --> Database Driver Class Initialized
DEBUG - 2012-06-25 09:45:56 --> Model Class Initialized
DEBUG - 2012-06-25 09:45:56 --> Model Class Initialized
DEBUG - 2012-06-25 09:45:56 --> Pagination Class Initialized
DEBUG - 2012-06-25 09:45:56 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-25 09:45:56 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-25 09:45:56 --> Helper loaded: text_helper
DEBUG - 2012-06-25 09:45:56 --> Final output sent to browser
DEBUG - 2012-06-25 09:45:56 --> Total execution time: 0.0671
DEBUG - 2012-06-25 09:46:41 --> Config Class Initialized
DEBUG - 2012-06-25 09:46:41 --> Hooks Class Initialized
DEBUG - 2012-06-25 09:46:41 --> Utf8 Class Initialized
DEBUG - 2012-06-25 09:46:41 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 09:46:41 --> URI Class Initialized
DEBUG - 2012-06-25 09:46:41 --> Router Class Initialized
DEBUG - 2012-06-25 09:46:41 --> Output Class Initialized
DEBUG - 2012-06-25 09:46:41 --> Security Class Initialized
DEBUG - 2012-06-25 09:46:41 --> Input Class Initialized
DEBUG - 2012-06-25 09:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 09:46:41 --> Language Class Initialized
DEBUG - 2012-06-25 09:46:41 --> Loader Class Initialized
DEBUG - 2012-06-25 09:46:41 --> Helper loaded: date_helper
DEBUG - 2012-06-25 09:46:41 --> Controller Class Initialized
DEBUG - 2012-06-25 09:46:41 --> Database Driver Class Initialized
DEBUG - 2012-06-25 09:46:41 --> Model Class Initialized
DEBUG - 2012-06-25 09:46:41 --> Model Class Initialized
DEBUG - 2012-06-25 09:46:41 --> Pagination Class Initialized
DEBUG - 2012-06-25 09:46:41 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-25 09:46:41 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-25 09:46:41 --> Helper loaded: text_helper
DEBUG - 2012-06-25 09:46:41 --> Final output sent to browser
DEBUG - 2012-06-25 09:46:41 --> Total execution time: 0.0342
DEBUG - 2012-06-25 09:48:58 --> Config Class Initialized
DEBUG - 2012-06-25 09:48:58 --> Hooks Class Initialized
DEBUG - 2012-06-25 09:48:58 --> Utf8 Class Initialized
DEBUG - 2012-06-25 09:48:58 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 09:48:58 --> URI Class Initialized
DEBUG - 2012-06-25 09:48:58 --> Router Class Initialized
DEBUG - 2012-06-25 09:48:58 --> Output Class Initialized
DEBUG - 2012-06-25 09:48:58 --> Security Class Initialized
DEBUG - 2012-06-25 09:48:58 --> Input Class Initialized
DEBUG - 2012-06-25 09:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 09:48:58 --> Language Class Initialized
DEBUG - 2012-06-25 09:48:58 --> Loader Class Initialized
DEBUG - 2012-06-25 09:48:58 --> Helper loaded: date_helper
DEBUG - 2012-06-25 09:48:58 --> Controller Class Initialized
DEBUG - 2012-06-25 09:48:58 --> Database Driver Class Initialized
DEBUG - 2012-06-25 09:48:58 --> Model Class Initialized
DEBUG - 2012-06-25 09:48:58 --> Model Class Initialized
DEBUG - 2012-06-25 09:48:58 --> Pagination Class Initialized
DEBUG - 2012-06-25 09:48:58 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-25 09:48:58 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-25 09:48:58 --> Helper loaded: text_helper
DEBUG - 2012-06-25 09:48:58 --> Final output sent to browser
DEBUG - 2012-06-25 09:48:58 --> Total execution time: 0.0537
DEBUG - 2012-06-25 09:52:04 --> Config Class Initialized
DEBUG - 2012-06-25 09:52:04 --> Hooks Class Initialized
DEBUG - 2012-06-25 09:52:04 --> Utf8 Class Initialized
DEBUG - 2012-06-25 09:52:04 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 09:52:04 --> URI Class Initialized
DEBUG - 2012-06-25 09:52:04 --> Router Class Initialized
DEBUG - 2012-06-25 09:52:04 --> Output Class Initialized
DEBUG - 2012-06-25 09:52:04 --> Security Class Initialized
DEBUG - 2012-06-25 09:52:04 --> Input Class Initialized
DEBUG - 2012-06-25 09:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 09:52:04 --> Language Class Initialized
DEBUG - 2012-06-25 09:52:04 --> Loader Class Initialized
DEBUG - 2012-06-25 09:52:04 --> Helper loaded: date_helper
DEBUG - 2012-06-25 09:52:04 --> Controller Class Initialized
DEBUG - 2012-06-25 09:52:04 --> Database Driver Class Initialized
DEBUG - 2012-06-25 09:52:04 --> Model Class Initialized
DEBUG - 2012-06-25 09:52:04 --> Model Class Initialized
DEBUG - 2012-06-25 09:52:04 --> Pagination Class Initialized
DEBUG - 2012-06-25 09:52:04 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-25 09:52:04 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-25 09:52:04 --> Helper loaded: text_helper
DEBUG - 2012-06-25 09:52:04 --> Final output sent to browser
DEBUG - 2012-06-25 09:52:04 --> Total execution time: 0.0381
DEBUG - 2012-06-25 09:56:26 --> Config Class Initialized
DEBUG - 2012-06-25 09:56:26 --> Hooks Class Initialized
DEBUG - 2012-06-25 09:56:26 --> Utf8 Class Initialized
DEBUG - 2012-06-25 09:56:26 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 09:56:26 --> URI Class Initialized
DEBUG - 2012-06-25 09:56:26 --> Router Class Initialized
DEBUG - 2012-06-25 09:56:26 --> Output Class Initialized
DEBUG - 2012-06-25 09:56:26 --> Security Class Initialized
DEBUG - 2012-06-25 09:56:26 --> Input Class Initialized
DEBUG - 2012-06-25 09:56:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 09:56:26 --> Language Class Initialized
DEBUG - 2012-06-25 09:56:26 --> Loader Class Initialized
DEBUG - 2012-06-25 09:56:26 --> Helper loaded: date_helper
DEBUG - 2012-06-25 09:56:26 --> Controller Class Initialized
DEBUG - 2012-06-25 09:56:26 --> Database Driver Class Initialized
DEBUG - 2012-06-25 09:56:26 --> Model Class Initialized
DEBUG - 2012-06-25 09:56:26 --> Model Class Initialized
DEBUG - 2012-06-25 09:56:26 --> Pagination Class Initialized
DEBUG - 2012-06-25 09:56:26 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-25 09:56:26 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-25 09:56:26 --> Helper loaded: text_helper
DEBUG - 2012-06-25 09:56:26 --> Final output sent to browser
DEBUG - 2012-06-25 09:56:26 --> Total execution time: 0.0393
DEBUG - 2012-06-25 09:57:40 --> Config Class Initialized
DEBUG - 2012-06-25 09:57:40 --> Hooks Class Initialized
DEBUG - 2012-06-25 09:57:40 --> Utf8 Class Initialized
DEBUG - 2012-06-25 09:57:40 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 09:57:40 --> URI Class Initialized
DEBUG - 2012-06-25 09:57:40 --> Router Class Initialized
DEBUG - 2012-06-25 09:57:40 --> Output Class Initialized
DEBUG - 2012-06-25 09:57:40 --> Security Class Initialized
DEBUG - 2012-06-25 09:57:40 --> Input Class Initialized
DEBUG - 2012-06-25 09:57:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 09:57:40 --> Language Class Initialized
DEBUG - 2012-06-25 09:57:40 --> Loader Class Initialized
DEBUG - 2012-06-25 09:57:40 --> Helper loaded: date_helper
DEBUG - 2012-06-25 09:57:40 --> Controller Class Initialized
DEBUG - 2012-06-25 09:57:40 --> Database Driver Class Initialized
DEBUG - 2012-06-25 09:57:40 --> Model Class Initialized
DEBUG - 2012-06-25 09:57:40 --> Model Class Initialized
DEBUG - 2012-06-25 09:57:40 --> Pagination Class Initialized
DEBUG - 2012-06-25 09:57:40 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-25 09:57:40 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-25 09:57:40 --> Helper loaded: text_helper
DEBUG - 2012-06-25 09:57:40 --> Final output sent to browser
DEBUG - 2012-06-25 09:57:40 --> Total execution time: 0.0369
DEBUG - 2012-06-25 09:58:49 --> Config Class Initialized
DEBUG - 2012-06-25 09:58:49 --> Hooks Class Initialized
DEBUG - 2012-06-25 09:58:49 --> Utf8 Class Initialized
DEBUG - 2012-06-25 09:58:49 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 09:58:49 --> URI Class Initialized
DEBUG - 2012-06-25 09:58:49 --> Router Class Initialized
DEBUG - 2012-06-25 09:58:49 --> Output Class Initialized
DEBUG - 2012-06-25 09:58:49 --> Security Class Initialized
DEBUG - 2012-06-25 09:58:49 --> Input Class Initialized
DEBUG - 2012-06-25 09:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 09:58:49 --> Language Class Initialized
DEBUG - 2012-06-25 09:58:49 --> Loader Class Initialized
DEBUG - 2012-06-25 09:58:49 --> Helper loaded: date_helper
DEBUG - 2012-06-25 09:58:49 --> Controller Class Initialized
DEBUG - 2012-06-25 09:58:49 --> Database Driver Class Initialized
DEBUG - 2012-06-25 09:58:49 --> Model Class Initialized
DEBUG - 2012-06-25 09:58:49 --> Model Class Initialized
DEBUG - 2012-06-25 09:58:49 --> Pagination Class Initialized
DEBUG - 2012-06-25 09:58:49 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-25 09:58:49 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-25 09:58:49 --> Helper loaded: text_helper
DEBUG - 2012-06-25 09:58:49 --> Final output sent to browser
DEBUG - 2012-06-25 09:58:49 --> Total execution time: 0.0526
DEBUG - 2012-06-25 09:59:59 --> Config Class Initialized
DEBUG - 2012-06-25 09:59:59 --> Hooks Class Initialized
DEBUG - 2012-06-25 09:59:59 --> Utf8 Class Initialized
DEBUG - 2012-06-25 09:59:59 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 09:59:59 --> URI Class Initialized
DEBUG - 2012-06-25 09:59:59 --> Router Class Initialized
DEBUG - 2012-06-25 09:59:59 --> Output Class Initialized
DEBUG - 2012-06-25 09:59:59 --> Security Class Initialized
DEBUG - 2012-06-25 09:59:59 --> Input Class Initialized
DEBUG - 2012-06-25 09:59:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 09:59:59 --> Language Class Initialized
DEBUG - 2012-06-25 09:59:59 --> Loader Class Initialized
DEBUG - 2012-06-25 09:59:59 --> Helper loaded: date_helper
DEBUG - 2012-06-25 09:59:59 --> Controller Class Initialized
DEBUG - 2012-06-25 09:59:59 --> Database Driver Class Initialized
DEBUG - 2012-06-25 09:59:59 --> Model Class Initialized
DEBUG - 2012-06-25 09:59:59 --> Model Class Initialized
DEBUG - 2012-06-25 09:59:59 --> Pagination Class Initialized
DEBUG - 2012-06-25 09:59:59 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-25 09:59:59 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-25 09:59:59 --> Helper loaded: text_helper
DEBUG - 2012-06-25 09:59:59 --> Final output sent to browser
DEBUG - 2012-06-25 09:59:59 --> Total execution time: 0.0287
DEBUG - 2012-06-25 10:00:17 --> Config Class Initialized
DEBUG - 2012-06-25 10:00:17 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:00:17 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:00:17 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:00:17 --> URI Class Initialized
DEBUG - 2012-06-25 10:00:17 --> Router Class Initialized
DEBUG - 2012-06-25 10:00:17 --> Output Class Initialized
DEBUG - 2012-06-25 10:00:17 --> Security Class Initialized
DEBUG - 2012-06-25 10:00:17 --> Input Class Initialized
DEBUG - 2012-06-25 10:00:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:00:17 --> Language Class Initialized
DEBUG - 2012-06-25 10:00:17 --> Loader Class Initialized
DEBUG - 2012-06-25 10:00:17 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:00:17 --> Controller Class Initialized
DEBUG - 2012-06-25 10:00:17 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:00:17 --> Model Class Initialized
DEBUG - 2012-06-25 10:00:17 --> Model Class Initialized
DEBUG - 2012-06-25 10:00:17 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-25 10:00:17 --> Final output sent to browser
DEBUG - 2012-06-25 10:00:17 --> Total execution time: 0.1309
DEBUG - 2012-06-25 10:01:30 --> Config Class Initialized
DEBUG - 2012-06-25 10:01:30 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:01:30 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:01:30 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:01:30 --> URI Class Initialized
DEBUG - 2012-06-25 10:01:30 --> Router Class Initialized
DEBUG - 2012-06-25 10:01:30 --> Output Class Initialized
DEBUG - 2012-06-25 10:01:30 --> Security Class Initialized
DEBUG - 2012-06-25 10:01:30 --> Input Class Initialized
DEBUG - 2012-06-25 10:01:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:01:30 --> Language Class Initialized
DEBUG - 2012-06-25 10:01:30 --> Loader Class Initialized
DEBUG - 2012-06-25 10:01:30 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:01:30 --> Controller Class Initialized
DEBUG - 2012-06-25 10:01:30 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:01:30 --> Model Class Initialized
DEBUG - 2012-06-25 10:01:30 --> Model Class Initialized
DEBUG - 2012-06-25 10:01:30 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-25 10:01:30 --> Final output sent to browser
DEBUG - 2012-06-25 10:01:30 --> Total execution time: 0.0267
DEBUG - 2012-06-25 10:03:17 --> Config Class Initialized
DEBUG - 2012-06-25 10:03:17 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:03:17 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:03:17 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:03:17 --> URI Class Initialized
DEBUG - 2012-06-25 10:03:17 --> Router Class Initialized
DEBUG - 2012-06-25 10:03:17 --> Output Class Initialized
DEBUG - 2012-06-25 10:03:17 --> Security Class Initialized
DEBUG - 2012-06-25 10:03:17 --> Input Class Initialized
DEBUG - 2012-06-25 10:03:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:03:17 --> Language Class Initialized
DEBUG - 2012-06-25 10:03:17 --> Loader Class Initialized
DEBUG - 2012-06-25 10:03:17 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:03:17 --> Controller Class Initialized
DEBUG - 2012-06-25 10:03:17 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:03:17 --> Model Class Initialized
DEBUG - 2012-06-25 10:03:17 --> Model Class Initialized
DEBUG - 2012-06-25 10:03:17 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-25 10:03:17 --> Final output sent to browser
DEBUG - 2012-06-25 10:03:17 --> Total execution time: 0.0376
DEBUG - 2012-06-25 10:03:26 --> Config Class Initialized
DEBUG - 2012-06-25 10:03:26 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:03:26 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:03:26 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:03:26 --> URI Class Initialized
DEBUG - 2012-06-25 10:03:26 --> Router Class Initialized
DEBUG - 2012-06-25 10:03:26 --> Output Class Initialized
DEBUG - 2012-06-25 10:03:26 --> Security Class Initialized
DEBUG - 2012-06-25 10:03:26 --> Input Class Initialized
DEBUG - 2012-06-25 10:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:03:26 --> Language Class Initialized
DEBUG - 2012-06-25 10:03:26 --> Loader Class Initialized
DEBUG - 2012-06-25 10:03:26 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:03:26 --> Controller Class Initialized
DEBUG - 2012-06-25 10:03:26 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:03:26 --> Model Class Initialized
DEBUG - 2012-06-25 10:03:26 --> Model Class Initialized
DEBUG - 2012-06-25 10:03:26 --> Pagination Class Initialized
DEBUG - 2012-06-25 10:03:26 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-25 10:03:26 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-25 10:03:26 --> Helper loaded: text_helper
DEBUG - 2012-06-25 10:03:26 --> Final output sent to browser
DEBUG - 2012-06-25 10:03:26 --> Total execution time: 0.0521
DEBUG - 2012-06-25 10:03:47 --> Config Class Initialized
DEBUG - 2012-06-25 10:03:47 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:03:47 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:03:47 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:03:47 --> URI Class Initialized
DEBUG - 2012-06-25 10:03:47 --> Router Class Initialized
DEBUG - 2012-06-25 10:03:47 --> Output Class Initialized
DEBUG - 2012-06-25 10:03:47 --> Security Class Initialized
DEBUG - 2012-06-25 10:03:48 --> Input Class Initialized
DEBUG - 2012-06-25 10:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:03:48 --> Language Class Initialized
DEBUG - 2012-06-25 10:03:48 --> Loader Class Initialized
DEBUG - 2012-06-25 10:03:48 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:03:48 --> Controller Class Initialized
DEBUG - 2012-06-25 10:03:48 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:03:48 --> Model Class Initialized
DEBUG - 2012-06-25 10:03:48 --> Model Class Initialized
DEBUG - 2012-06-25 10:03:48 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-25 10:03:48 --> Final output sent to browser
DEBUG - 2012-06-25 10:03:48 --> Total execution time: 0.0449
DEBUG - 2012-06-25 10:03:53 --> Config Class Initialized
DEBUG - 2012-06-25 10:03:53 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:03:53 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:03:53 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:03:53 --> URI Class Initialized
DEBUG - 2012-06-25 10:03:53 --> Router Class Initialized
DEBUG - 2012-06-25 10:03:53 --> Output Class Initialized
DEBUG - 2012-06-25 10:03:53 --> Security Class Initialized
DEBUG - 2012-06-25 10:03:53 --> Input Class Initialized
DEBUG - 2012-06-25 10:03:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:03:53 --> Language Class Initialized
DEBUG - 2012-06-25 10:03:53 --> Loader Class Initialized
DEBUG - 2012-06-25 10:03:53 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:03:53 --> Controller Class Initialized
DEBUG - 2012-06-25 10:03:53 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:03:53 --> Model Class Initialized
DEBUG - 2012-06-25 10:03:53 --> Model Class Initialized
DEBUG - 2012-06-25 10:03:53 --> Pagination Class Initialized
DEBUG - 2012-06-25 10:03:53 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-25 10:03:53 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-25 10:03:53 --> Helper loaded: text_helper
DEBUG - 2012-06-25 10:03:53 --> Final output sent to browser
DEBUG - 2012-06-25 10:03:53 --> Total execution time: 0.0465
DEBUG - 2012-06-25 10:10:02 --> Config Class Initialized
DEBUG - 2012-06-25 10:10:02 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:10:02 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:10:02 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:10:02 --> URI Class Initialized
DEBUG - 2012-06-25 10:10:02 --> Router Class Initialized
DEBUG - 2012-06-25 10:10:02 --> Output Class Initialized
DEBUG - 2012-06-25 10:10:02 --> Security Class Initialized
DEBUG - 2012-06-25 10:10:02 --> Input Class Initialized
DEBUG - 2012-06-25 10:10:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:10:02 --> Language Class Initialized
DEBUG - 2012-06-25 10:10:02 --> Loader Class Initialized
DEBUG - 2012-06-25 10:10:02 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:10:02 --> Controller Class Initialized
DEBUG - 2012-06-25 10:10:02 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:10:02 --> Model Class Initialized
DEBUG - 2012-06-25 10:10:02 --> Model Class Initialized
DEBUG - 2012-06-25 10:10:02 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:10:02 --> Pagination Class Initialized
DEBUG - 2012-06-25 10:10:02 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-25 10:10:02 --> File loaded: application/views/footer_v.php
DEBUG - 2012-06-25 10:10:02 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-25 10:10:02 --> Helper loaded: text_helper
DEBUG - 2012-06-25 10:10:02 --> Final output sent to browser
DEBUG - 2012-06-25 10:10:02 --> Total execution time: 0.0448
DEBUG - 2012-06-25 10:10:05 --> Config Class Initialized
DEBUG - 2012-06-25 10:10:05 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:10:05 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:10:05 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:10:05 --> URI Class Initialized
DEBUG - 2012-06-25 10:10:05 --> Router Class Initialized
DEBUG - 2012-06-25 10:10:05 --> Output Class Initialized
DEBUG - 2012-06-25 10:10:05 --> Security Class Initialized
DEBUG - 2012-06-25 10:10:05 --> Input Class Initialized
DEBUG - 2012-06-25 10:10:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:10:06 --> Language Class Initialized
DEBUG - 2012-06-25 10:10:06 --> Loader Class Initialized
DEBUG - 2012-06-25 10:10:06 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:10:06 --> Controller Class Initialized
DEBUG - 2012-06-25 10:10:06 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:10:06 --> Model Class Initialized
DEBUG - 2012-06-25 10:10:06 --> Model Class Initialized
DEBUG - 2012-06-25 10:10:06 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:10:06 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-06-25 10:10:06 --> File loaded: application/views/footer_v.php
DEBUG - 2012-06-25 10:10:06 --> Final output sent to browser
DEBUG - 2012-06-25 10:10:06 --> Total execution time: 0.0491
DEBUG - 2012-06-25 10:10:09 --> Config Class Initialized
DEBUG - 2012-06-25 10:10:09 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:10:09 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:10:09 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:10:09 --> URI Class Initialized
DEBUG - 2012-06-25 10:10:09 --> Router Class Initialized
DEBUG - 2012-06-25 10:10:09 --> Output Class Initialized
DEBUG - 2012-06-25 10:10:09 --> Security Class Initialized
DEBUG - 2012-06-25 10:10:09 --> Input Class Initialized
DEBUG - 2012-06-25 10:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:10:09 --> Language Class Initialized
DEBUG - 2012-06-25 10:10:09 --> Loader Class Initialized
DEBUG - 2012-06-25 10:10:09 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:10:09 --> Controller Class Initialized
DEBUG - 2012-06-25 10:10:09 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:10:09 --> Model Class Initialized
DEBUG - 2012-06-25 10:10:09 --> Model Class Initialized
DEBUG - 2012-06-25 10:10:09 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:10:09 --> Pagination Class Initialized
DEBUG - 2012-06-25 10:10:09 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-25 10:10:09 --> File loaded: application/views/footer_v.php
DEBUG - 2012-06-25 10:10:09 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-25 10:10:09 --> Helper loaded: text_helper
DEBUG - 2012-06-25 10:10:09 --> Final output sent to browser
DEBUG - 2012-06-25 10:10:09 --> Total execution time: 0.0491
DEBUG - 2012-06-25 10:14:03 --> Config Class Initialized
DEBUG - 2012-06-25 10:14:03 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:14:03 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:14:03 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:14:03 --> URI Class Initialized
DEBUG - 2012-06-25 10:14:03 --> Router Class Initialized
DEBUG - 2012-06-25 10:14:03 --> Output Class Initialized
DEBUG - 2012-06-25 10:14:03 --> Security Class Initialized
DEBUG - 2012-06-25 10:14:03 --> Input Class Initialized
DEBUG - 2012-06-25 10:14:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:14:03 --> Language Class Initialized
DEBUG - 2012-06-25 10:14:03 --> Loader Class Initialized
DEBUG - 2012-06-25 10:14:03 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:14:03 --> Controller Class Initialized
DEBUG - 2012-06-25 10:14:03 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:14:03 --> Model Class Initialized
DEBUG - 2012-06-25 10:14:03 --> Model Class Initialized
DEBUG - 2012-06-25 10:14:03 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:14:03 --> Pagination Class Initialized
DEBUG - 2012-06-25 10:14:03 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-25 10:14:03 --> File loaded: application/views/footer_v.php
DEBUG - 2012-06-25 10:14:03 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-25 10:14:03 --> Helper loaded: text_helper
DEBUG - 2012-06-25 10:14:03 --> Final output sent to browser
DEBUG - 2012-06-25 10:14:03 --> Total execution time: 0.0420
DEBUG - 2012-06-25 10:14:46 --> Config Class Initialized
DEBUG - 2012-06-25 10:14:46 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:14:46 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:14:46 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:14:46 --> URI Class Initialized
DEBUG - 2012-06-25 10:14:46 --> Router Class Initialized
DEBUG - 2012-06-25 10:14:46 --> Output Class Initialized
DEBUG - 2012-06-25 10:14:46 --> Security Class Initialized
DEBUG - 2012-06-25 10:14:46 --> Input Class Initialized
DEBUG - 2012-06-25 10:14:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:14:46 --> Language Class Initialized
DEBUG - 2012-06-25 10:14:46 --> Loader Class Initialized
DEBUG - 2012-06-25 10:14:46 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:14:46 --> Controller Class Initialized
DEBUG - 2012-06-25 10:14:46 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:14:46 --> Model Class Initialized
DEBUG - 2012-06-25 10:14:46 --> Model Class Initialized
DEBUG - 2012-06-25 10:14:46 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:14:46 --> Pagination Class Initialized
DEBUG - 2012-06-25 10:14:46 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-25 10:14:46 --> File loaded: application/views/footer_v.php
DEBUG - 2012-06-25 10:14:46 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-25 10:14:46 --> Helper loaded: text_helper
DEBUG - 2012-06-25 10:14:46 --> Final output sent to browser
DEBUG - 2012-06-25 10:14:46 --> Total execution time: 0.0397
DEBUG - 2012-06-25 10:14:51 --> Config Class Initialized
DEBUG - 2012-06-25 10:14:51 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:14:51 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:14:51 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:14:51 --> URI Class Initialized
DEBUG - 2012-06-25 10:14:51 --> Router Class Initialized
DEBUG - 2012-06-25 10:14:51 --> Output Class Initialized
DEBUG - 2012-06-25 10:14:51 --> Security Class Initialized
DEBUG - 2012-06-25 10:14:51 --> Input Class Initialized
DEBUG - 2012-06-25 10:14:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:14:51 --> Language Class Initialized
DEBUG - 2012-06-25 10:14:51 --> Loader Class Initialized
DEBUG - 2012-06-25 10:14:51 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:14:51 --> Controller Class Initialized
DEBUG - 2012-06-25 10:14:51 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:14:51 --> Model Class Initialized
DEBUG - 2012-06-25 10:14:51 --> Model Class Initialized
DEBUG - 2012-06-25 10:14:51 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:14:51 --> File loaded: application/views/board/write_v.php
DEBUG - 2012-06-25 10:14:51 --> File loaded: application/views/footer_v.php
DEBUG - 2012-06-25 10:14:51 --> Final output sent to browser
DEBUG - 2012-06-25 10:14:51 --> Total execution time: 0.0469
DEBUG - 2012-06-25 10:19:34 --> Config Class Initialized
DEBUG - 2012-06-25 10:19:34 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:19:34 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:19:34 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:19:34 --> URI Class Initialized
DEBUG - 2012-06-25 10:19:34 --> Router Class Initialized
DEBUG - 2012-06-25 10:19:34 --> Output Class Initialized
DEBUG - 2012-06-25 10:19:34 --> Security Class Initialized
DEBUG - 2012-06-25 10:19:34 --> Input Class Initialized
DEBUG - 2012-06-25 10:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:19:34 --> Language Class Initialized
DEBUG - 2012-06-25 10:19:34 --> Loader Class Initialized
DEBUG - 2012-06-25 10:19:34 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:19:34 --> Controller Class Initialized
DEBUG - 2012-06-25 10:19:34 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:19:34 --> Model Class Initialized
DEBUG - 2012-06-25 10:19:34 --> Model Class Initialized
DEBUG - 2012-06-25 10:19:34 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:19:34 --> File loaded: application/views/board/write_v.php
DEBUG - 2012-06-25 10:19:34 --> File loaded: application/views/footer_v.php
DEBUG - 2012-06-25 10:19:34 --> Final output sent to browser
DEBUG - 2012-06-25 10:19:34 --> Total execution time: 0.0478
DEBUG - 2012-06-25 10:20:22 --> Config Class Initialized
DEBUG - 2012-06-25 10:20:22 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:20:22 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:20:22 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:20:22 --> URI Class Initialized
DEBUG - 2012-06-25 10:20:22 --> Router Class Initialized
DEBUG - 2012-06-25 10:20:22 --> Output Class Initialized
DEBUG - 2012-06-25 10:20:22 --> Security Class Initialized
DEBUG - 2012-06-25 10:20:22 --> Input Class Initialized
DEBUG - 2012-06-25 10:20:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:20:22 --> Language Class Initialized
DEBUG - 2012-06-25 10:20:22 --> Loader Class Initialized
DEBUG - 2012-06-25 10:20:22 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:20:22 --> Controller Class Initialized
DEBUG - 2012-06-25 10:20:22 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:20:22 --> Model Class Initialized
DEBUG - 2012-06-25 10:20:22 --> Model Class Initialized
DEBUG - 2012-06-25 10:20:22 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:20:22 --> File loaded: application/views/board/write_v.php
DEBUG - 2012-06-25 10:20:22 --> File loaded: application/views/footer_v.php
DEBUG - 2012-06-25 10:20:22 --> Final output sent to browser
DEBUG - 2012-06-25 10:20:22 --> Total execution time: 0.0477
DEBUG - 2012-06-25 10:20:43 --> Config Class Initialized
DEBUG - 2012-06-25 10:20:43 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:20:43 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:20:43 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:20:43 --> URI Class Initialized
DEBUG - 2012-06-25 10:20:43 --> Router Class Initialized
DEBUG - 2012-06-25 10:20:43 --> Output Class Initialized
DEBUG - 2012-06-25 10:20:43 --> Security Class Initialized
DEBUG - 2012-06-25 10:20:43 --> Input Class Initialized
DEBUG - 2012-06-25 10:20:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:20:44 --> Language Class Initialized
DEBUG - 2012-06-25 10:20:44 --> Loader Class Initialized
DEBUG - 2012-06-25 10:20:44 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:20:44 --> Controller Class Initialized
DEBUG - 2012-06-25 10:20:44 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:20:44 --> Model Class Initialized
DEBUG - 2012-06-25 10:20:44 --> Model Class Initialized
DEBUG - 2012-06-25 10:20:44 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:20:44 --> File loaded: application/views/board/write_v.php
DEBUG - 2012-06-25 10:20:44 --> File loaded: application/views/footer_v.php
DEBUG - 2012-06-25 10:20:44 --> Final output sent to browser
DEBUG - 2012-06-25 10:20:44 --> Total execution time: 0.0470
DEBUG - 2012-06-25 10:24:21 --> Config Class Initialized
DEBUG - 2012-06-25 10:24:21 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:24:21 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:24:21 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:24:21 --> URI Class Initialized
DEBUG - 2012-06-25 10:24:21 --> Router Class Initialized
DEBUG - 2012-06-25 10:24:21 --> Output Class Initialized
DEBUG - 2012-06-25 10:24:21 --> Security Class Initialized
DEBUG - 2012-06-25 10:24:21 --> Input Class Initialized
DEBUG - 2012-06-25 10:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:24:21 --> Language Class Initialized
DEBUG - 2012-06-25 10:24:21 --> Loader Class Initialized
DEBUG - 2012-06-25 10:24:21 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:24:21 --> Controller Class Initialized
DEBUG - 2012-06-25 10:24:21 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:24:21 --> Model Class Initialized
DEBUG - 2012-06-25 10:24:21 --> Model Class Initialized
DEBUG - 2012-06-25 10:24:21 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:24:21 --> File loaded: application/views/board/write_v.php
DEBUG - 2012-06-25 10:24:21 --> File loaded: application/views/footer_v.php
DEBUG - 2012-06-25 10:24:21 --> Final output sent to browser
DEBUG - 2012-06-25 10:24:21 --> Total execution time: 0.0505
DEBUG - 2012-06-25 10:28:48 --> Config Class Initialized
DEBUG - 2012-06-25 10:28:48 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:28:48 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:28:48 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:28:48 --> URI Class Initialized
DEBUG - 2012-06-25 10:28:48 --> Router Class Initialized
DEBUG - 2012-06-25 10:28:48 --> Output Class Initialized
DEBUG - 2012-06-25 10:28:48 --> Security Class Initialized
DEBUG - 2012-06-25 10:28:49 --> Input Class Initialized
DEBUG - 2012-06-25 10:28:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:28:49 --> Language Class Initialized
DEBUG - 2012-06-25 10:28:49 --> Loader Class Initialized
DEBUG - 2012-06-25 10:28:49 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:28:49 --> Controller Class Initialized
DEBUG - 2012-06-25 10:28:49 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:28:49 --> Model Class Initialized
DEBUG - 2012-06-25 10:28:49 --> Model Class Initialized
DEBUG - 2012-06-25 10:28:49 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:28:49 --> File loaded: application/views/board/write_v.php
DEBUG - 2012-06-25 10:28:49 --> File loaded: application/views/footer_v.php
DEBUG - 2012-06-25 10:28:49 --> Final output sent to browser
DEBUG - 2012-06-25 10:28:49 --> Total execution time: 0.0525
DEBUG - 2012-06-25 10:29:38 --> Config Class Initialized
DEBUG - 2012-06-25 10:29:38 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:29:38 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:29:38 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:29:38 --> URI Class Initialized
DEBUG - 2012-06-25 10:29:38 --> Router Class Initialized
DEBUG - 2012-06-25 10:29:38 --> Output Class Initialized
DEBUG - 2012-06-25 10:29:38 --> Security Class Initialized
DEBUG - 2012-06-25 10:29:38 --> Input Class Initialized
DEBUG - 2012-06-25 10:29:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:29:38 --> Language Class Initialized
DEBUG - 2012-06-25 10:29:38 --> Loader Class Initialized
DEBUG - 2012-06-25 10:29:38 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:29:38 --> Controller Class Initialized
DEBUG - 2012-06-25 10:29:38 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:29:38 --> Model Class Initialized
DEBUG - 2012-06-25 10:29:38 --> Model Class Initialized
DEBUG - 2012-06-25 10:29:38 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:29:38 --> File loaded: application/views/board/write_v.php
DEBUG - 2012-06-25 10:29:38 --> File loaded: application/views/footer_v.php
DEBUG - 2012-06-25 10:29:38 --> Final output sent to browser
DEBUG - 2012-06-25 10:29:38 --> Total execution time: 0.0258
DEBUG - 2012-06-25 10:30:08 --> Config Class Initialized
DEBUG - 2012-06-25 10:30:08 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:30:08 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:30:08 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:30:08 --> URI Class Initialized
DEBUG - 2012-06-25 10:30:08 --> Router Class Initialized
DEBUG - 2012-06-25 10:30:08 --> Output Class Initialized
DEBUG - 2012-06-25 10:30:08 --> Security Class Initialized
DEBUG - 2012-06-25 10:30:08 --> Input Class Initialized
DEBUG - 2012-06-25 10:30:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:30:08 --> Language Class Initialized
DEBUG - 2012-06-25 10:30:08 --> Loader Class Initialized
DEBUG - 2012-06-25 10:30:08 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:30:08 --> Controller Class Initialized
DEBUG - 2012-06-25 10:30:08 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:30:08 --> Model Class Initialized
DEBUG - 2012-06-25 10:30:08 --> Model Class Initialized
DEBUG - 2012-06-25 10:30:08 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:30:08 --> File loaded: application/views/footer_v.php
DEBUG - 2012-06-25 10:30:08 --> Final output sent to browser
DEBUG - 2012-06-25 10:30:08 --> Total execution time: 0.1289
DEBUG - 2012-06-25 10:30:58 --> Config Class Initialized
DEBUG - 2012-06-25 10:30:58 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:30:58 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:30:58 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:30:58 --> URI Class Initialized
DEBUG - 2012-06-25 10:30:58 --> Router Class Initialized
DEBUG - 2012-06-25 10:30:58 --> Output Class Initialized
DEBUG - 2012-06-25 10:30:58 --> Security Class Initialized
DEBUG - 2012-06-25 10:30:58 --> Input Class Initialized
DEBUG - 2012-06-25 10:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:30:58 --> Language Class Initialized
DEBUG - 2012-06-25 10:30:58 --> Loader Class Initialized
DEBUG - 2012-06-25 10:30:58 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:30:58 --> Controller Class Initialized
DEBUG - 2012-06-25 10:30:58 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:30:58 --> Model Class Initialized
DEBUG - 2012-06-25 10:30:58 --> Model Class Initialized
DEBUG - 2012-06-25 10:30:58 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:31:45 --> Config Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:31:45 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:31:45 --> URI Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Router Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Output Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Security Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Input Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:31:45 --> Language Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Loader Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:31:45 --> Controller Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Model Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Model Class Initialized
DEBUG - 2012-06-25 10:31:45 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:31:45 --> Helper loaded: alert_helper
DEBUG - 2012-06-25 10:31:45 --> Config Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:31:45 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:31:45 --> URI Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Router Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Output Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Security Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Input Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:31:45 --> Language Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Loader Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:31:45 --> Controller Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Model Class Initialized
DEBUG - 2012-06-25 10:31:45 --> Model Class Initialized
DEBUG - 2012-06-25 10:31:45 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:31:45 --> Pagination Class Initialized
DEBUG - 2012-06-25 10:31:45 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-25 10:31:45 --> File loaded: application/views/footer_v.php
DEBUG - 2012-06-25 10:31:45 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-25 10:31:45 --> Helper loaded: text_helper
DEBUG - 2012-06-25 10:31:45 --> Final output sent to browser
DEBUG - 2012-06-25 10:31:45 --> Total execution time: 0.0399
DEBUG - 2012-06-25 10:32:02 --> Config Class Initialized
DEBUG - 2012-06-25 10:32:02 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:32:02 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:32:02 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:32:02 --> URI Class Initialized
DEBUG - 2012-06-25 10:32:02 --> Router Class Initialized
DEBUG - 2012-06-25 10:32:02 --> Output Class Initialized
DEBUG - 2012-06-25 10:32:02 --> Security Class Initialized
DEBUG - 2012-06-25 10:32:02 --> Input Class Initialized
DEBUG - 2012-06-25 10:32:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:32:02 --> Language Class Initialized
DEBUG - 2012-06-25 10:32:02 --> Loader Class Initialized
DEBUG - 2012-06-25 10:32:02 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:32:02 --> Controller Class Initialized
DEBUG - 2012-06-25 10:32:02 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:32:02 --> Model Class Initialized
DEBUG - 2012-06-25 10:32:02 --> Model Class Initialized
DEBUG - 2012-06-25 10:32:02 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:32:02 --> File loaded: application/views/board/write_v.php
DEBUG - 2012-06-25 10:32:02 --> File loaded: application/views/footer_v.php
DEBUG - 2012-06-25 10:32:02 --> Final output sent to browser
DEBUG - 2012-06-25 10:32:02 --> Total execution time: 0.0728
DEBUG - 2012-06-25 10:32:05 --> Config Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Config Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:32:05 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:32:05 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:32:05 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:32:05 --> URI Class Initialized
DEBUG - 2012-06-25 10:32:05 --> URI Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Router Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Router Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Output Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Output Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Security Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Security Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Input Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:32:05 --> Input Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:32:05 --> Language Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Language Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Loader Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Loader Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:32:05 --> Controller Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:32:05 --> Controller Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Model Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Model Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Model Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Model Class Initialized
DEBUG - 2012-06-25 10:32:05 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:32:05 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:32:05 --> Helper loaded: alert_helper
DEBUG - 2012-06-25 10:32:05 --> Helper loaded: alert_helper
DEBUG - 2012-06-25 10:32:05 --> Config Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:32:05 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:32:05 --> URI Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Router Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Output Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Security Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Input Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:32:05 --> Language Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Loader Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:32:05 --> Controller Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Model Class Initialized
DEBUG - 2012-06-25 10:32:05 --> Model Class Initialized
DEBUG - 2012-06-25 10:32:05 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:32:05 --> Pagination Class Initialized
DEBUG - 2012-06-25 10:32:05 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-25 10:32:05 --> File loaded: application/views/footer_v.php
DEBUG - 2012-06-25 10:32:05 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-25 10:32:05 --> Helper loaded: text_helper
DEBUG - 2012-06-25 10:32:05 --> Final output sent to browser
DEBUG - 2012-06-25 10:32:05 --> Total execution time: 0.0392
DEBUG - 2012-06-25 10:33:03 --> Config Class Initialized
DEBUG - 2012-06-25 10:33:03 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:33:03 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:33:03 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:33:03 --> URI Class Initialized
DEBUG - 2012-06-25 10:33:03 --> Router Class Initialized
DEBUG - 2012-06-25 10:33:03 --> Output Class Initialized
DEBUG - 2012-06-25 10:33:03 --> Security Class Initialized
DEBUG - 2012-06-25 10:33:03 --> Input Class Initialized
DEBUG - 2012-06-25 10:33:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:33:03 --> Language Class Initialized
DEBUG - 2012-06-25 10:33:03 --> Loader Class Initialized
DEBUG - 2012-06-25 10:33:03 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:33:03 --> Controller Class Initialized
DEBUG - 2012-06-25 10:33:03 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:33:03 --> Model Class Initialized
DEBUG - 2012-06-25 10:33:03 --> Model Class Initialized
DEBUG - 2012-06-25 10:33:03 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:33:03 --> Pagination Class Initialized
DEBUG - 2012-06-25 10:33:03 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-25 10:33:03 --> File loaded: application/views/footer_v.php
DEBUG - 2012-06-25 10:33:03 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-25 10:33:03 --> Helper loaded: text_helper
DEBUG - 2012-06-25 10:33:03 --> Final output sent to browser
DEBUG - 2012-06-25 10:33:03 --> Total execution time: 0.0481
DEBUG - 2012-06-25 10:33:04 --> Config Class Initialized
DEBUG - 2012-06-25 10:33:04 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:33:04 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:33:04 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:33:04 --> URI Class Initialized
DEBUG - 2012-06-25 10:33:04 --> Router Class Initialized
DEBUG - 2012-06-25 10:33:04 --> Output Class Initialized
DEBUG - 2012-06-25 10:33:04 --> Security Class Initialized
DEBUG - 2012-06-25 10:33:04 --> Input Class Initialized
DEBUG - 2012-06-25 10:33:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:33:04 --> Language Class Initialized
DEBUG - 2012-06-25 10:33:04 --> Loader Class Initialized
DEBUG - 2012-06-25 10:33:04 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:33:04 --> Controller Class Initialized
DEBUG - 2012-06-25 10:33:04 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:33:04 --> Model Class Initialized
DEBUG - 2012-06-25 10:33:04 --> Model Class Initialized
DEBUG - 2012-06-25 10:33:04 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:33:05 --> File loaded: application/views/board/write_v.php
DEBUG - 2012-06-25 10:33:05 --> File loaded: application/views/footer_v.php
DEBUG - 2012-06-25 10:33:05 --> Final output sent to browser
DEBUG - 2012-06-25 10:33:05 --> Total execution time: 0.0471
DEBUG - 2012-06-25 10:33:07 --> Config Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:33:07 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:33:07 --> URI Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Router Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Output Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Security Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Input Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:33:07 --> Language Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Config Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Loader Class Initialized
DEBUG - 2012-06-25 10:33:07 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:33:07 --> URI Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:33:07 --> Controller Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Router Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Output Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Security Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Input Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:33:07 --> Language Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Model Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Model Class Initialized
DEBUG - 2012-06-25 10:33:07 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:33:07 --> Loader Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Helper loaded: alert_helper
DEBUG - 2012-06-25 10:33:07 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:33:07 --> Controller Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Model Class Initialized
DEBUG - 2012-06-25 10:33:07 --> Model Class Initialized
DEBUG - 2012-06-25 10:33:07 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:33:07 --> Helper loaded: alert_helper
DEBUG - 2012-06-25 10:33:10 --> Config Class Initialized
DEBUG - 2012-06-25 10:33:10 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:33:10 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:33:10 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:33:10 --> URI Class Initialized
DEBUG - 2012-06-25 10:33:10 --> Router Class Initialized
DEBUG - 2012-06-25 10:33:10 --> Output Class Initialized
DEBUG - 2012-06-25 10:33:10 --> Security Class Initialized
DEBUG - 2012-06-25 10:33:10 --> Input Class Initialized
DEBUG - 2012-06-25 10:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:33:10 --> Language Class Initialized
DEBUG - 2012-06-25 10:33:10 --> Loader Class Initialized
DEBUG - 2012-06-25 10:33:10 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:33:10 --> Controller Class Initialized
DEBUG - 2012-06-25 10:33:10 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:33:10 --> Model Class Initialized
DEBUG - 2012-06-25 10:33:10 --> Model Class Initialized
DEBUG - 2012-06-25 10:33:10 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:33:10 --> Pagination Class Initialized
DEBUG - 2012-06-25 10:33:10 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-25 10:33:10 --> File loaded: application/views/footer_v.php
DEBUG - 2012-06-25 10:33:10 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-25 10:33:10 --> Helper loaded: text_helper
DEBUG - 2012-06-25 10:33:10 --> Final output sent to browser
DEBUG - 2012-06-25 10:33:10 --> Total execution time: 0.0382
DEBUG - 2012-06-25 10:42:18 --> Config Class Initialized
DEBUG - 2012-06-25 10:42:18 --> Hooks Class Initialized
DEBUG - 2012-06-25 10:42:18 --> Utf8 Class Initialized
DEBUG - 2012-06-25 10:42:18 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 10:42:18 --> URI Class Initialized
DEBUG - 2012-06-25 10:42:18 --> Router Class Initialized
DEBUG - 2012-06-25 10:42:18 --> Output Class Initialized
DEBUG - 2012-06-25 10:42:18 --> Security Class Initialized
DEBUG - 2012-06-25 10:42:18 --> Input Class Initialized
DEBUG - 2012-06-25 10:42:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 10:42:18 --> Language Class Initialized
DEBUG - 2012-06-25 10:42:18 --> Loader Class Initialized
DEBUG - 2012-06-25 10:42:18 --> Helper loaded: date_helper
DEBUG - 2012-06-25 10:42:18 --> Controller Class Initialized
DEBUG - 2012-06-25 10:42:18 --> Database Driver Class Initialized
DEBUG - 2012-06-25 10:42:18 --> Model Class Initialized
DEBUG - 2012-06-25 10:42:18 --> Model Class Initialized
DEBUG - 2012-06-25 10:42:18 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 10:42:18 --> File loaded: application/views/board/write_v.php
DEBUG - 2012-06-25 10:42:18 --> File loaded: application/views/footer_v.php
DEBUG - 2012-06-25 10:42:18 --> Final output sent to browser
DEBUG - 2012-06-25 10:42:18 --> Total execution time: 0.0329
DEBUG - 2012-06-25 11:26:54 --> Config Class Initialized
DEBUG - 2012-06-25 11:26:54 --> Hooks Class Initialized
DEBUG - 2012-06-25 11:26:54 --> Utf8 Class Initialized
DEBUG - 2012-06-25 11:26:54 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 11:26:54 --> URI Class Initialized
DEBUG - 2012-06-25 11:26:54 --> Router Class Initialized
DEBUG - 2012-06-25 11:26:54 --> No URI present. Default controller set.
DEBUG - 2012-06-25 11:26:54 --> Output Class Initialized
DEBUG - 2012-06-25 11:26:54 --> Security Class Initialized
DEBUG - 2012-06-25 11:26:54 --> Input Class Initialized
DEBUG - 2012-06-25 11:26:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 11:26:54 --> Language Class Initialized
DEBUG - 2012-06-25 11:26:54 --> Loader Class Initialized
DEBUG - 2012-06-25 11:26:54 --> Helper loaded: date_helper
DEBUG - 2012-06-25 11:26:54 --> Controller Class Initialized
DEBUG - 2012-06-25 11:26:54 --> File loaded: application/views/welcome_message.php
DEBUG - 2012-06-25 11:26:54 --> Final output sent to browser
DEBUG - 2012-06-25 11:26:54 --> Total execution time: 0.0201
DEBUG - 2012-06-25 11:26:58 --> Config Class Initialized
DEBUG - 2012-06-25 11:26:58 --> Hooks Class Initialized
DEBUG - 2012-06-25 11:26:58 --> Utf8 Class Initialized
DEBUG - 2012-06-25 11:26:58 --> UTF-8 Support Enabled
DEBUG - 2012-06-25 11:26:58 --> URI Class Initialized
DEBUG - 2012-06-25 11:26:58 --> Router Class Initialized
DEBUG - 2012-06-25 11:26:58 --> Output Class Initialized
DEBUG - 2012-06-25 11:26:58 --> Security Class Initialized
DEBUG - 2012-06-25 11:26:58 --> Input Class Initialized
DEBUG - 2012-06-25 11:26:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-06-25 11:26:58 --> Language Class Initialized
DEBUG - 2012-06-25 11:26:58 --> Loader Class Initialized
DEBUG - 2012-06-25 11:26:58 --> Helper loaded: date_helper
DEBUG - 2012-06-25 11:26:58 --> Controller Class Initialized
DEBUG - 2012-06-25 11:26:58 --> Database Driver Class Initialized
DEBUG - 2012-06-25 11:26:58 --> Model Class Initialized
DEBUG - 2012-06-25 11:26:58 --> Model Class Initialized
DEBUG - 2012-06-25 11:26:58 --> File loaded: application/views/header_v.php
DEBUG - 2012-06-25 11:26:58 --> Pagination Class Initialized
DEBUG - 2012-06-25 11:26:58 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-06-25 11:26:58 --> File loaded: application/views/footer_v.php
DEBUG - 2012-06-25 11:26:58 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-06-25 11:26:58 --> Helper loaded: text_helper
DEBUG - 2012-06-25 11:26:58 --> Final output sent to browser
DEBUG - 2012-06-25 11:26:58 --> Total execution time: 0.0477
