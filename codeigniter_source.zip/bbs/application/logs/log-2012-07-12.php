<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-07-12 07:29:45 --> Config Class Initialized
DEBUG - 2012-07-12 07:29:45 --> Hooks Class Initialized
DEBUG - 2012-07-12 07:29:45 --> Utf8 Class Initialized
DEBUG - 2012-07-12 07:29:45 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 07:29:45 --> URI Class Initialized
DEBUG - 2012-07-12 07:29:45 --> Router Class Initialized
DEBUG - 2012-07-12 07:29:45 --> Output Class Initialized
DEBUG - 2012-07-12 07:29:45 --> Security Class Initialized
DEBUG - 2012-07-12 07:29:45 --> Input Class Initialized
DEBUG - 2012-07-12 07:29:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 07:29:45 --> Language Class Initialized
DEBUG - 2012-07-12 07:29:45 --> Loader Class Initialized
DEBUG - 2012-07-12 07:29:45 --> Helper loaded: date_helper
DEBUG - 2012-07-12 07:29:45 --> Controller Class Initialized
DEBUG - 2012-07-12 07:29:46 --> Database Driver Class Initialized
DEBUG - 2012-07-12 07:29:46 --> Model Class Initialized
DEBUG - 2012-07-12 07:29:46 --> Model Class Initialized
DEBUG - 2012-07-12 07:29:46 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 07:29:46 --> Pagination Class Initialized
DEBUG - 2012-07-12 07:29:47 --> File loaded: application/views/board/list_v.php
DEBUG - 2012-07-12 07:29:47 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 07:29:47 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2012-07-12 07:29:47 --> Helper loaded: text_helper
DEBUG - 2012-07-12 07:29:47 --> Final output sent to browser
DEBUG - 2012-07-12 07:29:47 --> Total execution time: 2.5770
DEBUG - 2012-07-12 07:29:51 --> Config Class Initialized
DEBUG - 2012-07-12 07:29:51 --> Hooks Class Initialized
DEBUG - 2012-07-12 07:29:51 --> Utf8 Class Initialized
DEBUG - 2012-07-12 07:29:51 --> UTF-8 Support Enabled
DEBUG - 2012-07-12 07:29:51 --> URI Class Initialized
DEBUG - 2012-07-12 07:29:51 --> Router Class Initialized
DEBUG - 2012-07-12 07:29:51 --> Output Class Initialized
DEBUG - 2012-07-12 07:29:51 --> Security Class Initialized
DEBUG - 2012-07-12 07:29:51 --> Input Class Initialized
DEBUG - 2012-07-12 07:29:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-12 07:29:51 --> Language Class Initialized
DEBUG - 2012-07-12 07:29:51 --> Loader Class Initialized
DEBUG - 2012-07-12 07:29:51 --> Helper loaded: date_helper
DEBUG - 2012-07-12 07:29:51 --> Controller Class Initialized
DEBUG - 2012-07-12 07:29:51 --> Database Driver Class Initialized
DEBUG - 2012-07-12 07:29:51 --> Model Class Initialized
DEBUG - 2012-07-12 07:29:51 --> Model Class Initialized
DEBUG - 2012-07-12 07:29:51 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-12 07:29:52 --> File loaded: application/views/board/view_v.php
DEBUG - 2012-07-12 07:29:52 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-12 07:29:52 --> Final output sent to browser
DEBUG - 2012-07-12 07:29:52 --> Total execution time: 0.2116
