<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-07-16 05:18:50 --> Config Class Initialized
DEBUG - 2012-07-16 05:18:50 --> Hooks Class Initialized
DEBUG - 2012-07-16 05:18:50 --> Utf8 Class Initialized
DEBUG - 2012-07-16 05:18:50 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 05:18:50 --> URI Class Initialized
DEBUG - 2012-07-16 05:18:50 --> Router Class Initialized
DEBUG - 2012-07-16 05:18:50 --> Output Class Initialized
DEBUG - 2012-07-16 05:18:50 --> Security Class Initialized
DEBUG - 2012-07-16 05:18:50 --> Input Class Initialized
DEBUG - 2012-07-16 05:18:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 05:18:50 --> Language Class Initialized
DEBUG - 2012-07-16 05:18:50 --> Loader Class Initialized
DEBUG - 2012-07-16 05:18:50 --> Helper loaded: date_helper
DEBUG - 2012-07-16 05:18:50 --> Controller Class Initialized
DEBUG - 2012-07-16 05:18:50 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 05:18:50 --> Helper loaded: form_helper
DEBUG - 2012-07-16 05:18:50 --> Form Validation Class Initialized
DEBUG - 2012-07-16 05:18:50 --> File loaded: application/views/test/forms_v.php
DEBUG - 2012-07-16 05:18:50 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 05:18:50 --> Final output sent to browser
DEBUG - 2012-07-16 05:18:50 --> Total execution time: 0.2487
DEBUG - 2012-07-16 05:18:51 --> Config Class Initialized
DEBUG - 2012-07-16 05:18:51 --> Hooks Class Initialized
DEBUG - 2012-07-16 05:18:51 --> Utf8 Class Initialized
DEBUG - 2012-07-16 05:18:51 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 05:18:51 --> URI Class Initialized
DEBUG - 2012-07-16 05:18:51 --> Router Class Initialized
ERROR - 2012-07-16 05:18:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 05:18:55 --> Config Class Initialized
DEBUG - 2012-07-16 05:18:55 --> Hooks Class Initialized
DEBUG - 2012-07-16 05:18:55 --> Utf8 Class Initialized
DEBUG - 2012-07-16 05:18:55 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 05:18:55 --> URI Class Initialized
DEBUG - 2012-07-16 05:18:55 --> Router Class Initialized
DEBUG - 2012-07-16 05:18:55 --> Output Class Initialized
DEBUG - 2012-07-16 05:18:55 --> Security Class Initialized
DEBUG - 2012-07-16 05:18:55 --> Input Class Initialized
DEBUG - 2012-07-16 05:18:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 05:18:55 --> Language Class Initialized
DEBUG - 2012-07-16 05:18:55 --> Loader Class Initialized
DEBUG - 2012-07-16 05:18:55 --> Helper loaded: date_helper
DEBUG - 2012-07-16 05:18:55 --> Controller Class Initialized
DEBUG - 2012-07-16 05:18:55 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 05:18:55 --> Helper loaded: form_helper
DEBUG - 2012-07-16 05:18:55 --> Form Validation Class Initialized
DEBUG - 2012-07-16 05:18:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-16 05:18:55 --> File loaded: application/views/test/forms_v.php
DEBUG - 2012-07-16 05:18:55 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 05:18:55 --> Final output sent to browser
DEBUG - 2012-07-16 05:18:55 --> Total execution time: 0.0627
DEBUG - 2012-07-16 05:18:55 --> Config Class Initialized
DEBUG - 2012-07-16 05:18:55 --> Hooks Class Initialized
DEBUG - 2012-07-16 05:18:55 --> Utf8 Class Initialized
DEBUG - 2012-07-16 05:18:55 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 05:18:55 --> URI Class Initialized
DEBUG - 2012-07-16 05:18:55 --> Router Class Initialized
ERROR - 2012-07-16 05:18:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 05:19:08 --> Config Class Initialized
DEBUG - 2012-07-16 05:19:08 --> Hooks Class Initialized
DEBUG - 2012-07-16 05:19:08 --> Utf8 Class Initialized
DEBUG - 2012-07-16 05:19:08 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 05:19:08 --> URI Class Initialized
DEBUG - 2012-07-16 05:19:08 --> Router Class Initialized
DEBUG - 2012-07-16 05:19:08 --> Output Class Initialized
DEBUG - 2012-07-16 05:19:08 --> Security Class Initialized
DEBUG - 2012-07-16 05:19:08 --> Input Class Initialized
DEBUG - 2012-07-16 05:19:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 05:19:08 --> Language Class Initialized
DEBUG - 2012-07-16 05:19:08 --> Loader Class Initialized
DEBUG - 2012-07-16 05:19:08 --> Helper loaded: date_helper
DEBUG - 2012-07-16 05:19:08 --> Controller Class Initialized
DEBUG - 2012-07-16 05:19:08 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 05:19:08 --> Helper loaded: form_helper
DEBUG - 2012-07-16 05:19:08 --> Form Validation Class Initialized
DEBUG - 2012-07-16 05:19:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-16 05:19:08 --> File loaded: application/views/test/forms_v.php
DEBUG - 2012-07-16 05:19:08 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 05:19:08 --> Final output sent to browser
DEBUG - 2012-07-16 05:19:08 --> Total execution time: 0.0276
DEBUG - 2012-07-16 05:22:57 --> Config Class Initialized
DEBUG - 2012-07-16 05:22:57 --> Hooks Class Initialized
DEBUG - 2012-07-16 05:22:57 --> Utf8 Class Initialized
DEBUG - 2012-07-16 05:22:57 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 05:22:57 --> URI Class Initialized
DEBUG - 2012-07-16 05:22:57 --> Router Class Initialized
DEBUG - 2012-07-16 05:22:57 --> Output Class Initialized
DEBUG - 2012-07-16 05:22:57 --> Security Class Initialized
DEBUG - 2012-07-16 05:22:57 --> Input Class Initialized
DEBUG - 2012-07-16 05:22:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 05:22:57 --> Language Class Initialized
DEBUG - 2012-07-16 05:22:57 --> Loader Class Initialized
DEBUG - 2012-07-16 05:22:57 --> Helper loaded: date_helper
DEBUG - 2012-07-16 05:22:57 --> Controller Class Initialized
DEBUG - 2012-07-16 05:22:57 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 05:22:57 --> Helper loaded: form_helper
DEBUG - 2012-07-16 05:22:57 --> Form Validation Class Initialized
DEBUG - 2012-07-16 05:22:57 --> File loaded: application/views/test/forms_v.php
DEBUG - 2012-07-16 05:22:57 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 05:22:57 --> Final output sent to browser
DEBUG - 2012-07-16 05:22:57 --> Total execution time: 0.0253
DEBUG - 2012-07-16 05:22:58 --> Config Class Initialized
DEBUG - 2012-07-16 05:22:58 --> Hooks Class Initialized
DEBUG - 2012-07-16 05:22:58 --> Utf8 Class Initialized
DEBUG - 2012-07-16 05:22:58 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 05:22:58 --> URI Class Initialized
DEBUG - 2012-07-16 05:22:58 --> Router Class Initialized
ERROR - 2012-07-16 05:22:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 05:23:54 --> Config Class Initialized
DEBUG - 2012-07-16 05:23:54 --> Hooks Class Initialized
DEBUG - 2012-07-16 05:23:54 --> Utf8 Class Initialized
DEBUG - 2012-07-16 05:23:54 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 05:23:54 --> URI Class Initialized
DEBUG - 2012-07-16 05:23:54 --> Router Class Initialized
DEBUG - 2012-07-16 05:23:54 --> Output Class Initialized
DEBUG - 2012-07-16 05:23:54 --> Security Class Initialized
DEBUG - 2012-07-16 05:23:54 --> Input Class Initialized
DEBUG - 2012-07-16 05:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 05:23:54 --> Language Class Initialized
DEBUG - 2012-07-16 05:23:54 --> Loader Class Initialized
DEBUG - 2012-07-16 05:23:54 --> Helper loaded: date_helper
DEBUG - 2012-07-16 05:23:54 --> Controller Class Initialized
DEBUG - 2012-07-16 05:23:54 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 05:23:54 --> Helper loaded: form_helper
DEBUG - 2012-07-16 05:23:54 --> Form Validation Class Initialized
DEBUG - 2012-07-16 05:23:54 --> File loaded: application/views/test/forms_v.php
DEBUG - 2012-07-16 05:23:54 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 05:23:54 --> Final output sent to browser
DEBUG - 2012-07-16 05:23:54 --> Total execution time: 0.0245
DEBUG - 2012-07-16 05:23:54 --> Config Class Initialized
DEBUG - 2012-07-16 05:23:54 --> Hooks Class Initialized
DEBUG - 2012-07-16 05:23:54 --> Utf8 Class Initialized
DEBUG - 2012-07-16 05:23:54 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 05:23:54 --> URI Class Initialized
DEBUG - 2012-07-16 05:23:54 --> Router Class Initialized
ERROR - 2012-07-16 05:23:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 06:10:41 --> Config Class Initialized
DEBUG - 2012-07-16 06:10:41 --> Hooks Class Initialized
DEBUG - 2012-07-16 06:10:41 --> Utf8 Class Initialized
DEBUG - 2012-07-16 06:10:41 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 06:10:41 --> URI Class Initialized
DEBUG - 2012-07-16 06:10:41 --> Router Class Initialized
DEBUG - 2012-07-16 06:10:41 --> Output Class Initialized
DEBUG - 2012-07-16 06:10:41 --> Security Class Initialized
DEBUG - 2012-07-16 06:10:41 --> Input Class Initialized
DEBUG - 2012-07-16 06:10:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 06:10:41 --> Language Class Initialized
DEBUG - 2012-07-16 06:10:41 --> Loader Class Initialized
DEBUG - 2012-07-16 06:10:41 --> Helper loaded: date_helper
DEBUG - 2012-07-16 06:10:41 --> Controller Class Initialized
DEBUG - 2012-07-16 06:10:41 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 06:10:41 --> Helper loaded: form_helper
DEBUG - 2012-07-16 06:10:41 --> Form Validation Class Initialized
DEBUG - 2012-07-16 06:10:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-16 06:10:41 --> File loaded: application/views/test/form_success_v.php
DEBUG - 2012-07-16 06:10:41 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 06:10:41 --> Final output sent to browser
DEBUG - 2012-07-16 06:10:41 --> Total execution time: 0.0360
DEBUG - 2012-07-16 09:07:01 --> Config Class Initialized
DEBUG - 2012-07-16 09:07:01 --> Hooks Class Initialized
DEBUG - 2012-07-16 09:07:01 --> Utf8 Class Initialized
DEBUG - 2012-07-16 09:07:01 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 09:07:01 --> URI Class Initialized
DEBUG - 2012-07-16 09:07:01 --> Router Class Initialized
ERROR - 2012-07-16 09:07:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 09:07:07 --> Config Class Initialized
DEBUG - 2012-07-16 09:07:07 --> Hooks Class Initialized
DEBUG - 2012-07-16 09:07:07 --> Utf8 Class Initialized
DEBUG - 2012-07-16 09:07:07 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 09:07:07 --> URI Class Initialized
DEBUG - 2012-07-16 09:07:07 --> Router Class Initialized
DEBUG - 2012-07-16 09:07:07 --> Output Class Initialized
DEBUG - 2012-07-16 09:07:07 --> Security Class Initialized
DEBUG - 2012-07-16 09:07:07 --> Input Class Initialized
DEBUG - 2012-07-16 09:07:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 09:07:08 --> Language Class Initialized
DEBUG - 2012-07-16 09:07:08 --> Loader Class Initialized
DEBUG - 2012-07-16 09:07:08 --> Helper loaded: date_helper
DEBUG - 2012-07-16 09:07:08 --> Controller Class Initialized
DEBUG - 2012-07-16 09:07:08 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 09:07:08 --> Helper loaded: form_helper
DEBUG - 2012-07-16 09:07:08 --> Form Validation Class Initialized
DEBUG - 2012-07-16 09:07:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-16 09:07:08 --> File loaded: application/views/test/forms_v.php
DEBUG - 2012-07-16 09:07:08 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 09:07:08 --> Final output sent to browser
DEBUG - 2012-07-16 09:07:08 --> Total execution time: 0.1387
DEBUG - 2012-07-16 09:07:08 --> Config Class Initialized
DEBUG - 2012-07-16 09:07:08 --> Hooks Class Initialized
DEBUG - 2012-07-16 09:07:08 --> Utf8 Class Initialized
DEBUG - 2012-07-16 09:07:08 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 09:07:08 --> URI Class Initialized
DEBUG - 2012-07-16 09:07:08 --> Router Class Initialized
ERROR - 2012-07-16 09:07:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-07-16 09:07:15 --> Config Class Initialized
DEBUG - 2012-07-16 09:07:15 --> Hooks Class Initialized
DEBUG - 2012-07-16 09:07:15 --> Utf8 Class Initialized
DEBUG - 2012-07-16 09:07:15 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 09:07:15 --> URI Class Initialized
DEBUG - 2012-07-16 09:07:15 --> Router Class Initialized
DEBUG - 2012-07-16 09:07:15 --> Output Class Initialized
DEBUG - 2012-07-16 09:07:15 --> Security Class Initialized
DEBUG - 2012-07-16 09:07:15 --> Input Class Initialized
DEBUG - 2012-07-16 09:07:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-07-16 09:07:15 --> Language Class Initialized
DEBUG - 2012-07-16 09:07:15 --> Loader Class Initialized
DEBUG - 2012-07-16 09:07:15 --> Helper loaded: date_helper
DEBUG - 2012-07-16 09:07:15 --> Controller Class Initialized
DEBUG - 2012-07-16 09:07:15 --> File loaded: application/views/header_v.php
DEBUG - 2012-07-16 09:07:15 --> Helper loaded: form_helper
DEBUG - 2012-07-16 09:07:15 --> Form Validation Class Initialized
DEBUG - 2012-07-16 09:07:15 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2012-07-16 09:07:15 --> File loaded: application/views/test/form_success_v.php
DEBUG - 2012-07-16 09:07:15 --> File loaded: application/views/footer_v.php
DEBUG - 2012-07-16 09:07:15 --> Final output sent to browser
DEBUG - 2012-07-16 09:07:15 --> Total execution time: 0.0375
DEBUG - 2012-07-16 09:07:15 --> Config Class Initialized
DEBUG - 2012-07-16 09:07:15 --> Hooks Class Initialized
DEBUG - 2012-07-16 09:07:15 --> Utf8 Class Initialized
DEBUG - 2012-07-16 09:07:15 --> UTF-8 Support Enabled
DEBUG - 2012-07-16 09:07:15 --> URI Class Initialized
DEBUG - 2012-07-16 09:07:15 --> Router Class Initialized
ERROR - 2012-07-16 09:07:15 --> 404 Page Not Found --> favicon.ico
