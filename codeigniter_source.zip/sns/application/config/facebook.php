<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
|--------------------------------------------------------------------------
| 페이스북 OAuth 인증을 위한 키
|
| If you want to integrate with Facebook Connect authentication, put your
| Facebook App ID below.
|--------------------------------------------------------------------------
*/
$config['facebook_app_id'] = '172584046135587';
$config['facebook_app_secret_code'] = '2fb1f5221798267af13c16b68ddb6f46';
?>